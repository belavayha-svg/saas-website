-- ============================================================
-- Multi-Tenant SaaS AI Chatbot Platform — Database Schema
-- MySQL 8+ | UTF8MB4
-- ============================================================

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ------------------------------------------------------------
-- Users (Business Owners + Super Admins)
-- ------------------------------------------------------------
CREATE TABLE `users` (
  `id`         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `name`       VARCHAR(100) NOT NULL,
  `email`      VARCHAR(150) NOT NULL UNIQUE,
  `password`   VARCHAR(255) NOT NULL,
  `role`       ENUM('super_admin','business') NOT NULL DEFAULT 'business',
  `status`     ENUM('active','suspended') NOT NULL DEFAULT 'active',
  `business_name` VARCHAR(150) NULL,
  `logo`       VARCHAR(255) NULL,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ------------------------------------------------------------
-- Subscription Plans
-- ------------------------------------------------------------
CREATE TABLE `plans` (
  `id`                  INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `plan_name`           VARCHAR(100) NOT NULL,
  `duration_days`       INT UNSIGNED NOT NULL DEFAULT 30,
  `ai_message_limit`    INT NOT NULL DEFAULT 100 COMMENT '-1 = unlimited',
  `page_limit`          INT NOT NULL DEFAULT 1  COMMENT '-1 = unlimited',
  `price`               DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `status`              ENUM('active','inactive') NOT NULL DEFAULT 'active',
  `created_at`          TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ------------------------------------------------------------
-- Subscriptions
-- ------------------------------------------------------------
CREATE TABLE `subscriptions` (
  `id`                  INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `user_id`             INT UNSIGNED NOT NULL,
  `plan_id`             INT UNSIGNED NOT NULL,
  `start_date`          DATE NOT NULL,
  `end_date`            DATE NOT NULL,
  `remaining_messages`  INT NOT NULL DEFAULT 0 COMMENT '-1 = unlimited',
  `status`              ENUM('active','expired','cancelled') NOT NULL DEFAULT 'active',
  `created_at`          TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`plan_id`) REFERENCES `plans`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ------------------------------------------------------------
-- Payment Methods (Admin-configured)
-- ------------------------------------------------------------
CREATE TABLE `payment_methods` (
  `id`               INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `method_name`      VARCHAR(100) NOT NULL,
  `account_number`   VARCHAR(50)  NOT NULL,
  `account_holder`   VARCHAR(100) NOT NULL,
  `status`           ENUM('active','inactive') NOT NULL DEFAULT 'active',
  `created_at`       TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ------------------------------------------------------------
-- Payment Requests (Manual Verification)
-- ------------------------------------------------------------
CREATE TABLE `payment_requests` (
  `id`               INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `user_id`          INT UNSIGNED NOT NULL,
  `plan_id`          INT UNSIGNED NOT NULL,
  `trx_id`           VARCHAR(100) NOT NULL,
  `payment_method`   VARCHAR(100) NOT NULL,
  `amount`           DECIMAL(10,2) NOT NULL,
  `payment_status`   ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  `note`             TEXT NULL,
  `submitted_at`     TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `reviewed_at`      TIMESTAMP NULL,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`plan_id`) REFERENCES `plans`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ------------------------------------------------------------
-- Facebook Pages (per Business)
-- ------------------------------------------------------------
CREATE TABLE `facebook_pages` (
  `id`           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `user_id`      INT UNSIGNED NOT NULL,
  `page_id`      VARCHAR(50)  NOT NULL,
  `page_name`    VARCHAR(150) NOT NULL,
  `page_token`   TEXT         NOT NULL,
  `status`       ENUM('active','inactive') NOT NULL DEFAULT 'active',
  `created_at`   TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY `uk_user_page` (`user_id`, `page_id`),
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ------------------------------------------------------------
-- Products (per Business)
-- ------------------------------------------------------------
CREATE TABLE `products` (
  `id`          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `user_id`     INT UNSIGNED NOT NULL,
  `name`        VARCHAR(200) NOT NULL,
  `description` TEXT         NULL,
  `price`       DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `image`       VARCHAR(255) NULL,
  `status`      ENUM('active','inactive') NOT NULL DEFAULT 'active',
  `created_at`  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ------------------------------------------------------------
-- Orders (per Business, from Messenger)
-- ------------------------------------------------------------
CREATE TABLE `orders` (
  `id`              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `user_id`         INT UNSIGNED NOT NULL,
  `fb_sender_id`    VARCHAR(50)  NOT NULL,
  `page_id`         VARCHAR(50)  NOT NULL,
  `status`          ENUM('pending','confirmed','processing','delivered','cancelled') NOT NULL DEFAULT 'pending',
  `total_amount`    DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `delivery_charge` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `payment_type`    ENUM('full','half','delivery_only','pending') NOT NULL DEFAULT 'full',
  `paid_amount`     DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `customer_name`   VARCHAR(150) NULL,
  `customer_phone`  VARCHAR(20)  NULL,
  `customer_address` TEXT         NULL,
  `note`            TEXT NULL,
  `created_at`      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ------------------------------------------------------------
-- Delivery Rules (per Business)
-- ------------------------------------------------------------
CREATE TABLE `delivery_rules` (
  `id`          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `user_id`     INT UNSIGNED NOT NULL,
  `area_name`   VARCHAR(150) NOT NULL,
  `charge`      DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `note`        VARCHAR(255) NULL,
  `created_at`  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ------------------------------------------------------------
-- Business Payment Methods (per Business)
-- ------------------------------------------------------------
CREATE TABLE `business_payment_methods` (
  `id`             INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `user_id`        INT UNSIGNED NOT NULL,
  `method_name`    VARCHAR(100) NOT NULL,
  `account_number` VARCHAR(100) NOT NULL,
  `created_at`     TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- ------------------------------------------------------------
-- Order Items
-- ------------------------------------------------------------
CREATE TABLE `order_items` (
  `id`          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `order_id`    INT UNSIGNED NOT NULL,
  `product_id`  INT UNSIGNED NULL,
  `product_name` VARCHAR(200) NOT NULL,
  `quantity`    INT UNSIGNED NOT NULL DEFAULT 1,
  `price`       DECIMAL(10,2) NOT NULL,
  FOREIGN KEY (`order_id`)   REFERENCES `orders`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`product_id`) REFERENCES `products`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ------------------------------------------------------------
-- Conversations (Messenger threads per Business)
-- ------------------------------------------------------------
CREATE TABLE `conversations` (
  `id`           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `user_id`      INT UNSIGNED NOT NULL,
  `fb_sender_id` VARCHAR(50)  NOT NULL,
  `page_id`      VARCHAR(50)  NOT NULL,
  `created_at`   TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY `uk_conv` (`user_id`, `fb_sender_id`, `page_id`),
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ------------------------------------------------------------
-- Messages (Chat history)
-- ------------------------------------------------------------
CREATE TABLE `messages` (
  `id`               INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `conversation_id`  INT UNSIGNED NOT NULL,
  `role`             ENUM('user','model') NOT NULL,
  `content`          TEXT NOT NULL,
  `created_at`       TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`conversation_id`) REFERENCES `conversations`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ------------------------------------------------------------
-- AI Usage Logs
-- ------------------------------------------------------------
CREATE TABLE `ai_usage_logs` (
  `id`         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `user_id`    INT UNSIGNED NOT NULL,
  `page_id`    VARCHAR(50)  NOT NULL,
  `tokens_used` INT UNSIGNED NOT NULL DEFAULT 0,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ------------------------------------------------------------
-- System Settings
-- ------------------------------------------------------------
CREATE TABLE `system_settings` (
  `id`            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `setting_key`   VARCHAR(100) NOT NULL UNIQUE,
  `setting_value` TEXT         NULL,
  `updated_at`    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================================
-- SEED DATA
-- ============================================================

-- Super Admin (password: Admin@1234)
INSERT INTO `users` (`name`, `email`, `password`, `role`, `status`) VALUES
('Super Admin', 'admin@saas.com', '$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'super_admin', 'active');

-- Default Plans
-- ✅ Fix #3: INSERT IGNORE ensures re-running the script won't duplicate.
--    AUTO_INCREMENT reset guarantees Free plan always gets id=1.
ALTER TABLE `plans` AUTO_INCREMENT = 1;
INSERT IGNORE INTO `plans` (`id`, `plan_name`, `duration_days`, `ai_message_limit`, `page_limit`, `price`) VALUES
(1, 'Free',         30,   100,   1,    0.00),
(2, 'Starter',      30,  1000,   1,  299.00),
(3, 'Professional', 30,  5000,   5,  699.00),
(4, 'Business',     30,    -1,  -1, 1499.00);

-- Default Payment Methods
INSERT INTO `payment_methods` (`method_name`, `account_number`, `account_holder`, `status`) VALUES
('bKash Personal',  '01700000000', 'SaaS Platform', 'active'),
('Nagad Personal',  '01800000000', 'SaaS Platform', 'active');

-- Default System Settings
INSERT INTO `system_settings` (`setting_key`, `setting_value`) VALUES
('site_name',           'AI Chatbot SaaS'),
('site_logo',           ''),
('gemini_api_key',    ''),
('fb_app_id',           ''),
('fb_app_secret',       ''),
('webhook_verify_token','SAAS_WEBHOOK_SECRET_CHANGE_ME'),
('smtp_host',           ''),
('smtp_port',           '587'),
('smtp_user',           ''),
('smtp_pass',           ''),
('smtp_from',           '');

SET FOREIGN_KEY_CHECKS = 1;
