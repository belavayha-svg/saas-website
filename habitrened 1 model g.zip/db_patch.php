<?php
require __DIR__ . '/app/Core/Database.php';

// Mock env function for the script
function env($key, $default = '') {
    $env = parse_ini_file(__DIR__ . '/.env');
    return $env[$key] ?? $default;
}

try {
    $db = \App\Core\Database::getInstance();

    // ─── Create business_payment_methods table ───
    $db->execute("
        CREATE TABLE IF NOT EXISTS `business_payment_methods` (
          `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
          `user_id` INT UNSIGNED NOT NULL,
          `method_name` VARCHAR(100) NOT NULL,
          `account_number` VARCHAR(100) NOT NULL,
          `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
          FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    ");
    echo "Table business_payment_methods created or already exists.\n";

    // ─── Products extra image/color columns ───
    $productColumns = [
        'colors'  => 'VARCHAR(255) NULL AFTER `name`',
        'image_2' => 'VARCHAR(255) NULL AFTER `image`',
        'image_3' => 'VARCHAR(255) NULL AFTER `image_2`',
        'image_4' => 'VARCHAR(255) NULL AFTER `image_3`'
    ];

    foreach ($productColumns as $col => $def) {
        try {
            $db->execute("ALTER TABLE `products` ADD COLUMN `$col` $def");
            echo "Added products.$col column.\n";
        } catch (Exception $e) {
            echo "Column products.$col already exists or error: " . $e->getMessage() . "\n";
        }
    }

    // ─── Orders: update payment_type ENUM (full / partial / pending) ───
    try {
        $db->execute("ALTER TABLE `orders` MODIFY COLUMN `payment_type` ENUM('full','partial','pending') NOT NULL DEFAULT 'pending'");
        echo "orders.payment_type ENUM updated (full/partial/pending).\n";
    } catch (Exception $e) {
        echo "payment_type alter error: " . $e->getMessage() . "\n";
    }

    // ─── Orders: add transaction_id column ───
    try {
        $db->execute("ALTER TABLE `orders` ADD COLUMN `transaction_id` VARCHAR(100) NULL AFTER `paid_amount`");
        echo "Added orders.transaction_id column.\n";
    } catch (Exception $e) {
        echo "orders.transaction_id already exists or error: " . $e->getMessage() . "\n";
    }

    // ─── Orders: add amount_sent column ───
    try {
        $db->execute("ALTER TABLE `orders` ADD COLUMN `amount_sent` DECIMAL(10,2) NOT NULL DEFAULT 0.00 AFTER `transaction_id`");
        echo "Added orders.amount_sent column.\n";
    } catch (Exception $e) {
        echo "orders.amount_sent already exists or error: " . $e->getMessage() . "\n";
    }

    // ─── Users: add remember_token column (auto-login) ───
    try {
        $db->execute("ALTER TABLE `users` ADD COLUMN `remember_token` VARCHAR(100) NULL AFTER `status`");
        echo "Added users.remember_token column.\n";
    } catch (Exception $e) {
        echo "users.remember_token already exists or error: " . $e->getMessage() . "\n";
    }

    echo "\n✅ Migration complete!\n";

} catch (Exception $e) {
    echo "Fatal Error: " . $e->getMessage() . "\n";
}
