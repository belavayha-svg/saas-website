<?php

declare(strict_types=1);

/**
 * index.php — Application Entry Point
 * Place this in /public_html on production hosting.
 */

define('BASE_PATH', __DIR__);

// ── Autoloader ────────────────────────────────────────────
spl_autoload_register(function (string $class): void {
    // Convert namespace to path: App\Core\Database → app/Core/Database.php
    $prefix = 'App\\';
    if (!str_starts_with($class, $prefix)) return;
    $relative = str_replace('\\', '/', substr($class, strlen($prefix)));
    $file     = BASE_PATH . '/app/' . $relative . '.php';
    if (file_exists($file)) require $file;
});

// ── Bootstrap config (loads .env) ────────────────────────
$appConfig = require BASE_PATH . '/config/app.php';

// ── Session ───────────────────────────────────────────────
use App\Core\Session;
Session::start();

// ── Error display ─────────────────────────────────────────
if ($appConfig['debug']) {
    ini_set('display_errors', '1');
    error_reporting(E_ALL);
} else {
    ini_set('display_errors', '0');
    error_reporting(0);
    // Log errors instead
    ini_set('log_errors', '1');
    ini_set('error_log', BASE_PATH . '/storage/logs/error.log');
}

// ── Security headers ──────────────────────────────────────
header('X-Frame-Options: SAMEORIGIN');
header('X-Content-Type-Options: nosniff');
header('X-XSS-Protection: 1; mode=block');
header('Referrer-Policy: strict-origin-when-cross-origin');

// ── Router ────────────────────────────────────────────────
use App\Core\{Router, Request};

$router  = new Router();
$request = new Request();

require BASE_PATH . '/routes/web.php';

$router->dispatch($request);
