<?php

declare(strict_types=1);

use App\Core\Router;
use App\Middleware\{AuthMiddleware, AdminMiddleware};
use App\Controllers\{AuthController, DashboardController, ProductController, OrderController, DeliveryRuleController, FacebookController, SubscriptionController, ReportController, WebhookController};
use App\Controllers\Admin\{AdminDashboardController, UserManagementController, PlanController, PaymentVerificationController, BusinessController, SystemSettingController};

/** @var Router $router */

// ──────────────────────────────────────────────
// Public Auth Routes
// ──────────────────────────────────────────────
$router->get('/login',    [AuthController::class, 'showLogin']);
$router->post('/login',   [AuthController::class, 'login']);
$router->get('/register', [AuthController::class, 'showRegister']);
$router->post('/register',[AuthController::class, 'register']);
$router->get('/logout',   [AuthController::class, 'logout']);

// ──────────────────────────────────────────────
// Webhook (public, no auth)
// ──────────────────────────────────────────────
$router->get('/webhook',  [WebhookController::class, 'handle']);
$router->post('/webhook', [WebhookController::class, 'handle']);

// ──────────────────────────────────────────────
// Business Routes (Auth Protected)
// ──────────────────────────────────────────────
$router->group(['middleware' => [AuthMiddleware::class]], function(Router $r) {

    $r->get('/',           [DashboardController::class, 'index']);
    $r->get('/dashboard',  [DashboardController::class, 'index']);

    // Products
    $r->get('/products',            [ProductController::class, 'index']);
    $r->get('/products/create',     [ProductController::class, 'create']);
    $r->post('/products',           [ProductController::class, 'store']);
    $r->get('/products/:id/edit',   [ProductController::class, 'edit']);
    $r->post('/products/:id/update',[ProductController::class, 'update']);
    $r->post('/products/:id/delete',[ProductController::class, 'destroy']);

    // Orders
    $r->get('/orders',                  [OrderController::class, 'index']);
    $r->get('/orders/:id',              [OrderController::class, 'show']);
    $r->post('/orders/:id/status',      [OrderController::class, 'updateStatus']);
    $r->post('/orders/:id/payment',     [OrderController::class, 'updatePayment']);

    // Delivery Rules (AJAX API for products page modal)
    $r->get('/delivery-rules',              [DeliveryRuleController::class, 'index']);
    $r->post('/delivery-rules',             [DeliveryRuleController::class, 'store']);
    $r->post('/delivery-rules/:id/update',  [DeliveryRuleController::class, 'update']);
    $r->post('/delivery-rules/:id/delete',  [DeliveryRuleController::class, 'destroy']);

    // Business Payment Methods (for AI prompt)
    $r->post('/business-payments',             [DeliveryRuleController::class, 'storePayment']);
    $r->post('/business-payments/:id/delete',  [DeliveryRuleController::class, 'destroyPayment']);


    // Conversations
    $r->get('/conversations',        [\App\Controllers\ConversationController::class, 'index']);
    $r->get('/conversations/:id',    [\App\Controllers\ConversationController::class, 'show']);
    $r->post('/conversations/:id/send', [\App\Controllers\ConversationController::class, 'sendManual']);

    // Facebook Pages
    $r->get('/facebook',             [FacebookController::class, 'index']);
    $r->post('/facebook/connect',    [FacebookController::class, 'connect']);
    $r->post('/facebook/:id/disconnect', [FacebookController::class, 'disconnect']);
    $r->get('/api/facebook/pages',   [FacebookController::class, 'getPages']);

    // Subscription
    $r->get('/subscription',                      [SubscriptionController::class, 'index']);
    $r->get('/subscription/checkout/:planId',     [SubscriptionController::class, 'checkout']);
    $r->post('/subscription/payment',             [SubscriptionController::class, 'submitPayment']);

    // Reports
    $r->get('/reports', [ReportController::class, 'index']);
});

// ──────────────────────────────────────────────
// Super Admin Routes
// ──────────────────────────────────────────────
$router->group(['prefix' => '/admin', 'middleware' => [AdminMiddleware::class]], function(Router $r) {

    $r->get('/dashboard',  [AdminDashboardController::class, 'index']);

    // Users
    $r->get('/users',              [UserManagementController::class, 'index']);
    $r->get('/users/:id/edit',     [UserManagementController::class, 'edit']);
    $r->post('/users/:id/update',  [UserManagementController::class, 'update']);
    $r->post('/users/:id/suspend', [UserManagementController::class, 'suspend']);
    $r->post('/users/:id/activate',[UserManagementController::class, 'activate']);
    $r->post('/users/:id/delete',  [UserManagementController::class, 'delete']);

    // Plans & Payment Methods
    $r->get('/plans',                   [PlanController::class, 'index']);
    $r->get('/plans/create',            [PlanController::class, 'create']);
    $r->post('/plans',                  [PlanController::class, 'store']);
    $r->post('/plans/:id/update',       [PlanController::class, 'update']);
    $r->post('/plans/:id/delete',       [PlanController::class, 'delete']);
    $r->post('/methods',                [PlanController::class, 'storeMethod']);
    $r->post('/methods/:id/delete',     [PlanController::class, 'deleteMethod']);

    // Payment Verification
    $r->get('/payments',               [PaymentVerificationController::class, 'index']);
    $r->post('/payments/:id/approve',  [PaymentVerificationController::class, 'approve']);
    $r->post('/payments/:id/reject',   [PaymentVerificationController::class, 'reject']);

    // Business Management
    $r->get('/businesses',             [BusinessController::class, 'index']);
    $r->get('/businesses/:id',         [BusinessController::class, 'show']);
    $r->post('/businesses/:id/login-as',[BusinessController::class, 'loginAs']);
    $r->get('/return-to-admin',        [BusinessController::class, 'returnToAdmin']);

    // System Settings
    $r->get('/settings',               [SystemSettingController::class, 'index']);
    $r->post('/settings',              [SystemSettingController::class, 'update']);
});
