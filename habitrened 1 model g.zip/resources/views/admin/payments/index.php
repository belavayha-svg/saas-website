<?php $pageTitle = 'Payment Verification'; include __DIR__ . '/../layouts/app.php'; ?>

<div class="flex justify-between items-center mb-6">
  <div>
    <h2 class="text-xl font-bold text-slate-800">Payment Verification</h2>
    <p class="text-sm text-slate-500">Approve or reject manual payment requests based on TrxID</p>
  </div>
  <div class="flex gap-2">
    <?php foreach (['pending','approved','rejected'] as $s): ?>
    <a href="/admin/payments?status=<?= $s ?>"
      class="text-xs px-3 py-1.5 rounded-full font-medium transition-colors <?= $status === $s ? 'bg-indigo-600 text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200' ?>">
      <?= ucfirst($s) ?>
    </a>
    <?php endforeach; ?>
  </div>
</div>

<div class="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
  <?php if (empty($payments)): ?>
  <div class="p-10 text-center text-slate-500">
    <div class="h-12 w-12 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-3">
      <svg class="w-6 h-6 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
    </div>
    No <?= $status ?> payment requests found.
  </div>
  <?php else: ?>
  <table class="w-full text-sm">
    <thead class="bg-slate-50">
      <tr>
        <th class="text-left px-5 py-3 text-slate-600 font-medium">Date</th>
        <th class="text-left px-5 py-3 text-slate-600 font-medium">Business / User</th>
        <th class="text-left px-5 py-3 text-slate-600 font-medium">Plan Requested</th>
        <th class="text-left px-5 py-3 text-slate-600 font-medium">Payment Details</th>
        <th class="text-left px-5 py-3 text-slate-600 font-medium">Status</th>
        <th class="text-right px-5 py-3 text-slate-600 font-medium">Actions</th>
      </tr>
    </thead>
    <tbody class="divide-y divide-slate-50">
      <?php foreach ($payments as $p): ?>
      <tr class="hover:bg-slate-50 group">
        <td class="px-5 py-4 text-xs text-slate-500 whitespace-nowrap">
          <?= date('M j, Y g:ia', strtotime($p['submitted_at'])) ?>
        </td>
        <td class="px-5 py-4">
          <p class="font-medium text-slate-800 text-xs"><?= htmlspecialchars($p['user_name']) ?></p>
          <p class="text-xs text-slate-400"><?= htmlspecialchars($p['business_name'] ?? 'No Business Name') ?></p>
        </td>
        <td class="px-5 py-4">
          <span class="inline-block bg-indigo-50 text-indigo-700 text-xs font-semibold px-2 py-0.5 rounded"><?= htmlspecialchars($p['plan_name']) ?></span>
          <p class="text-xs font-bold text-slate-800 mt-1">৳<?= number_format($p['amount'], 2) ?></p>
        </td>
        <td class="px-5 py-4">
          <p class="text-xs font-medium text-slate-800"><?= htmlspecialchars($p['payment_method']) ?></p>
          <div class="flex items-center gap-2 mt-1">
            <span class="text-xs font-mono bg-slate-100 text-slate-600 px-2 py-0.5 rounded font-bold border border-slate-200"><?= htmlspecialchars($p['trx_id']) ?></span>
          </div>
        </td>
        <td class="px-5 py-4">
          <span class="text-xs px-2 py-0.5 rounded-full <?= match($p['payment_status']) {
            'approved' => 'bg-green-100 text-green-700',
            'rejected' => 'bg-red-100 text-red-700',
            default    => 'bg-amber-100 text-amber-700'
          } ?>"><?= ucfirst($p['payment_status']) ?></span>
        </td>
        <td class="px-5 py-4 text-right">
          <?php if ($p['payment_status'] === 'pending'): ?>
          <div class="flex items-center justify-end gap-2">
            <form method="POST" action="/admin/payments/<?= $p['id'] ?>/approve" onsubmit="return confirm('Approve this payment and activate the subscription?')">
              <?= \App\Core\CSRF::field() ?>
              <button class="btn-success py-1 px-3">Approve</button>
            </form>
            <form method="POST" action="/admin/payments/<?= $p['id'] ?>/reject" onsubmit="return confirm('Reject this payment?')">
              <?= \App\Core\CSRF::field() ?>
              <button class="text-red-500 hover:text-red-700 text-xs font-medium px-2 py-1">Reject</button>
            </form>
          </div>
          <?php endif; ?>
        </td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>

  <!-- Pagination -->
  <?php if ($total > $limit): ?>
  <div class="px-5 py-4 border-t border-slate-100 flex justify-between">
    <p class="text-xs text-slate-500">Page <?= $page ?></p>
    <div class="flex gap-2">
      <?php if ($page > 1): ?><a href="?status=<?= $status ?>&page=<?= $page-1 ?>" class="text-xs px-3 py-1.5 bg-slate-100 rounded-lg hover:bg-slate-200">← Prev</a><?php endif; ?>
      <?php if ($page * $limit < $total): ?><a href="?status=<?= $status ?>&page=<?= $page+1 ?>" class="text-xs px-3 py-1.5 bg-slate-100 rounded-lg hover:bg-slate-200">Next →</a><?php endif; ?>
    </div>
  </div>
  <?php endif; ?>
  <?php endif; ?>
</div>

<?php include __DIR__ . '/../layouts/footer.php'; ?>
