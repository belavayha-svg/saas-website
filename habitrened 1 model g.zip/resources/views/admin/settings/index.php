<?php $pageTitle = 'System Settings'; include __DIR__ . '/../layouts/app.php'; ?>

<div class="flex items-center justify-between mb-6">
  <div>
    <h2 class="text-xl font-bold text-slate-800">System Settings</h2>
    <p class="text-sm text-slate-500">Manage global platform configurations</p>
  </div>
</div>

<div class="bg-white rounded-2xl shadow-sm border border-slate-100">
  <div class="lg:flex">
    <!-- Settings Form -->
    <div class="p-6 flex-1 lg:border-r border-slate-100 border-b lg:border-b-0">
      <form method="POST" action="/admin/settings" class="space-y-6 max-w-lg">
        <?= \App\Core\CSRF::field() ?>

        <div>
          <h3 class="text-sm font-bold tracking-wide text-slate-400 uppercase mb-3">General Settings</h3>
          <div class="space-y-4">
            <div>
              <label class="block text-sm font-medium text-slate-700 mb-1">Site Form Name</label>
              <input type="text" name="settings[site_name]" value="<?= htmlspecialchars($settings['site_name'] ?? '') ?>" class="form-input text-sm">
            </div>
            <div>
              <label class="block text-sm font-medium text-slate-700 mb-1">Site Logo URL</label>
              <input type="text" name="settings[site_logo]" value="<?= htmlspecialchars($settings['site_logo'] ?? '') ?>" class="form-input text-sm" placeholder="https://example.com/logo.png">
            </div>
            <div>
              <label class="block text-sm font-medium text-slate-700 mb-1">Support Email</label>
              <input type="email" name="settings[support_email]" value="<?= htmlspecialchars($settings['support_email'] ?? '') ?>" class="form-input text-sm">
            </div>
          </div>
        </div>

        <div>
          <h3 class="text-sm font-bold tracking-wide text-slate-400 uppercase mb-3 pt-3 border-t border-slate-100">Free Tier Limits</h3>
          <p class="text-xs text-slate-500 mb-3">Fallback limits applied to users without an active subscription.</p>
          <div class="grid grid-cols-2 gap-4">
            <div>
              <label class="block text-xs font-medium text-slate-700 mb-1">AI Messages Limit</label>
              <input type="number" name="settings[free_ai_limit]" value="<?= htmlspecialchars($settings['free_ai_limit'] ?? '100') ?>" class="form-input text-sm">
            </div>
            <div>
              <label class="block text-xs font-medium text-slate-700 mb-1">Facebook Pages Limit</label>
              <input type="number" name="settings[free_page_limit]" value="<?= htmlspecialchars($settings['free_page_limit'] ?? '1') ?>" class="form-input text-sm">
            </div>
          </div>
        </div>

        <div class="pt-4 mt-2">
          <button type="submit" class="btn-primary w-full justify-center">Save Settings</button>
        </div>
      </form>
    </div>

    <!-- Instructions / Guide -->
    <div class="p-6 w-full lg:w-80 bg-slate-50 rounded-r-2xl">
      <h3 class="font-semibold text-slate-800 mb-3">API Keys & Integration</h3>
      <p class="text-xs text-slate-600 mb-5">
        Sensitive API keys must be configured in the <code>.env</code> file directly on the server for security reasons. They are not editable from this dashboard.
      </p>

      <div class="space-y-4 text-xs">
        <div>
          <span class="font-bold text-slate-700">Facebook App Settings</span>
          <p class="text-slate-500 mt-1">Webhook URL: <br><code class="block bg-slate-200 p-1.5 rounded mt-1 select-all break-all"><?= env('APP_URL') ?>/webhook</code></p>
          <p class="text-slate-500 mt-2">Verify Token: <br><code class="block bg-slate-200 p-1.5 rounded mt-1 select-all"><?= env('FB_WEBHOOK_VERIFY_TOKEN') ?></code></p>
        </div>
        <div class="border-t border-slate-200 pt-3">
          <span class="font-bold text-slate-700">Required .env Variables</span>
          <ul class="list-disc pl-4 text-slate-500 mt-1 space-y-1">
            <li>GEMINI_API_KEY</li>
            <li>GEMINI_MODEL (optional)</li>
            <li>FB_APP_ID</li>
            <li>FB_APP_SECRET</li>
            <li>FB_WEBHOOK_VERIFY_TOKEN</li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</div>

<?php include __DIR__ . '/../layouts/footer.php'; ?>
