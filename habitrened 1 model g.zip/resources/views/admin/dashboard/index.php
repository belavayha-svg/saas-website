<?php $pageTitle = 'Admin Dashboard'; include __DIR__ . '/../layouts/app.php'; ?>

<!-- Stats Grid -->
<div class="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4 mb-8">
  <?php $stats = [
    ['label'=>'Total Users',        'value'=>$totalUsers,      'color'=>'bg-indigo-500',  'icon'=>'👥'],
    ['label'=>'Active Subs',        'value'=>$activeSubs,      'color'=>'bg-green-500',   'icon'=>'✅'],
    ['label'=>'Expired Subs',       'value'=>$expiredSubs,     'color'=>'bg-slate-400',   'icon'=>'⏰'],
    ['label'=>'Total Revenue',      'value'=>'৳'.number_format($totalRevenue,0), 'color'=>'bg-emerald-500','icon'=>'💰'],
    ['label'=>'FB Pages Connected', 'value'=>$totalPages,      'color'=>'bg-blue-500',    'icon'=>'📘'],
    ['label'=>'AI Messages Used',   'value'=>number_format($totalAiMessages), 'color'=>'bg-purple-500','icon'=>'🤖'],
  ]; ?>
  <?php foreach ($stats as $s): ?>
  <div class="stat-card">
    <div class="flex items-center gap-2 mb-2">
      <span class="text-xl"><?= $s['icon'] ?></span>
      <span class="text-xs text-slate-500 font-medium"><?= $s['label'] ?></span>
    </div>
    <p class="text-2xl font-bold text-slate-800"><?= $s['value'] ?></p>
  </div>
  <?php endforeach; ?>
</div>

<?php if ($pendingPayments > 0): ?>
<div class="bg-amber-50 border border-amber-200 text-amber-800 px-4 py-3 rounded-xl text-sm flex items-center justify-between mb-6">
  <span>⚠️ <strong><?= $pendingPayments ?></strong> payment request(s) awaiting verification</span>
  <a href="/admin/payments?status=pending" class="bg-amber-500 hover:bg-amber-600 text-white px-4 py-1.5 rounded-lg text-xs font-medium">Review Now</a>
</div>
<?php endif; ?>

<div class="grid grid-cols-1 lg:grid-cols-2 gap-6">

  <!-- Recent Users -->
  <div class="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
    <div class="px-5 py-4 border-b border-slate-100 flex justify-between items-center">
      <h3 class="font-semibold text-slate-800">Recent Users</h3>
      <a href="/admin/users" class="text-xs text-indigo-600 hover:underline">View all</a>
    </div>
    <div class="divide-y divide-slate-50">
      <?php foreach (array_slice($recentUsers, 0, 6) as $u): ?>
      <div class="flex items-center justify-between px-5 py-3">
        <div class="flex items-center gap-2">
          <div class="h-8 w-8 rounded-full bg-indigo-100 flex items-center justify-center text-indigo-600 text-xs font-bold">
            <?= strtoupper(substr($u['name'], 0, 2)) ?>
          </div>
          <div>
            <p class="text-sm font-medium text-slate-800"><?= htmlspecialchars($u['name']) ?></p>
            <p class="text-xs text-slate-400"><?= htmlspecialchars($u['email']) ?></p>
          </div>
        </div>
        <span class="text-xs px-2 py-0.5 rounded-full <?= $u['status'] === 'active' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-600' ?>">
          <?= ucfirst($u['status']) ?>
        </span>
      </div>
      <?php endforeach; ?>
    </div>
  </div>

  <!-- Pending Payments -->
  <div class="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
    <div class="px-5 py-4 border-b border-slate-100 flex justify-between items-center">
      <h3 class="font-semibold text-slate-800">Pending Payments</h3>
      <a href="/admin/payments" class="text-xs text-indigo-600 hover:underline">View all</a>
    </div>
    <?php if (empty($recentPayments)): ?>
    <div class="px-5 py-8 text-center text-slate-400 text-sm">No pending payments 🎉</div>
    <?php else: ?>
    <div class="divide-y divide-slate-50">
      <?php foreach (array_slice($recentPayments, 0, 5) as $p): ?>
      <div class="flex items-center justify-between px-5 py-3">
        <div>
          <p class="text-sm font-medium text-slate-800"><?= htmlspecialchars($p['user_name']) ?></p>
          <p class="text-xs text-slate-400"><?= htmlspecialchars($p['plan_name']) ?> • <?= htmlspecialchars($p['payment_method']) ?></p>
          <p class="text-xs font-mono text-slate-500">TrxID: <?= htmlspecialchars($p['trx_id']) ?></p>
        </div>
        <div class="text-right">
          <p class="font-bold text-slate-800">৳<?= number_format($p['amount'], 0) ?></p>
          <div class="flex gap-1 mt-1">
            <form method="POST" action="/admin/payments/<?= $p['id'] ?>/approve">
              <?= \App\Core\CSRF::field() ?>
              <button class="btn-success">✓</button>
            </form>
          </div>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>
  </div>

</div>

<?php include __DIR__ . '/../layouts/footer.php'; ?>
