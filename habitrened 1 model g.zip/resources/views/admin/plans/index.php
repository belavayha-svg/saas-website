<?php $pageTitle = 'Plans & Payment Methods'; include __DIR__ . '/../layouts/app.php'; ?>

<div class="flex justify-between items-center mb-6">
  <h2 class="text-xl font-bold text-slate-800">Subscription Plans</h2>
  <a href="/admin/plans/create" class="btn-primary">
    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6"/></svg>
    Add Plan
  </a>
</div>

<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
  <?php foreach ($plans as $p): ?>
  <div class="bg-white rounded-2xl p-5 shadow-sm border <?= $p['status'] === 'active' ? 'border-slate-100' : 'border-red-100 bg-red-50/50' ?> flex flex-col">
    <div class="mb-3">
      <div class="flex justify-between items-start">
        <h3 class="font-bold text-slate-800 text-lg"><?= htmlspecialchars($p['plan_name']) ?></h3>
        <span class="text-xs px-2 py-0.5 rounded-full <?= $p['status'] === 'active' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-600' ?>"><?= ucfirst($p['status']) ?></span>
      </div>
      <p class="text-2xl font-bold text-indigo-600 mt-2">৳<?= number_format($p['price'], 0) ?> <span class="text-sm font-normal text-slate-400">/ <?= $p['duration_days'] ?>d</span></p>
    </div>
    <ul class="text-sm text-slate-600 space-y-1 mb-4 flex-1">
      <li>• <?= $p['ai_message_limit'] === -1 ? 'Unlimited' : number_format($p['ai_message_limit']) ?> AI Messages</li>
      <li>• <?= $p['page_limit'] === -1 ? 'Unlimited' : $p['page_limit'] ?> FB Pages</li>
    </ul>
    <div class="flex gap-2 pt-3 border-t border-slate-100">
      <button onclick="document.getElementById('editPlan<?= $p['id'] ?>').classList.toggle('hidden')" class="text-indigo-600 hover:bg-indigo-50 text-xs font-medium px-3 py-1.5 rounded-lg transition-colors">Edit</button>
      <form method="POST" action="/admin/plans/<?= $p['id'] ?>/delete" onsubmit="return confirm('Delete plan? Subscribed users will not be affected until expiration.')" class="inline">
        <?= \App\Core\CSRF::field() ?>
        <button type="submit" class="text-red-600 hover:bg-red-50 text-xs font-medium px-3 py-1.5 rounded-lg transition-colors">Delete</button>
      </form>
    </div>

    <!-- Edit Form (Hidden by default) -->
    <div id="editPlan<?= $p['id'] ?>" class="hidden mt-3 pt-3 border-t border-slate-200">
      <form method="POST" action="/admin/plans/<?= $p['id'] ?>/update" class="space-y-3">
        <?= \App\Core\CSRF::field() ?>
        <input type="text" name="plan_name" value="<?= htmlspecialchars($p['plan_name']) ?>" class="form-input text-xs" required>
        <div class="grid grid-cols-2 gap-2">
          <input type="number" name="price" value="<?= $p['price'] ?>" class="form-input text-xs" placeholder="Price">
          <input type="number" name="duration_days" value="<?= $p['duration_days'] ?>" class="form-input text-xs" placeholder="Days">
          <input type="number" name="ai_message_limit" value="<?= $p['ai_message_limit'] ?>" class="form-input text-xs" placeholder="AI Limit (-1 for unlim)">
          <input type="number" name="page_limit" value="<?= $p['page_limit'] ?>" class="form-input text-xs" placeholder="Page Limit">
        </div>
        <select name="status" class="form-input text-xs">
          <option value="active" <?= $p['status'] === 'active' ? 'selected' : '' ?>>Active</option>
          <option value="inactive" <?= $p['status'] === 'inactive' ? 'selected' : '' ?>>Inactive</option>
        </select>
        <button type="submit" class="btn-primary w-full justify-center text-xs py-1.5">Save Changes</button>
      </form>
    </div>
  </div>
  <?php endforeach; ?>
</div>

<hr class="border-slate-200 mb-8">

<div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
  <!-- Payment Methods List -->
  <div>
    <h2 class="text-xl font-bold text-slate-800 mb-4">Payment Methods</h2>
    <div class="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
      <?php if (empty($methods)): ?>
      <div class="p-5 text-center text-slate-500 text-sm">No payment methods configured.</div>
      <?php else: ?>
      <table class="w-full text-sm">
        <thead class="bg-slate-50">
          <tr>
            <th class="text-left px-5 py-3 text-slate-600 font-medium">Provider</th>
            <th class="text-left px-5 py-3 text-slate-600 font-medium">Account / Name</th>
            <th class="text-right px-5 py-3 text-slate-600 font-medium">Action</th>
          </tr>
        </thead>
        <tbody class="divide-y divide-slate-50">
          <?php foreach ($methods as $m): ?>
          <tr>
            <td class="px-5 py-3 font-semibold text-slate-800"><?= htmlspecialchars($m['method_name']) ?></td>
            <td class="px-5 py-3">
              <p class="font-mono text-slate-800"><?= htmlspecialchars($m['account_number']) ?></p>
              <p class="text-xs text-slate-400"><?= htmlspecialchars($m['account_holder']) ?></p>
            </td>
            <td class="px-5 py-3 text-right">
              <form method="POST" action="/admin/methods/<?= $m['id'] ?>/delete" onsubmit="return confirm('Remove payment method?')">
                <?= \App\Core\CSRF::field() ?>
                <button type="submit" class="text-red-600 hover:underline text-xs font-medium">Delete</button>
              </form>
            </td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
      <?php endif; ?>
    </div>
  </div>

  <!-- Add Payment Method -->
  <div>
    <h2 class="text-xl font-bold text-slate-800 mb-4">Add Payment Method</h2>
    <div class="bg-white rounded-2xl p-5 shadow-sm border border-slate-100">
      <form method="POST" action="/admin/methods" class="space-y-4">
        <?= \App\Core\CSRF::field() ?>
        <div>
          <label class="block text-sm font-medium text-slate-700 mb-1">Provider Name</label>
          <input type="text" name="method_name" class="form-input" placeholder="e.g. bKash, Nagad, Bank" required>
        </div>
        <div>
          <label class="block text-sm font-medium text-slate-700 mb-1">Account / Phone Number</label>
          <input type="text" name="account_number" class="form-input" required>
        </div>
        <div>
          <label class="block text-sm font-medium text-slate-700 mb-1">Account Name</label>
          <input type="text" name="account_holder" class="form-input" placeholder="e.g. Acme Corp" required>
        </div>
        <button type="submit" class="btn-primary">Add Method</button>
      </form>
    </div>
  </div>
</div>

<?php include __DIR__ . '/../layouts/footer.php'; ?>
