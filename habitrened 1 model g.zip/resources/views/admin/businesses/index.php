<?php $pageTitle = 'Business Overview'; include __DIR__ . '/../layouts/app.php'; ?>

<div class="flex justify-between items-center mb-6">
  <div>
    <h2 class="text-xl font-bold text-slate-800">Businesses / Tenants (<?= $total ?>)</h2>
    <p class="text-sm text-slate-500">View performance and impersonate tenant dashboards</p>
  </div>
</div>

<div class="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
  <table class="w-full text-sm">
    <thead class="bg-slate-50">
      <tr>
        <th class="text-left px-5 py-3 text-slate-600 font-medium">Business</th>
        <th class="text-left px-5 py-3 text-slate-600 font-medium">Owner</th>
        <th class="text-left px-5 py-3 text-slate-600 font-medium">Current Plan</th>
        <th class="text-left px-5 py-3 text-slate-600 font-medium">AI Usage</th>
        <th class="text-left px-5 py-3 text-slate-600 font-medium">Revenue (Total)</th>
        <th class="text-right px-5 py-3 text-slate-600 font-medium">Actions</th>
      </tr>
    </thead>
    <tbody class="divide-y divide-slate-50">
      <?php foreach ($businesses as $b): ?>
      <tr class="hover:bg-slate-50">
        <td class="px-5 py-4">
          <p class="font-bold text-slate-800 text-sm"><?= htmlspecialchars($b['business_name'] ?? 'Unnamed Business') ?></p>
          <span class="text-xs text-slate-500 mt-1 inline-block"><?= $b['total_pages'] ?> FB Pages</span>
        </td>
        <td class="px-5 py-4">
          <p class="font-medium text-slate-800 text-xs"><?= htmlspecialchars($b['user_name']) ?></p>
          <p class="text-xs text-slate-400"><?= htmlspecialchars($b['email']) ?></p>
        </td>
        <td class="px-5 py-4">
          <?php if ($b['plan_name']): ?>
          <span class="inline-block bg-indigo-50 text-indigo-700 text-xs font-semibold px-2 py-0.5 rounded mb-1"><?= htmlspecialchars($b['plan_name']) ?></span><br>
          <span class="text-xs <?= $b['sub_status'] === 'active' ? 'text-green-600' : 'text-red-500' ?>"><?= ucfirst($b['sub_status']) ?> (<?= $b['remaining_messages'] === -1 ? '∞' : $b['remaining_messages'] ?> msgs)</span>
          <?php else: ?>
          <span class="text-xs text-slate-400">Default Free</span>
          <?php endif; ?>
        </td>
        <td class="px-5 py-4">
          <p class="font-semibold text-slate-800 text-xs"><?= number_format($b['ai_messages_used'] ?? 0) ?> msgs</p>
        </td>
        <td class="px-5 py-4">
          <p class="font-bold text-emerald-600 text-sm">৳<?= number_format($b['total_business_revenue'] ?? 0, 0) ?></p>
          <p class="text-xs text-slate-400"><?= $b['total_orders'] ?> orders</p>
        </td>
        <td class="px-5 py-4 text-right">
          <form method="POST" action="/admin/businesses/<?= $b['user_id'] ?>/login-as">
            <?= \App\Core\CSRF::field() ?>
            <button class="bg-slate-800 hover:bg-slate-700 text-white text-xs px-3 py-1.5 rounded-lg font-medium transition-colors">Login As User</button>
          </form>
        </td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>

  <!-- Pagination -->
  <?php if ($total > $limit): ?>
  <div class="px-5 py-4 border-t border-slate-100 flex justify-between">
    <p class="text-xs text-slate-500">Page <?= $page ?></p>
    <div class="flex gap-2">
      <?php if ($page > 1): ?><a href="?page=<?= $page-1 ?>" class="text-xs px-3 py-1.5 bg-slate-100 rounded-lg hover:bg-slate-200">← Prev</a><?php endif; ?>
      <?php if ($page * $limit < $total): ?><a href="?page=<?= $page+1 ?>" class="text-xs px-3 py-1.5 bg-slate-100 rounded-lg hover:bg-slate-200">Next →</a><?php endif; ?>
    </div>
  </div>
  <?php endif; ?>
</div>

<?php include __DIR__ . '/../layouts/footer.php'; ?>
