<?php $pageTitle = 'User Management'; include __DIR__ . '/../layouts/app.php'; ?>

<div class="flex justify-between items-center mb-6">
  <h2 class="text-xl font-bold text-slate-800">Users (<?= $total ?>)</h2>
</div>

<div class="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
  <table class="w-full text-sm">
    <thead class="bg-slate-50">
      <tr>
        <th class="text-left px-5 py-3 text-slate-600 font-medium">User</th>
        <th class="text-left px-5 py-3 text-slate-600 font-medium">Business</th>
        <th class="text-left px-5 py-3 text-slate-600 font-medium">Role</th>
        <th class="text-left px-5 py-3 text-slate-600 font-medium">Status</th>
        <th class="text-left px-5 py-3 text-slate-600 font-medium">Joined</th>
        <th class="text-right px-5 py-3 text-slate-600 font-medium">Actions</th>
      </tr>
    </thead>
    <tbody class="divide-y divide-slate-50">
      <?php foreach ($users as $u): ?>
      <tr class="hover:bg-slate-50">
        <td class="px-5 py-3">
          <div class="flex items-center gap-2">
            <div class="h-8 w-8 rounded-full bg-indigo-100 flex items-center justify-center text-indigo-600 text-xs font-bold">
              <?= strtoupper(substr($u['name'], 0, 2)) ?>
            </div>
            <div>
              <p class="font-medium text-slate-800 text-xs"><?= htmlspecialchars($u['name']) ?></p>
              <p class="text-slate-400 text-xs"><?= htmlspecialchars($u['email']) ?></p>
            </div>
          </div>
        </td>
        <td class="px-5 py-3 text-xs text-slate-600"><?= htmlspecialchars($u['business_name'] ?? '—') ?></td>
        <td class="px-5 py-3">
          <span class="text-xs px-2 py-0.5 rounded-full <?= $u['role'] === 'super_admin' ? 'bg-rose-100 text-rose-700' : 'bg-slate-100 text-slate-600' ?>">
            <?= $u['role'] === 'super_admin' ? 'Super Admin' : 'Business' ?>
          </span>
        </td>
        <td class="px-5 py-3">
          <span class="text-xs px-2 py-0.5 rounded-full <?= $u['status'] === 'active' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-600' ?>">
            <?= ucfirst($u['status']) ?>
          </span>
        </td>
        <td class="px-5 py-3 text-xs text-slate-400"><?= date('M j, Y', strtotime($u['created_at'])) ?></td>
        <td class="px-5 py-3 text-right">
          <div class="flex items-center justify-end gap-1.5">
            <a href="/admin/users/<?= $u['id'] ?>/edit" class="text-indigo-600 hover:bg-indigo-50 text-xs font-medium px-2 py-1 rounded-lg transition-colors">Edit</a>
            <?php if ($u['status'] === 'active' && $u['role'] !== 'super_admin'): ?>
            <form method="POST" action="/admin/users/<?= $u['id'] ?>/suspend" class="inline">
              <?= \App\Core\CSRF::field() ?>
              <button type="submit" class="text-amber-600 hover:bg-amber-50 text-xs font-medium px-2 py-1 rounded-lg transition-colors" onclick="return confirm('Suspend this user?')">Suspend</button>
            </form>
            <?php elseif ($u['status'] === 'suspended'): ?>
            <form method="POST" action="/admin/users/<?= $u['id'] ?>/activate" class="inline">
              <?= \App\Core\CSRF::field() ?>
              <button type="submit" class="text-green-600 hover:bg-green-50 text-xs font-medium px-2 py-1 rounded-lg transition-colors">Activate</button>
            </form>
            <?php endif; ?>
            <?php if ($u['role'] !== 'super_admin'): ?>
            <form method="POST" action="/admin/users/<?= $u['id'] ?>/delete" class="inline">
              <?= \App\Core\CSRF::field() ?>
              <button type="submit" class="text-red-600 hover:bg-red-50 text-xs font-medium px-2 py-1 rounded-lg transition-colors" onclick="return confirm('Delete this user permanently?')">Delete</button>
            </form>
            <?php endif; ?>
          </div>
        </td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>

  <?php if ($total > $limit): ?>
  <div class="px-5 py-4 border-t border-slate-100 flex justify-between">
    <p class="text-xs text-slate-500">Page <?= $page ?></p>
    <div class="flex gap-2">
      <?php if ($page > 1): ?><a href="?page=<?= $page-1 ?>" class="text-xs px-3 py-1.5 bg-slate-100 rounded-lg hover:bg-slate-200">← Prev</a><?php endif; ?>
      <?php if ($page * $limit < $total): ?><a href="?page=<?= $page+1 ?>" class="text-xs px-3 py-1.5 bg-slate-100 rounded-lg hover:bg-slate-200">Next →</a><?php endif; ?>
    </div>
  </div>
  <?php endif; ?>
</div>

<?php include __DIR__ . '/../layouts/footer.php'; ?>
