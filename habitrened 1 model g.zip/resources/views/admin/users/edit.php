<?php $pageTitle = 'Edit User'; include __DIR__ . '/../layouts/app.php'; ?>

<div class="max-w-lg">
  <div class="flex items-center gap-3 mb-6">
    <a href="/admin/users" class="text-slate-400 hover:text-slate-600">
      <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/></svg>
    </a>
    <h2 class="text-xl font-bold text-slate-800">Edit User</h2>
  </div>
  <div class="bg-white rounded-2xl p-6 shadow-sm border border-slate-100">
    <form method="POST" action="/admin/users/<?= $user['id'] ?>/update" class="space-y-4">
      <?= \App\Core\CSRF::field() ?>
      <div>
        <label class="block text-sm font-medium text-slate-700 mb-1">Full Name</label>
        <input type="text" name="name" required class="form-input" value="<?= htmlspecialchars($user['name']) ?>">
      </div>
      <div>
        <label class="block text-sm font-medium text-slate-700 mb-1">Business Name</label>
        <input type="text" name="business_name" class="form-input" value="<?= htmlspecialchars($user['business_name'] ?? '') ?>">
      </div>
      <div>
        <label class="block text-sm font-medium text-slate-700 mb-1">Email</label>
        <input type="email" name="email" required class="form-input" value="<?= htmlspecialchars($user['email']) ?>">
      </div>
      <div>
        <label class="block text-sm font-medium text-slate-700 mb-1">New Password <span class="text-slate-400">(leave blank to keep)</span></label>
        <input type="password" name="password" class="form-input" placeholder="••••••••">
      </div>
      <div>
        <label class="block text-sm font-medium text-slate-700 mb-1">Status</label>
        <select name="status" class="form-input">
          <option value="active" <?= $user['status'] === 'active' ? 'selected' : '' ?>>Active</option>
          <option value="suspended" <?= $user['status'] === 'suspended' ? 'selected' : '' ?>>Suspended</option>
        </select>
      </div>
      <div class="flex gap-3 pt-2">
        <button type="submit" class="btn-primary">Save Changes</button>
        <a href="/admin/users" class="px-4 py-2 text-sm bg-slate-100 text-slate-600 rounded-lg hover:bg-slate-200">Cancel</a>
      </div>
    </form>
  </div>
</div>

<?php include __DIR__ . '/../layouts/footer.php'; ?>
