<?php $pageTitle = 'Order #'.$order['id']; include __DIR__ . '/../layouts/app.php'; ?>

<div class="max-w-4xl">
  <div class="flex items-center gap-3 mb-6">
    <a href="/orders" class="text-slate-400 hover:text-slate-600">
      <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/></svg>
    </a>
    <h2 class="text-xl font-bold text-slate-800">Order #<?= $order['id'] ?></h2>
    <span class="px-3 py-1 rounded-full text-xs font-medium <?= match($order['status']) {
      'delivered'  => 'bg-green-100 text-green-700',
      'cancelled'  => 'bg-red-100 text-red-700',
      'confirmed'  => 'bg-blue-100 text-blue-700',
      'processing' => 'bg-purple-100 text-purple-700',
      default      => 'bg-amber-100 text-amber-700'
    } ?>"><?= ucfirst($order['status']) ?></span>
  </div>

  <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">

    <!-- ── Left Column: Order Items + Payment ── -->
    <div class="lg:col-span-2 space-y-5">

      <!-- Order Items -->
      <div class="bg-white rounded-2xl p-6 shadow-sm border border-slate-100">
        <h3 class="font-semibold text-slate-800 mb-4">অর্ডার আইটেম</h3>
        <?php if (empty($items)): ?>
          <p class="text-slate-400 text-sm">এই অর্ডারে কোনো আইটেম নেই।</p>
        <?php else: ?>
        <div class="space-y-3">
          <?php foreach ($items as $item): ?>
          <div class="flex justify-between items-center py-3 border-b border-slate-50 last:border-0">
            <div>
              <p class="font-medium text-slate-800"><?= htmlspecialchars($item['product_name']) ?></p>
              <p class="text-xs text-slate-400">Qty: <?= $item['quantity'] ?></p>
            </div>
            <p class="font-semibold text-slate-800">৳<?= number_format($item['price'] * $item['quantity'], 2) ?></p>
          </div>
          <?php endforeach; ?>
        </div>
        <div class="mt-4 pt-4 border-t border-slate-100 space-y-1">
          <div class="flex justify-between text-sm text-slate-600">
            <span>সাবটোটাল</span>
            <span>৳<?= number_format($order['total_amount'], 2) ?></span>
          </div>
          <?php if ($order['delivery_charge'] > 0): ?>
          <div class="flex justify-between text-sm text-slate-600">
            <span>ডেলিভারি চার্জ</span>
            <span>৳<?= number_format($order['delivery_charge'], 2) ?></span>
          </div>
          <?php endif; ?>
          <div class="flex justify-between font-bold text-lg text-indigo-600 pt-2 border-t border-slate-100">
            <span>মোট</span>
            <span>৳<?= number_format($order['total_amount'] + $order['delivery_charge'], 2) ?></span>
          </div>
        </div>
        <?php endif; ?>
      </div>

      <!-- Payment Info Card -->
      <div class="bg-white rounded-2xl p-6 shadow-sm border border-slate-100">
        <h3 class="font-semibold text-slate-800 mb-4">পেমেন্ট তথ্য</h3>

        <?php
          $ptLabels = [
            'full'    => '✅ Full Payment (সম্পূর্ণ)',
            'partial' => '⚡ Partial (ডেলিভারি চার্জ)',
            'pending' => '⏳ Pending (পেমেন্ট বাকি)',
          ];
          $ptColors = [
            'full'    => 'bg-blue-100 text-blue-700',
            'partial' => 'bg-amber-100 text-amber-700',
            'pending' => 'bg-red-100 text-red-700',
          ];
          $amountSent = (float)($order['amount_sent'] ?? $order['paid_amount'] ?? 0);
          $due        = ($order['total_amount'] + $order['delivery_charge']) - $amountSent;
        ?>

        <!-- Summary Boxes -->
        <div class="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-5">
          <div class="bg-slate-50 rounded-xl p-3 text-center">
            <p class="text-xs text-slate-400 mb-1">পেমেন্ট ধরন</p>
            <span class="px-2 py-1 rounded-full text-xs font-medium <?= $ptColors[$order['payment_type']] ?? 'bg-slate-100 text-slate-600' ?>">
              <?= $ptLabels[$order['payment_type']] ?? $order['payment_type'] ?>
            </span>
          </div>
          <div class="bg-slate-50 rounded-xl p-3 text-center">
            <p class="text-xs text-slate-400 mb-1">Amount Sent</p>
            <p class="font-bold text-emerald-700">৳<?= number_format($amountSent, 2) ?></p>
          </div>
          <div class="bg-slate-50 rounded-xl p-3 text-center">
            <p class="text-xs text-slate-400 mb-1">বাকি পরিমাণ</p>
            <p class="font-bold <?= $due > 0 ? 'text-red-600' : 'text-green-600' ?>">৳<?= number_format(max(0, $due), 2) ?></p>
          </div>
          <div class="bg-slate-50 rounded-xl p-3 text-center">
            <p class="text-xs text-slate-400 mb-1">Transaction ID</p>
            <?php if (!empty($order['transaction_id']) && $order['transaction_id'] !== 'N/A'): ?>
              <p class="font-mono text-xs text-slate-700 break-all"><?= htmlspecialchars($order['transaction_id']) ?></p>
            <?php else: ?>
              <span class="text-slate-400 text-xs italic">দেওয়া হয়নি</span>
            <?php endif; ?>
          </div>
        </div>

        <!-- Update Payment Form -->
        <form method="POST" action="/orders/<?= $order['id'] ?>/payment" class="space-y-4 border-t border-slate-100 pt-4">
          <?= \App\Core\CSRF::field() ?>
          <p class="text-xs font-semibold text-slate-500 uppercase tracking-wide">পেমেন্ট তথ্য আপডেট করুন</p>

          <!-- Payment Type -->
          <div>
            <label class="block text-xs font-medium text-slate-600 mb-2">পেমেন্ট ধরন</label>
            <div class="flex gap-2 flex-wrap">
              <?php foreach (['full' => '✅ Full Payment', 'partial' => '⚡ Partial', 'pending' => '⏳ Pending'] as $val => $lbl): ?>
              <label class="flex items-center justify-center gap-1.5 px-3 py-2 border-2 rounded-lg cursor-pointer text-xs font-medium transition-colors
                <?= $order['payment_type'] === $val ? 'border-indigo-500 bg-indigo-50 text-indigo-700' : 'border-slate-200 hover:border-indigo-300' ?>">
                <input type="radio" name="payment_type" value="<?= $val ?>"
                  <?= $order['payment_type'] === $val ? 'checked' : '' ?> class="sr-only"
                  onchange="this.closest('form').querySelectorAll('label').forEach(l=>l.classList.remove('border-indigo-500','bg-indigo-50','text-indigo-700'));this.closest('label').classList.add('border-indigo-500','bg-indigo-50','text-indigo-700')">
                <?= $lbl ?>
              </label>
              <?php endforeach; ?>
            </div>
          </div>

          <div class="grid grid-cols-2 gap-3">
            <div>
              <label class="block text-xs font-medium text-slate-600 mb-1">ডেলিভারি চার্জ (৳)</label>
              <input type="number" name="delivery_charge" step="0.01" min="0"
                value="<?= htmlspecialchars($order['delivery_charge']) ?>"
                class="form-input text-sm">
            </div>
            <div>
              <label class="block text-xs font-medium text-slate-600 mb-1">Amount Sent (৳)</label>
              <input type="number" name="amount_sent" step="0.01" min="0"
                value="<?= htmlspecialchars($amountSent) ?>"
                class="form-input text-sm">
            </div>
          </div>

          <div>
            <label class="block text-xs font-medium text-slate-600 mb-1">Transaction ID</label>
            <input type="text" name="transaction_id"
              value="<?= htmlspecialchars($order['transaction_id'] ?? '') ?>"
              placeholder="যেমন: TRX1234567890"
              class="form-input text-sm font-mono">
          </div>

          <!-- Hidden: keep paid_amount in sync with amount_sent -->
          <input type="hidden" name="paid_amount" id="paid_amount_sync"
            value="<?= htmlspecialchars($amountSent) ?>">

          <button type="submit" class="btn-primary w-full justify-center text-sm">পেমেন্ট তথ্য আপডেট করুন</button>
        </form>
      </div>

    </div>

    <!-- ── Right Column: Customer + Status ── -->
    <div class="space-y-4">

      <!-- Customer Info -->
      <div class="bg-white rounded-2xl p-5 shadow-sm border border-slate-100">
        <h3 class="font-semibold text-slate-800 mb-4">কাস্টমার তথ্য</h3>

        <div class="mb-3">
          <p class="text-xs text-slate-400 mb-0.5">নাম</p>
          <p class="text-sm font-medium text-slate-800">
            <?= $order['customer_name'] ? htmlspecialchars($order['customer_name']) : '<span class="text-slate-400 italic text-xs">অজানা</span>' ?>
          </p>
        </div>

        <div class="mb-3">
          <p class="text-xs text-slate-400 mb-0.5">ফোন নম্বর</p>
          <?php if ($order['customer_phone']): ?>
          <a href="tel:<?= htmlspecialchars($order['customer_phone']) ?>"
            class="text-sm font-medium text-indigo-600 hover:underline flex items-center gap-1">
            <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"/></svg>
            <?= htmlspecialchars($order['customer_phone']) ?>
          </a>
          <?php else: ?>
          <span class="text-slate-400 italic text-xs">দেওয়া হয়নি</span>
          <?php endif; ?>
        </div>

        <div class="mb-3">
          <p class="text-xs text-slate-400 mb-0.5">ঠিকানা</p>
          <?php if ($order['customer_address']): ?>
          <p class="text-sm text-slate-700 bg-slate-50 px-3 py-2 rounded-lg">
            <?= nl2br(htmlspecialchars($order['customer_address'])) ?>
          </p>
          <?php else: ?>
          <span class="text-slate-400 italic text-xs">দেওয়া হয়নি</span>
          <?php endif; ?>
        </div>

        <div class="mb-3">
          <p class="text-xs text-slate-400 mb-0.5">Facebook Sender ID</p>
          <p class="text-xs font-mono text-slate-500 bg-slate-50 px-3 py-1.5 rounded"><?= htmlspecialchars($order['fb_sender_id']) ?></p>
        </div>

        <p class="text-xs text-slate-400">Page: <?= htmlspecialchars($order['page_id']) ?></p>
        <p class="text-xs text-slate-400 mt-1">Placed: <?= date('M j, Y g:ia', strtotime($order['created_at'])) ?></p>

        <?php if ($order['note']): ?>
        <div class="mt-3 p-3 bg-amber-50 rounded-lg text-xs text-amber-700">
          <strong>Note:</strong> <?= htmlspecialchars($order['note']) ?>
        </div>
        <?php endif; ?>
      </div>

      <!-- Update Customer Info Form -->
      <div class="bg-white rounded-2xl p-5 shadow-sm border border-slate-100">
        <h3 class="font-semibold text-slate-800 mb-3">কাস্টমার আপডেট</h3>
        <form method="POST" action="/orders/<?= $order['id'] ?>/payment" class="space-y-3">
          <?= \App\Core\CSRF::field() ?>
          <input type="hidden" name="payment_type"    value="<?= htmlspecialchars($order['payment_type']) ?>">
          <input type="hidden" name="delivery_charge" value="<?= htmlspecialchars($order['delivery_charge']) ?>">
          <input type="hidden" name="paid_amount"     value="<?= htmlspecialchars($amountSent) ?>">
          <input type="hidden" name="amount_sent"     value="<?= htmlspecialchars($amountSent) ?>">
          <input type="hidden" name="transaction_id"  value="<?= htmlspecialchars($order['transaction_id'] ?? '') ?>">
          <div>
            <label class="block text-xs font-medium text-slate-600 mb-1">নাম</label>
            <input type="text" name="customer_name" value="<?= htmlspecialchars($order['customer_name'] ?? '') ?>" class="form-input text-sm" placeholder="কাস্টমারের নাম">
          </div>
          <div>
            <label class="block text-xs font-medium text-slate-600 mb-1">ফোন নম্বর</label>
            <input type="text" name="customer_phone" value="<?= htmlspecialchars($order['customer_phone'] ?? '') ?>" class="form-input text-sm" placeholder="01XXXXXXXXX">
          </div>
          <div>
            <label class="block text-xs font-medium text-slate-600 mb-1">ঠিকানা</label>
            <textarea name="customer_address" rows="3" class="form-input text-sm" placeholder="সম্পূর্ণ ঠিকানা"><?= htmlspecialchars($order['customer_address'] ?? '') ?></textarea>
          </div>
          <button type="submit" class="w-full text-center py-2 px-4 bg-slate-800 text-white text-sm font-medium rounded-lg hover:bg-slate-700 transition-colors">আপডেট করুন</button>
        </form>
      </div>

      <!-- Update Status -->
      <div class="bg-white rounded-2xl p-5 shadow-sm border border-slate-100">
        <h3 class="font-semibold text-slate-800 mb-3">স্ট্যাটাস আপডেট</h3>
        <form method="POST" action="/orders/<?= $order['id'] ?>/status">
          <?= \App\Core\CSRF::field() ?>
          <select name="status" class="w-full border border-slate-200 rounded-lg px-3 py-2 text-sm mb-3 focus:outline-none focus:ring-2 focus:ring-indigo-500">
            <?php foreach (['pending','confirmed','processing','delivered','cancelled'] as $s): ?>
            <option value="<?= $s ?>" <?= $order['status'] === $s ? 'selected' : '' ?>><?= ucfirst($s) ?></option>
            <?php endforeach; ?>
          </select>
          <button type="submit" class="btn-primary w-full justify-center">স্ট্যাটাস আপডেট করুন</button>
        </form>
      </div>

    </div>
  </div>
</div>

<script>
// Keep paid_amount in sync with amount_sent input
document.querySelector('input[name="amount_sent"]')?.addEventListener('input', function() {
  const syncField = document.getElementById('paid_amount_sync');
  if (syncField) syncField.value = this.value;
});
</script>

<?php include __DIR__ . '/../layouts/footer.php'; ?>
