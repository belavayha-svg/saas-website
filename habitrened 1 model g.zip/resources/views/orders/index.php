<?php $pageTitle = 'Orders'; include __DIR__ . '/../layouts/app.php'; ?>

<style>
.quick-edit-dropdown {
  position: absolute;
  z-index: 50;
  background: white;
  border: 1px solid #e2e8f0;
  border-radius: 12px;
  box-shadow: 0 10px 40px rgba(0,0,0,0.12);
  padding: 12px;
  min-width: 220px;
  display: none;
}
.quick-edit-dropdown.open { display: block; }
.qe-wrap { position: relative; display: inline-block; }
.trx-badge {
  display: inline-block;
  font-family: monospace;
  font-size: 11px;
  background: #f1f5f9;
  color: #475569;
  border-radius: 6px;
  padding: 2px 7px;
  max-width: 130px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  vertical-align: middle;
}
</style>

<div class="flex flex-col gap-4 mb-6">
  <div class="flex justify-between items-center">
    <div>
      <h2 class="text-xl font-bold text-slate-800">Orders</h2>
      <p class="text-sm text-slate-500">All customer orders from Messenger</p>
    </div>
  </div>

  <!-- Status Filter -->
  <div class="flex flex-wrap gap-2 items-center">
    <span class="text-xs text-slate-400 font-medium mr-1">স্ট্যাটাস:</span>
    <?php foreach ([''=> 'সব','pending'=>'Pending','confirmed'=>'Confirmed','processing'=>'Processing','delivered'=>'Delivered','cancelled'=>'Cancelled'] as $s => $label): ?>
    <a href="/orders?status=<?= urlencode($s) ?>&payment_type=<?= urlencode($paymentType) ?>"
      class="text-xs px-3 py-1.5 rounded-full font-medium transition-colors <?= $status === $s ? 'bg-indigo-600 text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200' ?>">
      <?= $label ?>
    </a>
    <?php endforeach; ?>
  </div>

  <!-- Payment Type Filter -->
  <div class="flex flex-wrap gap-2 items-center">
    <span class="text-xs text-slate-400 font-medium mr-1">পেমেন্ট:</span>
    <?php foreach ([''=> 'সব', 'full'=>'✅ Full', 'partial'=>'⚡ Partial', 'pending'=>'⏳ Pending'] as $pt => $ptLabel): ?>
    <a href="/orders?status=<?= urlencode($status) ?>&payment_type=<?= urlencode($pt) ?>"
      class="text-xs px-3 py-1.5 rounded-full font-medium transition-colors <?= $paymentType === $pt ? 'bg-emerald-600 text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200' ?>">
      <?= $ptLabel ?>
    </a>
    <?php endforeach; ?>
  </div>
</div>

<?php if (empty($orders)): ?>
<div class="text-center py-20 bg-white rounded-2xl border border-slate-100">
  <div class="h-16 w-16 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-4">
    <svg class="w-8 h-8 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2"/></svg>
  </div>
  <p class="text-slate-500">কোনো অর্ডার পাওয়া যায়নি। ফিল্টার পরিবর্তন করুন অথবা নতুন অর্ডারের জন্য অপেক্ষা করুন।</p>
</div>
<?php else: ?>
<div class="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-visible">
  <table class="w-full text-sm">
    <thead class="bg-slate-50">
      <tr>
        <th class="text-left px-6 py-3 text-slate-600 font-medium">Order #</th>
        <th class="text-left px-6 py-3 text-slate-600 font-medium">কাস্টমার</th>
        <th class="text-left px-6 py-3 text-slate-600 font-medium">পরিমাণ</th>
        <th class="text-left px-6 py-3 text-slate-600 font-medium">পেমেন্ট</th>
        <th class="text-left px-6 py-3 text-slate-600 font-medium">Amount Sent</th>
        <th class="text-left px-6 py-3 text-slate-600 font-medium">Transaction ID</th>
        <th class="text-left px-6 py-3 text-slate-600 font-medium">স্ট্যাটাস <span class="text-indigo-400 text-xs font-normal">(ক্লিক করে এডিট)</span></th>
        <th class="text-left px-6 py-3 text-slate-600 font-medium">তারিখ</th>
        <th class="text-right px-6 py-3 text-slate-600 font-medium">Actions</th>
      </tr>
    </thead>
    <tbody class="divide-y divide-slate-50">
      <?php foreach ($orders as $o): ?>
      <tr class="hover:bg-slate-50 transition-colors">

        <!-- Order # -->
        <td class="px-6 py-4 font-semibold text-indigo-600">#<?= $o['id'] ?></td>

        <!-- Customer -->
        <td class="px-6 py-4">
          <?php if ($o['customer_name']): ?>
            <p class="font-medium text-slate-800 text-sm"><?= htmlspecialchars($o['customer_name']) ?></p>
            <?php if ($o['customer_phone']): ?>
            <p class="text-xs text-slate-400"><?= htmlspecialchars($o['customer_phone']) ?></p>
            <?php endif; ?>
          <?php else: ?>
            <span class="text-slate-400 font-mono text-xs"><?= htmlspecialchars($o['fb_sender_id']) ?></span>
          <?php endif; ?>
        </td>

        <!-- Amount -->
        <td class="px-6 py-4">
          <p class="font-semibold text-slate-800">৳<?= number_format($o['total_amount'], 2) ?></p>
          <?php if ($o['delivery_charge'] > 0): ?>
          <p class="text-xs text-slate-400">+ ৳<?= number_format($o['delivery_charge'], 2) ?> ডেলিভারি</p>
          <?php endif; ?>
        </td>

        <!-- Payment Type (read-only badge, no dropdown) -->
        <td class="px-6 py-4">
          <?php
            $ptMap = [
              'full'    => ['bg-blue-100 text-blue-700',   '✅ Full'],
              'partial' => ['bg-amber-100 text-amber-700', '⚡ Partial'],
              'pending' => ['bg-red-100 text-red-700',     '⏳ Pending'],
            ];
            [$ptClass, $ptText] = $ptMap[$o['payment_type']] ?? ['bg-slate-100 text-slate-500', $o['payment_type']];
          ?>
          <span class="px-2 py-1 rounded-full text-xs font-medium <?= $ptClass ?>">
            <?= $ptText ?>
          </span>
        </td>

        <!-- Amount Sent -->
        <td class="px-6 py-4">
          <?php $sent = (float)($o['amount_sent'] ?? $o['paid_amount'] ?? 0); ?>
          <?php if ($sent > 0): ?>
            <span class="font-semibold text-emerald-700">৳<?= number_format($sent, 2) ?></span>
          <?php else: ?>
            <span class="text-slate-400 text-xs">—</span>
          <?php endif; ?>
        </td>

        <!-- Transaction ID -->
        <td class="px-6 py-4">
          <?php if (!empty($o['transaction_id']) && $o['transaction_id'] !== 'N/A'): ?>
            <span class="trx-badge" title="<?= htmlspecialchars($o['transaction_id']) ?>">
              <?= htmlspecialchars($o['transaction_id']) ?>
            </span>
          <?php else: ?>
            <span class="text-slate-400 text-xs">—</span>
          <?php endif; ?>
        </td>

        <!-- STATUS quick-edit (kept) -->
        <td class="px-6 py-4">
          <div class="qe-wrap">
            <?php
              $statusColors = [
                'delivered'  => 'bg-green-100 text-green-700',
                'cancelled'  => 'bg-red-100 text-red-700',
                'confirmed'  => 'bg-blue-100 text-blue-700',
                'processing' => 'bg-purple-100 text-purple-700',
                'pending'    => 'bg-amber-100 text-amber-700',
              ];
              $sc = $statusColors[$o['status']] ?? 'bg-slate-100 text-slate-600';
            ?>
            <button type="button"
              onclick="toggleDropdown('stat-dd-<?= $o['id'] ?>')"
              class="px-2 py-1 rounded-full text-xs font-medium cursor-pointer <?= $sc ?> hover:opacity-80 transition">
              <?= ucfirst($o['status']) ?> ✎
            </button>

            <!-- Status dropdown -->
            <div id="stat-dd-<?= $o['id'] ?>" class="quick-edit-dropdown" style="top:28px;left:0">
              <form method="POST" action="/orders/<?= $o['id'] ?>/status" class="space-y-2">
                <?= \App\Core\CSRF::field() ?>
                <p class="text-xs font-semibold text-slate-500 mb-2">স্ট্যাটাস আপডেট</p>
                <select name="status" class="w-full border border-slate-200 rounded-lg px-2 py-1.5 text-xs focus:outline-none focus:ring-2 focus:ring-indigo-400">
                  <?php foreach (['pending','confirmed','processing','delivered','cancelled'] as $sv): ?>
                  <option value="<?= $sv ?>" <?= $o['status']===$sv ? 'selected' : '' ?>><?= ucfirst($sv) ?></option>
                  <?php endforeach; ?>
                </select>
                <div class="flex gap-1 pt-1">
                  <button type="submit" class="flex-1 bg-indigo-600 text-white text-xs py-1.5 rounded-lg hover:bg-indigo-700 transition">সেভ করুন</button>
                  <button type="button" onclick="closeDropdown('stat-dd-<?= $o['id'] ?>')" class="flex-1 bg-slate-100 text-slate-600 text-xs py-1.5 rounded-lg hover:bg-slate-200 transition">বাতিল</button>
                </div>
              </form>
            </div>
          </div>
        </td>

        <td class="px-6 py-4 text-slate-500 text-xs"><?= date('M j, Y g:ia', strtotime($o['created_at'])) ?></td>
        <td class="px-6 py-4 text-right">
          <a href="/orders/<?= $o['id'] ?>" class="text-indigo-600 hover:underline text-xs font-medium">View</a>
        </td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>

  <!-- Pagination -->
  <?php if ($total > $limit): ?>
  <div class="px-6 py-4 border-t border-slate-100 flex justify-between items-center">
    <p class="text-xs text-slate-500">Showing <?= count($orders) ?> of <?= $total ?></p>
    <div class="flex gap-2">
      <?php if ($page > 1): ?><a href="?status=<?= urlencode($status) ?>&payment_type=<?= urlencode($paymentType) ?>&page=<?= $page-1 ?>" class="text-xs px-3 py-1.5 bg-slate-100 rounded-lg hover:bg-slate-200">← Prev</a><?php endif; ?>
      <?php if ($page * $limit < $total): ?><a href="?status=<?= urlencode($status) ?>&payment_type=<?= urlencode($paymentType) ?>&page=<?= $page+1 ?>" class="text-xs px-3 py-1.5 bg-slate-100 rounded-lg hover:bg-slate-200">Next →</a><?php endif; ?>
    </div>
  </div>
  <?php endif; ?>
</div>
<?php endif; ?>

<script>
document.addEventListener('click', function(e) {
  if (!e.target.closest('.qe-wrap')) {
    document.querySelectorAll('.quick-edit-dropdown.open').forEach(d => d.classList.remove('open'));
  }
});

function toggleDropdown(id) {
  const dd = document.getElementById(id);
  const wasOpen = dd.classList.contains('open');
  document.querySelectorAll('.quick-edit-dropdown.open').forEach(d => d.classList.remove('open'));
  if (!wasOpen) dd.classList.add('open');
}

function closeDropdown(id) {
  document.getElementById(id).classList.remove('open');
}
</script>

<?php include __DIR__ . '/../layouts/footer.php'; ?>
