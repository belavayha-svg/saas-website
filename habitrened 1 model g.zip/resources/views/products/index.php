<?php $pageTitle = 'Products'; include __DIR__ . '/../layouts/app.php'; ?>

<div class="flex justify-between items-center mb-6">
  <div>
    <h2 class="text-xl font-bold text-slate-800">Your Products</h2>
    <p class="text-sm text-slate-500">Manage products your AI will offer to customers</p>
  </div>
  <div class="flex items-center gap-2">
    <!-- Delivery Rules Button -->
    <button onclick="openDeliveryModal()"
      class="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium text-emerald-700 bg-emerald-50 border border-emerald-200 rounded-lg hover:bg-emerald-100 transition-colors">
      <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
          d="M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-.553-.894L15 4m0 13V4m0 0L9 7"/>
      </svg>
      ডেলিভারি রুলস
    </button>
    <!-- Add Product Button -->
    <a href="/products/create" class="btn-primary">
      <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/></svg>
      Add Product
    </a>
  </div>
</div>

<?php if (empty($products)): ?>
<div class="text-center py-20 bg-white rounded-2xl border border-slate-100">
  <div class="h-16 w-16 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-4">
    <svg class="w-8 h-8 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10"/></svg>
  </div>
  <h3 class="text-slate-600 font-medium">No products yet</h3>
  <p class="text-slate-400 text-sm mt-1">Add your first product to start taking orders</p>
  <a href="/products/create" class="btn-primary mt-4 mx-auto w-fit">Add First Product</a>
</div>
<?php else: ?>
<div class="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
  <table class="w-full text-sm">
    <thead class="bg-slate-50">
      <tr>
        <th class="text-left px-6 py-3 text-slate-600 font-medium">Product</th>
        <th class="text-left px-6 py-3 text-slate-600 font-medium">Price</th>
        <th class="text-left px-6 py-3 text-slate-600 font-medium">Status</th>
        <th class="text-right px-6 py-3 text-slate-600 font-medium">Actions</th>
      </tr>
    </thead>
    <tbody class="divide-y divide-slate-50">
      <?php foreach ($products as $p): ?>
      <tr class="hover:bg-slate-50 transition-colors">
        <td class="px-6 py-4">
          <div class="flex items-center gap-3">
            <?php if ($p['image']): ?>
            <img src="<?= htmlspecialchars($p['image']) ?>" class="h-10 w-10 rounded-lg object-cover" alt="">
            <?php else: ?>
            <div class="h-10 w-10 bg-indigo-100 rounded-lg flex items-center justify-center text-indigo-500 text-xs font-bold">
              <?= strtoupper(substr($p['name'], 0, 2)) ?>
            </div>
            <?php endif; ?>
            <div>
              <p class="font-medium text-slate-800"><?= htmlspecialchars($p['name']) ?></p>
              <p class="text-slate-400 text-xs truncate max-w-xs"><?= htmlspecialchars(substr($p['description'] ?? '', 0, 60)) ?></p>
            </div>
          </div>
        </td>
        <td class="px-6 py-4 font-semibold text-slate-800">৳<?= number_format($p['price'], 2) ?></td>
        <td class="px-6 py-4">
          <span class="px-2 py-1 rounded-full text-xs font-medium <?= $p['status'] === 'active' ? 'bg-green-100 text-green-700' : 'bg-slate-100 text-slate-500' ?>">
            <?= ucfirst($p['status']) ?>
          </span>
        </td>
        <td class="px-6 py-4 text-right">
          <div class="flex items-center justify-end gap-2">
            <a href="/products/<?= $p['id'] ?>/edit" class="text-indigo-600 hover:text-indigo-700 text-xs font-medium px-3 py-1.5 rounded-lg hover:bg-indigo-50 transition-colors">Edit</a>
            <form method="POST" action="/products/<?= $p['id'] ?>/delete" onsubmit="return confirm('Delete this product?')">
              <?= \App\Core\CSRF::field() ?>
              <button type="submit" class="text-red-600 hover:text-red-700 text-xs font-medium px-3 py-1.5 rounded-lg hover:bg-red-50 transition-colors">Delete</button>
            </form>
          </div>
        </td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>
<?php endif; ?>

<!-- ===================== Delivery Rules Modal ===================== -->
<div id="deliveryModal" class="fixed inset-0 z-50 hidden items-center justify-center bg-black/50 backdrop-blur-sm">
  <div class="bg-white rounded-2xl shadow-2xl w-full max-w-xl mx-4 overflow-hidden">

    <!-- Modal Header -->
    <div class="flex items-center justify-between px-6 py-4 border-b border-slate-100 bg-emerald-50">
      <div class="flex items-center gap-2">
        <svg class="w-5 h-5 text-emerald-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
            d="M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-.553-.894L15 4m0 13V4m0 0L9 7"/>
        </svg>
        <h3 class="font-bold text-slate-800">ডেলিভারি চার্জের নিয়ম</h3>
      </div>
      <button onclick="closeDeliveryModal()" class="text-slate-400 hover:text-slate-600 transition-colors">
        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/>
        </svg>
      </button>
    </div>

    <!-- Rules List -->
    <div class="px-6 py-4 max-h-64 overflow-y-auto" id="rulesList">
      <p class="text-slate-400 text-sm text-center py-6" id="rulesEmpty">লোড হচ্ছে...</p>
    </div>

    <!-- Add New Rule Form -->
    <div class="px-6 py-4 border-t border-slate-100 bg-slate-50">
      <p class="text-xs font-semibold text-slate-500 mb-3 uppercase tracking-wide">নতুন এলাকা যোগ করুন</p>
      <div class="flex gap-2">
        <input type="text" id="newAreaName" placeholder="এলাকার নাম (যেমন: ঢাকা)" class="form-input flex-1 text-sm">
        <input type="number" id="newCharge" placeholder="চার্জ (৳)" min="0" step="0.01" class="form-input w-28 text-sm">
        <input type="text" id="newNote" placeholder="নোট (ঐচ্ছিক)" class="form-input w-32 text-sm">
        <button onclick="addRule()" class="px-4 py-2 bg-emerald-600 text-white text-sm font-medium rounded-lg hover:bg-emerald-700 transition-colors whitespace-nowrap">যোগ করুন</button>
      </div>
      <p id="ruleError" class="text-red-500 text-xs mt-2 hidden"></p>
    </div>

    <!-- Payment Methods Section -->
    <div class="flex items-center justify-between px-6 py-3 border-t border-b border-slate-100 bg-indigo-50 mt-4">
      <div class="flex items-center gap-2">
        <svg class="w-5 h-5 text-indigo-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>
        <h3 class="font-bold text-slate-800">পেমেন্ট মেথড (বিকাশ/নগদ)</h3>
      </div>
    </div>
    
    <!-- Payments List -->
    <div class="px-6 py-2 max-h-40 overflow-y-auto" id="paymentsList">
      <p class="text-slate-400 text-sm text-center py-4">লোড হচ্ছে...</p>
    </div>

    <!-- Add New Payment Form -->
    <div class="px-6 py-4 border-t border-slate-100 bg-slate-50">
      <p class="text-xs font-semibold text-slate-500 mb-3 uppercase tracking-wide">নতুন মেথড যোগ করুন</p>
      <div class="flex gap-2">
        <input type="text" id="newMethodName" placeholder="যেমন: bKash Personal" class="form-input flex-1 text-sm">
        <input type="text" id="newAccountNum" placeholder="অ্যাকাউন্ট নাম্বার" class="form-input flex-1 text-sm">
        <button onclick="addPayment()" class="px-4 py-2 bg-indigo-600 text-white text-sm font-medium rounded-lg hover:bg-indigo-700 transition-colors whitespace-nowrap">যোগ করুন</button>
      </div>
      <p id="paymentError" class="text-red-500 text-xs mt-2 hidden"></p>
    </div>
  </div>
</div>

<?php include __DIR__ . '/../layouts/footer.php'; ?>

<script>
const CSRF_TOKEN = '<?= \App\Core\CSRF::token() ?>';

async function openDeliveryModal() {
  document.getElementById('deliveryModal').classList.remove('hidden');
  document.getElementById('deliveryModal').classList.add('flex');
  await loadRules();
}

function closeDeliveryModal() {
  document.getElementById('deliveryModal').classList.add('hidden');
  document.getElementById('deliveryModal').classList.remove('flex');
}

// Close on backdrop click
document.getElementById('deliveryModal').addEventListener('click', function(e) {
  if (e.target === this) closeDeliveryModal();
});

async function loadRules() {
  const list = document.getElementById('rulesList');
  const pList = document.getElementById('paymentsList');
  list.innerHTML = '<p class="text-slate-400 text-sm text-center py-6">লোড হচ্ছে...</p>';
  pList.innerHTML = '<p class="text-slate-400 text-sm text-center py-4">লোড হচ্ছে...</p>';

  const res  = await fetch('/delivery-rules');
  const data = await res.json();

  if (!data.rules || data.rules.length === 0) {
    list.innerHTML = '<p class="text-slate-400 text-sm text-center py-6">এখনো কোনো ডেলিভারি রুলস নেই।</p>';
  } else {
    list.innerHTML = data.rules.map(r => `
      <div class="flex items-center gap-3 py-2.5 border-b border-slate-100 last:border-0" id="rule-${r.id}">
        <div class="flex-1">
          <p class="font-medium text-slate-800 text-sm">${escHtml(r.area_name)}</p>
          ${r.note ? `<p class="text-xs text-slate-400">${escHtml(r.note)}</p>` : ''}
        </div>
        <span class="font-bold text-emerald-700 text-sm">৳${parseFloat(r.charge).toFixed(2)}</span>
        <button onclick="deleteRule(${r.id})"
          class="text-red-400 hover:text-red-600 text-xs px-2 py-1 rounded hover:bg-red-50 transition-colors">মুছুন</button>
      </div>
    `).join('');
  }

  if (!data.payments || data.payments.length === 0) {
    pList.innerHTML = '<p class="text-slate-400 text-sm text-center py-4">কোনো পেমেন্ট মেথড যোগ করা হয়নি।</p>';
  } else {
    pList.innerHTML = data.payments.map(p => `
      <div class="flex items-center gap-3 py-2 border-b border-slate-100 last:border-0" id="payment-${p.id}">
        <div class="flex-1">
          <p class="font-medium text-slate-800 text-sm">${escHtml(p.method_name)}</p>
          <p class="text-xs font-mono text-slate-500">${escHtml(p.account_number)}</p>
        </div>
        <button onclick="deletePayment(${p.id})"
          class="text-red-400 hover:text-red-600 text-xs px-2 py-1 rounded hover:bg-red-50 transition-colors">মুছুন</button>
      </div>
    `).join('');
  }
}

async function addRule() {
  const areaName = document.getElementById('newAreaName').value.trim();
  const charge   = document.getElementById('newCharge').value.trim();
  const note     = document.getElementById('newNote').value.trim();
  const errEl    = document.getElementById('ruleError');

  if (!areaName) {
    errEl.textContent = 'এলাকার নাম দিন।';
    errEl.classList.remove('hidden');
    return;
  }
  errEl.classList.add('hidden');

  const fd = new FormData();
  fd.append('_csrf', CSRF_TOKEN);
  fd.append('area_name', areaName);
  fd.append('charge', charge || '0');
  fd.append('note', note);

  const res  = await fetch('/delivery-rules', { method: 'POST', body: fd });
  const data = await res.json();

  if (data.error) {
    errEl.textContent = data.error;
    errEl.classList.remove('hidden');
    return;
  }

  document.getElementById('newAreaName').value = '';
  document.getElementById('newCharge').value   = '';
  document.getElementById('newNote').value      = '';
  await loadRules();
}

async function deleteRule(id) {
  if (!confirm('এই রুলটি মুছে ফেলবেন?')) return;

  const fd = new FormData();
  fd.append('_csrf', CSRF_TOKEN);

  await fetch(`/delivery-rules/${id}/delete`, { method: 'POST', body: fd });
  await loadRules();
}

async function addPayment() {
  const methodName = document.getElementById('newMethodName').value.trim();
  const accountNum = document.getElementById('newAccountNum').value.trim();
  const errEl      = document.getElementById('paymentError');

  if (!methodName || !accountNum) {
    errEl.textContent = 'মেথড নাম এবং অ্যাকাউন্ট নাম্বার দিন।';
    errEl.classList.remove('hidden');
    return;
  }
  errEl.classList.add('hidden');

  const fd = new FormData();
  fd.append('_csrf', CSRF_TOKEN);
  fd.append('method_name', methodName);
  fd.append('account_number', accountNum);

  const res  = await fetch('/business-payments', { method: 'POST', body: fd });
  const data = await res.json();

  if (data.error) {
    errEl.textContent = data.error;
    errEl.classList.remove('hidden');
    return;
  }

  document.getElementById('newMethodName').value = '';
  document.getElementById('newAccountNum').value = '';
  await loadRules();
}

async function deletePayment(id) {
  if (!confirm('এই পেমেন্ট মেথড মুছে ফেলবেন?')) return;

  const fd = new FormData();
  fd.append('_csrf', CSRF_TOKEN);

  await fetch(`/business-payments/${id}/delete`, { method: 'POST', body: fd });
  await loadRules();
}

function escHtml(str) {
  return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}
</script>
