<?php $pageTitle = 'Edit Product'; include __DIR__ . '/../layouts/app.php'; ?>

<div class="max-w-2xl">
  <div class="flex items-center gap-3 mb-6">
    <a href="/products" class="text-slate-400 hover:text-slate-600">
      <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/></svg>
    </a>
    <h2 class="text-xl font-bold text-slate-800">Edit Product</h2>
  </div>

  <div class="bg-white rounded-2xl p-6 shadow-sm border border-slate-100">
    <form method="POST" action="/products/<?= $product['id'] ?>/update" enctype="multipart/form-data" class="space-y-4">
      <?= \App\Core\CSRF::field() ?>
      <?php
      $images = [];
      if (!empty($product['image'])) $images[] = ['col' => 'image', 'url' => $product['image']];
      if (!empty($product['image_2'])) $images[] = ['col' => 'image_2', 'url' => $product['image_2']];
      ?>
      <?php if (!empty($images)): ?>
      <div>
        <p class="text-sm text-slate-500 mb-2">Current Images</p>
        <div class="flex gap-4">
          <?php foreach ($images as $img): ?>
          <img src="<?= htmlspecialchars($img['url']) ?>" class="h-24 w-24 object-cover rounded-lg border border-slate-200" title="<?= $img['col'] ?>">
          <?php endforeach; ?>
        </div>
      </div>
      <?php endif; ?>
      <div class="mb-4">
        <label class="block text-sm font-medium text-slate-700 mb-1">Product Name *</label>
        <input type="text" name="name" required class="form-input" value="<?= htmlspecialchars($product['name']) ?>">
      </div>
      <div>
        <label class="block text-sm font-medium text-slate-700 mb-1">Description</label>
        <textarea name="description" rows="3" class="form-input"><?= htmlspecialchars($product['description'] ?? '') ?></textarea>
      </div>
      <div class="grid grid-cols-2 gap-4">
        <div>
          <label class="block text-sm font-medium text-slate-700 mb-1">Price (৳) *</label>
          <input type="number" name="price" step="0.01" min="0" required class="form-input" value="<?= $product['price'] ?>">
        </div>
        <div>
          <label class="block text-sm font-medium text-slate-700 mb-1">Status</label>
          <select name="status" class="form-input">
            <option value="active" <?= $product['status'] === 'active' ? 'selected' : '' ?>>Active</option>
            <option value="inactive" <?= $product['status'] === 'inactive' ? 'selected' : '' ?>>Inactive</option>
          </select>
        </div>
      </div>
      <div class="grid grid-cols-2 gap-4">
        <div>
          <label class="block text-sm font-medium text-slate-700 mb-1">Replace Main Image (optional)</label>
          <input type="file" name="image" accept="image/*" class="form-input p-2">
        </div>
        <div>
          <label class="block text-sm font-medium text-slate-700 mb-1">Replace Image 2 (optional)</label>
          <input type="file" name="image_2" accept="image/*" class="form-input p-2">
        </div>
      </div>
      <div class="flex gap-3 pt-2">
        <button type="submit" class="btn-primary">Update Product</button>
        <a href="/products" class="inline-flex items-center px-4 py-2 text-sm font-medium text-slate-600 bg-slate-100 rounded-lg hover:bg-slate-200 transition-colors">Cancel</a>
      </div>
    </form>
  </div>
</div>

<?php include __DIR__ . '/../layouts/footer.php'; ?>
