<?php $pageTitle = 'Add Product'; include __DIR__ . '/../layouts/app.php'; ?>

<div class="max-w-2xl">
  <div class="flex items-center gap-3 mb-6">
    <a href="/products" class="text-slate-400 hover:text-slate-600">
      <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/></svg>
    </a>
    <h2 class="text-xl font-bold text-slate-800">Add New Product</h2>
  </div>

  <div class="bg-white rounded-2xl p-6 shadow-sm border border-slate-100">
    <form method="POST" action="/products" enctype="multipart/form-data" class="space-y-4">
      <?= \App\Core\CSRF::field() ?>
      <div class="mb-4">
        <label class="block text-sm font-medium text-slate-700 mb-1">Product Name *</label>
        <input type="text" name="name" required class="form-input" placeholder="e.g. Chicken Burger">
      </div>
      <div>
        <label class="block text-sm font-medium text-slate-700 mb-1">Description</label>
        <textarea name="description" rows="3" class="form-input" placeholder="Describe your product..."></textarea>
      </div>
      <div class="grid grid-cols-2 gap-4">
        <div>
          <label class="block text-sm font-medium text-slate-700 mb-1">Price (৳) *</label>
          <input type="number" name="price" step="0.01" min="0" required class="form-input" placeholder="0.00">
        </div>
        <div>
          <label class="block text-sm font-medium text-slate-700 mb-1">Status</label>
          <select name="status" class="form-input">
            <option value="active">Active</option>
            <option value="inactive">Inactive</option>
          </select>
        </div>
      </div>
      <div class="grid grid-cols-2 gap-4">
        <div>
          <label class="block text-sm font-medium text-slate-700 mb-1">Main Image</label>
          <input type="file" name="image" accept="image/*" class="form-input p-2">
        </div>
        <div>
          <label class="block text-sm font-medium text-slate-700 mb-1">Image 2</label>
          <input type="file" name="image_2" accept="image/*" class="form-input p-2">
        </div>
      </div>
      <p class="text-xs text-slate-400 mt-1">Accepted: JPG, PNG, GIF, WebP. You can upload up to 2 images.</p>
      <div class="flex gap-3 pt-2">
        <button type="submit" class="btn-primary">Save Product</button>
        <a href="/products" class="inline-flex items-center px-4 py-2 text-sm font-medium text-slate-600 bg-slate-100 rounded-lg hover:bg-slate-200 transition-colors">Cancel</a>
      </div>
    </form>
  </div>
</div>

<?php include __DIR__ . '/../layouts/footer.php'; ?>
