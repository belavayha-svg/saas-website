<?php $pageTitle = 'Subscription'; include __DIR__ . '/../layouts/app.php'; ?>

<!-- Current Plan Banner -->
<?php if ($current): ?>
<div class="bg-gradient-to-r from-indigo-600 to-purple-600 rounded-2xl p-6 mb-6 text-white">
  <div class="flex justify-between items-start">
    <div>
      <p class="text-indigo-200 text-sm mb-1">Current Plan</p>
      <h2 class="text-2xl font-bold"><?= htmlspecialchars($current['plan_name']) ?></h2>
      <div class="flex gap-6 mt-3 text-sm">
        <div><p class="text-indigo-200">Expires</p><p class="font-semibold"><?= date('M j, Y', strtotime($current['end_date'])) ?></p></div>
        <div><p class="text-indigo-200">Messages Left</p><p class="font-semibold"><?= $current['remaining_messages'] === -1 ? '∞ Unlimited' : number_format($current['remaining_messages']) ?></p></div>
        <div><p class="text-indigo-200">Status</p><p class="font-semibold capitalize"><?= $current['status'] ?></p></div>
      </div>
    </div>
  </div>
</div>
<?php else: ?>
<div class="bg-amber-50 border border-amber-200 text-amber-800 px-4 py-4 rounded-xl mb-6 text-sm">
  ⚠️ You have no active subscription. Purchase a plan below to unlock full access.
</div>
<?php endif; ?>

<!-- Available Plans -->
<h3 class="text-lg font-bold text-slate-800 mb-4">Choose a Plan</h3>
<div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
  <?php foreach ($plans as $plan): ?>
  <?php $isPro = $plan['plan_name'] === 'Professional'; ?>
  <div class="bg-white rounded-2xl p-5 border <?= $isPro ? 'border-indigo-400 shadow-lg ring-2 ring-indigo-200' : 'border-slate-100 shadow-sm' ?> relative flex flex-col">
    <?php if ($isPro): ?>
    <div class="absolute -top-3 left-1/2 -translate-x-1/2 bg-indigo-600 text-white text-xs px-3 py-1 rounded-full font-semibold">Popular</div>
    <?php endif; ?>
    <div class="mb-4">
      <h4 class="font-bold text-slate-800 text-lg"><?= htmlspecialchars($plan['plan_name']) ?></h4>
      <div class="mt-2">
        <span class="text-3xl font-bold text-slate-900">৳<?= number_format($plan['price'], 0) ?></span>
        <span class="text-slate-400 text-sm">/ <?= $plan['duration_days'] ?> days</span>
      </div>
    </div>
    <ul class="space-y-2 text-sm text-slate-600 mb-5 flex-1">
      <li class="flex items-center gap-2">
        <svg class="w-4 h-4 text-green-500 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
        <?= $plan['ai_message_limit'] === -1 ? 'Unlimited' : number_format($plan['ai_message_limit']) ?> AI Messages
      </li>
      <li class="flex items-center gap-2">
        <svg class="w-4 h-4 text-green-500 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
        <?= $plan['page_limit'] === -1 ? 'Unlimited' : $plan['page_limit'] ?> Facebook Page<?= $plan['page_limit'] !== 1 ? 's' : '' ?>
      </li>
      <li class="flex items-center gap-2">
        <svg class="w-4 h-4 text-green-500 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>
        <?= $plan['duration_days'] ?> Days Access
      </li>
    </ul>
    <?php if ($plan['price'] == 0): ?>
    <span class="block text-center text-sm text-slate-400 bg-slate-50 rounded-xl py-2">Default Free Plan</span>
    <?php else: ?>
    <a href="/subscription/checkout/<?= $plan['id'] ?>"
      class="block text-center <?= $isPro ? 'bg-indigo-600 hover:bg-indigo-700' : 'bg-slate-800 hover:bg-slate-700' ?> text-white text-sm font-medium py-2.5 rounded-xl transition-colors">
      Get <?= htmlspecialchars($plan['plan_name']) ?>
    </a>
    <?php endif; ?>
  </div>
  <?php endforeach; ?>
</div>

<!-- Payment History -->
<?php if (!empty($history)): ?>
<h3 class="text-lg font-bold text-slate-800 mb-4">Subscription History</h3>
<div class="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
  <table class="w-full text-sm">
    <thead class="bg-slate-50">
      <tr>
        <th class="text-left px-6 py-3 text-slate-600 font-medium">Plan</th>
        <th class="text-left px-6 py-3 text-slate-600 font-medium">Start</th>
        <th class="text-left px-6 py-3 text-slate-600 font-medium">End</th>
        <th class="text-left px-6 py-3 text-slate-600 font-medium">Status</th>
      </tr>
    </thead>
    <tbody class="divide-y divide-slate-50">
      <?php foreach ($history as $h): ?>
      <tr>
        <td class="px-6 py-3 font-medium text-slate-800"><?= htmlspecialchars($h['plan_name']) ?></td>
        <td class="px-6 py-3 text-slate-500"><?= date('M j, Y', strtotime($h['start_date'])) ?></td>
        <td class="px-6 py-3 text-slate-500"><?= date('M j, Y', strtotime($h['end_date'])) ?></td>
        <td class="px-6 py-3">
          <span class="text-xs px-2 py-0.5 rounded-full <?= $h['status'] === 'active' ? 'bg-green-100 text-green-700' : 'bg-slate-100 text-slate-500' ?>"><?= ucfirst($h['status']) ?></span>
        </td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>
<?php endif; ?>

<?php include __DIR__ . '/../layouts/footer.php'; ?>
