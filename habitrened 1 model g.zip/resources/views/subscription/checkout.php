<?php $pageTitle = 'Checkout — '.$plan['plan_name']; include __DIR__ . '/../layouts/app.php'; ?>

<div class="max-w-2xl">
  <div class="flex items-center gap-3 mb-6">
    <a href="/subscription" class="text-slate-400 hover:text-slate-600">
      <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/></svg>
    </a>
    <h2 class="text-xl font-bold text-slate-800">Checkout — <?= htmlspecialchars($plan['plan_name']) ?> Plan</h2>
  </div>

  <!-- Plan Summary -->
  <div class="bg-gradient-to-r from-indigo-600 to-purple-700 rounded-2xl p-5 text-white mb-6">
    <div class="flex justify-between items-center">
      <div>
        <p class="text-indigo-200 text-sm">You're purchasing</p>
        <h3 class="text-xl font-bold"><?= htmlspecialchars($plan['plan_name']) ?> Plan</h3>
        <p class="text-indigo-200 text-sm mt-1">
          <?= $plan['ai_message_limit'] === -1 ? 'Unlimited' : number_format($plan['ai_message_limit']) ?> AI Messages •
          <?= $plan['page_limit'] === -1 ? 'Unlimited' : $plan['page_limit'] ?> Pages •
          <?= $plan['duration_days'] ?> Days
        </p>
      </div>
      <div class="text-right">
        <p class="text-3xl font-bold">৳<?= number_format($plan['price'], 0) ?></p>
      </div>
    </div>
  </div>

  <!-- Payment Methods Display -->
  <div class="bg-white rounded-2xl p-5 shadow-sm border border-slate-100 mb-6">
    <h3 class="font-semibold text-slate-800 mb-4">Payment Numbers</h3>
    <?php if (empty($methods)): ?>
    <p class="text-slate-400 text-sm">No payment methods configured. Contact admin.</p>
    <?php else: ?>
    <div class="space-y-3">
      <?php foreach ($methods as $m): ?>
      <div class="flex items-center justify-between bg-slate-50 rounded-xl px-4 py-3">
        <div>
          <p class="font-semibold text-slate-800"><?= htmlspecialchars($m['method_name']) ?></p>
          <p class="text-xs text-slate-500"><?= htmlspecialchars($m['account_holder']) ?></p>
        </div>
        <div class="text-right">
          <p class="font-mono font-bold text-slate-800 text-lg"><?= htmlspecialchars($m['account_number']) ?></p>
          <p class="text-xs text-slate-400">(Personal)</p>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
    <div class="mt-4 text-xs text-slate-500 bg-amber-50 border border-amber-200 rounded-xl p-3">
      💡 Send <strong>৳<?= number_format($plan['price'], 0) ?></strong> to any number above, then fill the form below with your Transaction ID.
    </div>
    <?php endif; ?>
  </div>

  <!-- Submit Payment Form -->
  <div class="bg-white rounded-2xl p-6 shadow-sm border border-slate-100">
    <h3 class="font-semibold text-slate-800 mb-4">Submit Payment Details</h3>
    <form method="POST" action="/subscription/payment" class="space-y-4">
      <?= \App\Core\CSRF::field() ?>
      <input type="hidden" name="plan_id" value="<?= $plan['id'] ?>">
      <input type="hidden" name="amount" value="<?= $plan['price'] ?>">
      <div>
        <label class="block text-sm font-medium text-slate-700 mb-1">Payment Method Used *</label>
        <select name="payment_method" required class="form-input">
          <option value="">Select method...</option>
          <?php foreach ($methods as $m): ?>
          <option value="<?= htmlspecialchars($m['method_name']) ?>"><?= htmlspecialchars($m['method_name']) ?> — <?= htmlspecialchars($m['account_number']) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div>
        <label class="block text-sm font-medium text-slate-700 mb-1">Transaction ID (TrxID) *</label>
        <input type="text" name="trx_id" required class="form-input" placeholder="e.g. 8N5XXXXXXX">
        <p class="text-xs text-slate-400 mt-1">Find this in your bKash/Nagad payment confirmation SMS</p>
      </div>
      <button type="submit" class="btn-primary w-full justify-center py-3">Submit Payment Request</button>
    </form>
  </div>
</div>

<?php include __DIR__ . '/../layouts/footer.php'; ?>
