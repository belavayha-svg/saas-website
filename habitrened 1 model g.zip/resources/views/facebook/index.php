<?php $pageTitle = 'Facebook Pages'; include __DIR__ . '/../layouts/app.php'; ?>

<div class="flex justify-between items-center mb-6">
  <div>
    <h2 class="text-xl font-bold text-slate-800">Facebook Pages</h2>
    <p class="text-sm text-slate-500">Connect your Facebook pages to receive Messenger orders</p>
  </div>
  <div class="flex items-center gap-2 text-xs text-slate-500">
    <span class="bg-slate-100 px-3 py-1.5 rounded-full">
      <?= $connected ?> / <?= $pageLimit === -1 ? '∞' : $pageLimit ?> pages connected
    </span>
  </div>
</div>

<!-- Connected Pages -->
<?php if (empty($pages)): ?>
<div class="text-center py-12 bg-white rounded-2xl border border-slate-100 mb-6">
  <div class="h-14 w-14 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-3">
    <svg class="w-7 h-7 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 8h10M7 12h4m1 8l-4-4H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-3l-4 4z"/></svg>
  </div>
  <p class="text-slate-600 font-medium">No pages connected</p>
  <p class="text-slate-400 text-sm mt-1">Connect a Facebook page to start the AI chatbot</p>
</div>
<?php else: ?>
<div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
  <?php foreach ($pages as $pg): ?>
  <div class="bg-white rounded-2xl p-5 shadow-sm border border-slate-100 flex items-center justify-between">
    <div class="flex items-center gap-3">
      <div class="h-12 w-12 bg-blue-600 rounded-xl flex items-center justify-center text-white text-lg font-bold">
        <?= strtoupper(substr($pg['page_name'], 0, 1)) ?>
      </div>
      <div>
        <p class="font-semibold text-slate-800"><?= htmlspecialchars($pg['page_name']) ?></p>
        <p class="text-xs text-slate-400 font-mono"><?= htmlspecialchars($pg['page_id']) ?></p>
        <span class="text-xs px-2 py-0.5 rounded-full <?= $pg['status'] === 'active' ? 'bg-green-100 text-green-700' : 'bg-slate-100 text-slate-500' ?>">
          <?= ucfirst($pg['status']) ?>
        </span>
      </div>
    </div>
    <form method="POST" action="/facebook/<?= $pg['id'] ?>/disconnect" onsubmit="return confirm('Disconnect this page?')">
      <?= \App\Core\CSRF::field() ?>
      <button type="submit" class="text-red-500 hover:text-red-700 text-xs font-medium px-3 py-1.5 rounded-lg hover:bg-red-50 transition-colors">Disconnect</button>
    </form>
  </div>
  <?php endforeach; ?>
</div>
<?php endif; ?>

<!-- Connect New Page -->
<?php if ($pageLimit === -1 || $connected < $pageLimit): ?>
<div class="bg-white rounded-2xl p-6 shadow-sm border border-slate-100">
  <h3 class="font-semibold text-slate-800 mb-4">Connect a New Page</h3>

  <div class="bg-blue-50 border border-blue-100 rounded-xl p-4 mb-5 text-sm text-blue-700">
    <strong>How to connect:</strong><br>
    1. Click "Login with Facebook" below<br>
    2. Grant permissions and get your User Access Token<br>
    3. Paste the token + select your page
  </div>

  <form method="POST" action="/facebook/connect" class="space-y-4">
    <?= \App\Core\CSRF::field() ?>
    <div>
      <label class="block text-sm font-medium text-slate-700 mb-1">User Access Token</label>
      <input type="text" name="user_access_token" id="user_access_token" required
        class="form-input font-mono text-xs" placeholder="Paste your Facebook User Access Token here">
    </div>
    <div>
      <label class="block text-sm font-medium text-slate-700 mb-1">Page ID</label>
      <input type="text" name="page_id" id="page_id" required class="form-input font-mono text-xs" placeholder="e.g. 123456789012345">
      <p class="text-xs text-slate-400 mt-1" id="page_help_text">Find your Page ID in the Facebook Page settings &gt; About section</p>
    </div>
    <button type="submit" class="btn-primary">Connect Page</button>
  </form>

  <?php if (!empty($fbAppId)): ?>
  <div class="mt-5 pt-5 border-t border-slate-100">
    <a href="https://www.facebook.com/v19.0/dialog/oauth?client_id=<?= htmlspecialchars($fbAppId) ?>&redirect_uri=<?= urlencode(env('APP_URL','').'/facebook') ?>&scope=pages_manage_metadata,pages_messaging,pages_read_engagement&response_type=token"
      class="inline-flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white text-sm font-medium px-4 py-2 rounded-lg transition-colors">
      <svg class="w-4 h-4" fill="currentColor" viewBox="0 0 24 24"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>
      Login with Facebook to get Token
    </a>
  </div>
  <?php endif; ?>
</div>
<?php else: ?>
<div class="bg-amber-50 border border-amber-200 text-amber-700 px-5 py-4 rounded-xl text-sm">
  ⚠️ You've reached your page limit (<?= $pageLimit ?>) on your current plan.
  <a href="/subscription" class="underline font-medium ml-1">Upgrade plan →</a>
</div>
<?php endif; ?>

<script>
document.addEventListener('DOMContentLoaded', () => {
    const tokenInput = document.getElementById('user_access_token');
    const pageIdInput = document.getElementById('page_id');
    const pageHelpText = document.getElementById('page_help_text');

    // Check URL hash for token
    const hash = window.location.hash;
    if (hash && hash.includes('access_token=')) {
        const params = new URLSearchParams(hash.substring(1));
        const token = params.get('access_token');
        if (token && tokenInput) {
            tokenInput.value = token;
            window.history.replaceState(null, null, window.location.pathname);
            fetchPages(token);
        }
    }

    // Listen for manual token paste
    if (tokenInput) {
        tokenInput.addEventListener('input', (e) => {
            const token = e.target.value.trim();
            if (token.length > 20) {
                fetchPages(token);
            }
        });
    }

    function fetchPages(token) {
        if (!token || !pageIdInput) return;
        
        const container = pageIdInput.parentElement;
        const previousHtml = container.innerHTML;
        
        container.innerHTML = '<label class="block text-sm font-medium text-slate-700 mb-1">Select Page</label><p class="text-sm text-slate-500">Loading pages...</p>';
        
        fetch('/api/facebook/pages?token=' + encodeURIComponent(token))
            .then(res => res.json())
            .then(data => {
                if (data.pages && data.pages.length > 0) {
                    let selectHtml = '<label class="block text-sm font-medium text-slate-700 mb-1">Select Page</label>';
                    selectHtml += '<select name="page_id" id="page_id" required class="form-input text-sm">';
                    selectHtml += '<option value="">-- Choose a Facebook Page --</option>';
                    data.pages.forEach(page => {
                        selectHtml += `<option value="${page.id}">${page.name} (${page.id})</option>`;
                    });
                    selectHtml += '</select>';
                    container.innerHTML = selectHtml;
                } else {
                    container.innerHTML = previousHtml;
                    document.getElementById('page_help_text').innerHTML = '<span class="text-red-500 font-medium">No pages found in your Facebook account.</span>';
                }
            })
            .catch(err => {
                container.innerHTML = previousHtml;
                console.error("Failed to fetch pages", err);
            });
    }
});
</script>

<?php include __DIR__ . '/../layouts/footer.php'; ?>
