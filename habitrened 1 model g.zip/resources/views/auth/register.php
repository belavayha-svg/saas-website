<?php use App\Core\CSRF; use App\Models\SystemSetting;
$settings = (new SystemSetting())->all();
$siteName = $settings['site_name'] ?? 'AI Chatbot SaaS';
?>
<!DOCTYPE html>
<html lang="en" class="h-full bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-900">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Register — <?= htmlspecialchars($siteName) ?></title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <style>body { font-family: 'Inter', sans-serif; }</style>
</head>
<body class="min-h-full flex items-center justify-center p-4">

  <div class="w-full max-w-md my-8">
    <div class="text-center mb-8">
      <div class="inline-flex items-center justify-center h-14 w-14 bg-indigo-600 rounded-xl mb-4 shadow-lg">
        <svg class="w-7 h-7 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20a6 6 0 0112 0v1H3v-1z"/></svg>
      </div>
      <h1 class="text-2xl font-bold text-white">Create Your Account</h1>
      <p class="text-slate-400 text-sm mt-1">Get started with a free plan — no credit card required</p>
    </div>

    <div class="bg-white/10 backdrop-blur-xl rounded-2xl p-8 border border-white/20 shadow-2xl">
      <?php if (!empty($error)): ?>
      <div class="bg-red-500/20 border border-red-400/40 text-red-300 px-4 py-3 rounded-lg text-sm mb-4">
        <?= htmlspecialchars($error) ?>
      </div>
      <?php endif; ?>

      <form method="POST" action="/register" class="space-y-4">
        <?= CSRF::field() ?>
        <div class="grid grid-cols-1 gap-4">
          <div>
            <label class="block text-sm font-medium text-slate-300 mb-1">Your Full Name</label>
            <input type="text" name="name" required placeholder="John Doe"
              class="w-full bg-white/10 border border-white/20 text-white placeholder-slate-400 rounded-lg px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500">
          </div>
          <div>
            <label class="block text-sm font-medium text-slate-300 mb-1">Business Name</label>
            <input type="text" name="business_name" placeholder="My Restaurant"
              class="w-full bg-white/10 border border-white/20 text-white placeholder-slate-400 rounded-lg px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500">
          </div>
          <div>
            <label class="block text-sm font-medium text-slate-300 mb-1">Email Address</label>
            <input type="email" name="email" required placeholder="you@business.com"
              class="w-full bg-white/10 border border-white/20 text-white placeholder-slate-400 rounded-lg px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500">
          </div>
          <div>
            <label class="block text-sm font-medium text-slate-300 mb-1">Password <span class="text-slate-500">(min 8 chars)</span></label>
            <input type="password" name="password" required placeholder="••••••••" minlength="8"
              class="w-full bg-white/10 border border-white/20 text-white placeholder-slate-400 rounded-lg px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500">
          </div>
          <div>
            <label class="block text-sm font-medium text-slate-300 mb-1">Confirm Password</label>
            <input type="password" name="password_confirm" required placeholder="••••••••"
              class="w-full bg-white/10 border border-white/20 text-white placeholder-slate-400 rounded-lg px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500">
          </div>
        </div>
        <div class="bg-indigo-500/10 border border-indigo-400/30 rounded-lg p-3 text-xs text-indigo-300">
          🎁 You'll get a <strong>Free Plan</strong> with 100 AI messages and 1 Facebook page connection.
        </div>
        <button type="submit"
          class="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-semibold py-3 rounded-lg transition-all duration-200 text-sm">
          Create Account
        </button>
      </form>

      <p class="text-center text-slate-400 text-sm mt-6">
        Already have an account?
        <a href="/login" class="text-indigo-400 hover:text-indigo-300 font-medium">Sign in</a>
      </p>
    </div>
  </div>
</body>
</html>
