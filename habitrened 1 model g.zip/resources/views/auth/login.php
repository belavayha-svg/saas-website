<?php use App\Core\CSRF; use App\Models\SystemSetting;
$settings = (new SystemSetting())->all();
$siteName = $settings['site_name'] ?? 'AI Chatbot SaaS';
?>
<!DOCTYPE html>
<html lang="en" class="h-full bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-900">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login — <?= htmlspecialchars($siteName) ?></title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <style>body { font-family: 'Inter', sans-serif; }</style>
</head>
<body class="h-full flex items-center justify-center p-4">

  <div class="w-full max-w-md">
    <!-- Logo -->
    <div class="text-center mb-8">
      <div class="inline-flex items-center justify-center h-16 w-16 bg-indigo-600 rounded-2xl mb-4 shadow-lg">
        <svg class="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"/></svg>
      </div>
      <h1 class="text-2xl font-bold text-white"><?= htmlspecialchars($siteName) ?></h1>
      <p class="text-slate-400 text-sm mt-1">Sign in to your business account</p>
    </div>

    <!-- Card -->
    <div class="bg-white/10 backdrop-blur-xl rounded-2xl p-8 border border-white/20 shadow-2xl">
      <?php if (!empty($error)): ?>
      <div class="bg-red-500/20 border border-red-400/40 text-red-300 px-4 py-3 rounded-lg text-sm mb-4">
        <?= htmlspecialchars($error) ?>
      </div>
      <?php endif; ?>
      <?php if (!empty($success)): ?>
      <div class="bg-green-500/20 border border-green-400/40 text-green-300 px-4 py-3 rounded-lg text-sm mb-4">
        <?= htmlspecialchars($success) ?>
      </div>
      <?php endif; ?>

      <form method="POST" action="/login" class="space-y-4">
        <?= CSRF::field() ?>
        <div>
          <label class="block text-sm font-medium text-slate-300 mb-1">Email Address</label>
          <input type="email" name="email" required placeholder="you@business.com"
            class="w-full bg-white/10 border border-white/20 text-white placeholder-slate-400 rounded-lg px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500">
        </div>
        <div>
          <label class="block text-sm font-medium text-slate-300 mb-1">Password</label>
          <input type="password" name="password" required placeholder="••••••••"
            class="w-full bg-white/10 border border-white/20 text-white placeholder-slate-400 rounded-lg px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500">
        </div>

        <!-- Remember Me -->
        <div class="flex items-center gap-3 pt-1">
          <label class="relative inline-flex items-center cursor-pointer select-none">
            <input type="checkbox" name="remember_me" value="1" id="remember_me" checked
              class="sr-only peer">
            <div class="w-10 h-5 bg-white/20 peer-focus:ring-2 peer-focus:ring-indigo-500 rounded-full peer
                        peer-checked:bg-indigo-500 transition-all duration-200
                        after:content-[''] after:absolute after:top-0.5 after:left-0.5
                        after:bg-white after:rounded-full after:h-4 after:w-4
                        after:transition-all peer-checked:after:translate-x-5">
            </div>
            <span class="ml-2 text-sm text-slate-300">আমাকে মনে রাখুন <span class="text-slate-500 text-xs">(30 দিন)</span></span>
          </label>
        </div>

        <button type="submit"
          class="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-semibold py-3 rounded-lg transition-all duration-200 text-sm mt-2">
          Sign In →
        </button>
      </form>

      <p class="text-center text-slate-400 text-sm mt-6">
        Don't have an account?
        <a href="/register" class="text-indigo-400 hover:text-indigo-300 font-medium">Register free</a>
      </p>
    </div>
  </div>

</body>
</html>
