<?php $pageTitle = 'Reports'; include __DIR__ . '/../layouts/app.php'; ?>

<div class="flex justify-between items-center mb-6">
  <h2 class="text-xl font-bold text-slate-800">Business Reports</h2>
  <div class="flex gap-2">
    <?php foreach (['day'=>'Today','week'=>'This Week','month'=>'This Month'] as $k => $label): ?>
    <a href="/reports?period=<?= $k ?>"
      class="text-xs px-3 py-2 rounded-lg font-medium transition-colors <?= $period === $k ? 'bg-indigo-600 text-white' : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-50' ?>">
      <?= $label ?>
    </a>
    <?php endforeach; ?>
  </div>
</div>

<!-- Order Stats Grid -->
<div class="grid grid-cols-2 sm:grid-cols-5 gap-3 mb-6">
  <?php $statDef = [
    ['label'=>'Total Orders','key'=>'total','color'=>'indigo'],
    ['label'=>'Pending','key'=>'pending','color'=>'amber'],
    ['label'=>'Confirmed','key'=>'confirmed','color'=>'blue'],
    ['label'=>'Delivered','key'=>'delivered','color'=>'green'],
    ['label'=>'Cancelled','key'=>'cancelled','color'=>'red'],
  ]; ?>
  <?php foreach ($statDef as $s): ?>
  <div class="bg-white rounded-2xl p-4 shadow-sm border border-slate-100">
    <p class="text-xs text-slate-500"><?= $s['label'] ?></p>
    <p class="text-2xl font-bold text-slate-800 mt-1"><?= $orderStats[$s['key']] ?></p>
  </div>
  <?php endforeach; ?>
</div>

<!-- Revenue Card -->
<div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
  <div class="bg-gradient-to-br from-indigo-600 to-purple-700 rounded-2xl p-6 text-white">
    <p class="text-indigo-200 text-sm">Revenue (<?= ucfirst($period) ?>)</p>
    <p class="text-4xl font-bold mt-1">৳<?= number_format($revenue, 2) ?></p>
    <p class="text-indigo-200 text-sm mt-2"><?= count($dailyOrders) ?> days of data</p>
  </div>
  <div class="bg-white rounded-2xl p-6 shadow-sm border border-slate-100">
    <p class="text-sm font-semibold text-slate-700 mb-3">AI Messages Used (Last 30 Days)</p>
    <?php if (empty($aiStats)): ?>
    <p class="text-slate-400 text-sm">No AI usage data yet.</p>
    <?php else: ?>
    <div class="space-y-1">
      <?php $max = max(array_column($aiStats, 'total') ?: [1]); ?>
      <?php foreach (array_slice($aiStats, -7) as $stat): ?>
      <div class="flex items-center gap-2 text-xs">
        <span class="w-16 text-slate-400"><?= date('M j', strtotime($stat['date'])) ?></span>
        <div class="flex-1 bg-slate-100 rounded-full h-2">
          <div class="bg-indigo-500 h-2 rounded-full" style="width:<?= round(($stat['total']/$max)*100) ?>%"></div>
        </div>
        <span class="w-8 text-right text-slate-600"><?= $stat['total'] ?></span>
      </div>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>
  </div>
</div>

<!-- Daily Orders Table -->
<?php if (!empty($dailyOrders)): ?>
<div class="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
  <div class="px-6 py-4 border-b border-slate-100">
    <h3 class="font-semibold text-slate-800">Daily Breakdown</h3>
  </div>
  <table class="w-full text-sm">
    <thead class="bg-slate-50">
      <tr>
        <th class="text-left px-6 py-3 text-slate-600 font-medium">Date</th>
        <th class="text-left px-6 py-3 text-slate-600 font-medium">Orders</th>
        <th class="text-left px-6 py-3 text-slate-600 font-medium">Revenue</th>
      </tr>
    </thead>
    <tbody class="divide-y divide-slate-50">
      <?php foreach (array_reverse($dailyOrders) as $day): ?>
      <tr class="hover:bg-slate-50">
        <td class="px-6 py-3 text-slate-700"><?= date('D, M j Y', strtotime($day['date'])) ?></td>
        <td class="px-6 py-3 font-medium text-slate-800"><?= $day['count'] ?></td>
        <td class="px-6 py-3 font-semibold text-slate-800">৳<?= number_format($day['revenue'], 2) ?></td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>
<?php endif; ?>

<?php include __DIR__ . '/../layouts/footer.php'; ?>
