<?php $pageTitle = 'Dashboard'; include __DIR__ . '/../layouts/app.php'; ?>

<!-- Subscription Alert -->
<?php if (!$subscription): ?>
<div class="bg-amber-50 border border-amber-200 text-amber-800 px-4 py-3 rounded-xl text-sm flex items-center justify-between mb-6">
  <span>⚠️ No active subscription. Get started with a plan.</span>
  <a href="/subscription" class="bg-amber-500 hover:bg-amber-600 text-white px-4 py-1.5 rounded-lg text-xs font-medium">View Plans</a>
</div>
<?php elseif ($subscription['remaining_messages'] !== -1 && $subscription['remaining_messages'] < 50): ?>
<div class="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-xl text-sm flex items-center justify-between mb-6">
  <span>🔔 Only <strong><?= $subscription['remaining_messages'] ?></strong> AI messages remaining!</span>
  <a href="/subscription" class="bg-red-500 hover:bg-red-600 text-white px-4 py-1.5 rounded-lg text-xs font-medium">Upgrade</a>
</div>
<?php endif; ?>

<!-- Stats Grid -->
<div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">

  <div class="stat-card">
    <div class="flex items-center gap-3 mb-1">
      <div class="h-10 w-10 bg-indigo-100 rounded-xl flex items-center justify-center">
        <svg class="w-5 h-5 text-indigo-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2"/></svg>
      </div>
      <span class="text-sm text-slate-500 font-medium">Total Orders</span>
    </div>
    <p class="text-3xl font-bold text-slate-800 mt-2"><?= $totalOrders ?></p>
    <p class="text-xs text-amber-600 mt-1"><?= $pendingOrders ?> pending</p>
  </div>

  <div class="stat-card">
    <div class="flex items-center gap-3 mb-1">
      <div class="h-10 w-10 bg-green-100 rounded-xl flex items-center justify-center">
        <svg class="w-5 h-5 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
      </div>
      <span class="text-sm text-slate-500 font-medium">Revenue (Month)</span>
    </div>
    <p class="text-3xl font-bold text-slate-800 mt-2">৳<?= number_format($revenueMonth, 2) ?></p>
    <p class="text-xs text-slate-400 mt-1">৳<?= number_format($revenueDay, 0) ?> today</p>
  </div>

  <div class="stat-card">
    <div class="flex items-center gap-3 mb-1">
      <div class="h-10 w-10 bg-purple-100 rounded-xl flex items-center justify-center">
        <svg class="w-5 h-5 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10"/></svg>
      </div>
      <span class="text-sm text-slate-500 font-medium">Products</span>
    </div>
    <p class="text-3xl font-bold text-slate-800 mt-2"><?= $totalProducts ?></p>
    <a href="/products/create" class="text-xs text-indigo-600 mt-1 hover:underline">+ Add product</a>
  </div>

  <div class="stat-card">
    <div class="flex items-center gap-3 mb-1">
      <div class="h-10 w-10 bg-blue-100 rounded-xl flex items-center justify-center">
        <svg class="w-5 h-5 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"/></svg>
      </div>
      <span class="text-sm text-slate-500 font-medium">AI Messages Used</span>
    </div>
    <p class="text-3xl font-bold text-slate-800 mt-2"><?= number_format($aiMessagesUsed) ?></p>
    <?php if ($subscription): ?>
    <p class="text-xs text-slate-400 mt-1">
      <?= $subscription['remaining_messages'] === -1 ? 'Unlimited remaining' : number_format($subscription['remaining_messages']) . ' remaining' ?>
    </p>
    <?php endif; ?>
  </div>

</div>

<!-- Subscription Info + Connected Pages -->
<div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">

  <!-- Subscription Card -->
  <div class="bg-gradient-to-br from-indigo-600 to-purple-700 rounded-2xl p-6 text-white">
    <div class="flex justify-between items-start mb-4">
      <div>
        <p class="text-indigo-200 text-sm">Current Plan</p>
        <h3 class="text-2xl font-bold"><?= htmlspecialchars($subscription['plan_name'] ?? 'No Plan') ?></h3>
      </div>
      <span class="bg-white/20 text-white text-xs px-3 py-1 rounded-full">
        <?= $subscription ? 'Active' : 'Inactive' ?>
      </span>
    </div>
    <?php if ($subscription): ?>
    <div class="grid grid-cols-2 gap-3 text-sm">
      <div><p class="text-indigo-200">Expires</p><p class="font-semibold"><?= date('M j, Y', strtotime($subscription['end_date'])) ?></p></div>
      <div><p class="text-indigo-200">Messages Left</p><p class="font-semibold"><?= $subscription['remaining_messages'] === -1 ? '∞ Unlimited' : number_format($subscription['remaining_messages']) ?></p></div>
    </div>
    <?php endif; ?>
    <a href="/subscription" class="mt-4 inline-block bg-white/20 hover:bg-white/30 text-white text-sm px-4 py-2 rounded-lg transition-colors">Manage Subscription →</a>
  </div>

  <!-- Recent Orders -->
  <div class="bg-white rounded-2xl p-6 shadow-sm border border-slate-100">
    <div class="flex justify-between items-center mb-4">
      <h3 class="font-semibold text-slate-800">Recent Orders</h3>
      <a href="/orders" class="text-xs text-indigo-600 hover:underline">View all</a>
    </div>
    <?php if (empty($recentOrders)): ?>
    <p class="text-slate-400 text-sm">No orders yet. Connect your Facebook page to start receiving orders.</p>
    <?php else: ?>
    <div class="space-y-2">
      <?php foreach ($recentOrders as $order): ?>
      <div class="flex items-center justify-between py-2 border-b border-slate-50 last:border-0">
        <div>
          <p class="text-sm font-medium text-slate-700">#<?= $order['id'] ?> — <?= htmlspecialchars($order['fb_sender_id']) ?></p>
          <p class="text-xs text-slate-400"><?= date('M j, g:ia', strtotime($order['created_at'])) ?></p>
        </div>
        <div class="flex items-center gap-2">
          <span class="text-sm font-semibold text-slate-800">৳<?= number_format($order['total_amount'], 0) ?></span>
          <span class="text-xs px-2 py-0.5 rounded-full <?= match($order['status']) {
            'delivered' => 'bg-green-100 text-green-700',
            'cancelled' => 'bg-red-100 text-red-700',
            'confirmed' => 'bg-blue-100 text-blue-700',
            default     => 'bg-amber-100 text-amber-700'
          } ?>"><?= ucfirst($order['status']) ?></span>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>
  </div>

</div>

<?php include __DIR__ . '/../layouts/footer.php'; ?>
