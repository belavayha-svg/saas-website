<?php
$pageTitle = 'Conversations';
require_once __DIR__ . '/../layouts/app.php';
?>

<div class="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
  <div class="p-6 border-b border-slate-200">
    <h2 class="text-lg font-semibold text-slate-800">Recent Customer Messages</h2>
    <p class="text-sm text-slate-500 mt-1">View Messenger chats handled by your AI assistant.</p>
  </div>

  <div class="overflow-x-auto">
    <table class="w-full text-left border-collapse">
      <thead>
        <tr class="bg-slate-50 text-slate-500 text-xs uppercase tracking-wider">
          <th class="px-6 py-4 font-medium">Customer (Sender ID)</th>
          <th class="px-6 py-4 font-medium">Page Name</th>
          <th class="px-6 py-4 font-medium">Last Message</th>
          <th class="px-6 py-4 font-medium">Time</th>
          <th class="px-6 py-4 font-medium text-right">Action</th>
        </tr>
      </thead>
      <tbody class="divide-y divide-slate-200 text-sm">
        <?php if (empty($conversations)): ?>
        <tr>
          <td colspan="5" class="px-6 py-8 text-center text-slate-500 bg-slate-50">
            No conversations found yet. Messages will appear here when customers message your connected pages.
          </td>
        </tr>
        <?php else: ?>
          <?php foreach ($conversations as $c): ?>
          <tr class="hover:bg-slate-50 transition-colors">
            <td class="px-6 py-4 whitespace-nowrap text-slate-800 font-medium">
              <?= htmlspecialchars($c['fb_sender_id']) ?>
            </td>
            <td class="px-6 py-4 whitespace-nowrap text-slate-600">
              <?= htmlspecialchars($c['page_name'] ?? 'Unknown Page') ?>
            </td>
            <td class="px-6 py-4 text-slate-600 max-w-xs truncate">
              <?= htmlspecialchars($c['last_message'] ?? 'No messages') ?>
            </td>
            <td class="px-6 py-4 whitespace-nowrap text-slate-500 text-xs">
              <?= $c['last_message_time'] ? date('M j, Y g:i A', strtotime($c['last_message_time'])) : 'N/A' ?>
            </td>
            <td class="px-6 py-4 whitespace-nowrap text-right">
              <a href="/conversations/<?= $c['id'] ?>" class="text-indigo-600 hover:text-indigo-800 font-medium text-xs">View Chat</a>
            </td>
          </tr>
          <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require_once __DIR__ . '/../layouts/footer.php'; ?>
