<?php
$pageTitle = 'Chat Details';
require_once __DIR__ . '/../layouts/app.php';
$convId = $conversation['id'];
?>

<?php
$flash_success = \App\Core\Session::flash('flash_success');
$flash_error   = \App\Core\Session::flash('flash_error');
?>

<?php if ($flash_success): ?>
  <div class="mb-4 px-4 py-3 rounded-xl bg-green-50 border border-green-200 text-green-700 text-sm font-medium">
    ✓ <?= htmlspecialchars($flash_success) ?>
  </div>
<?php endif; ?>

<?php if ($flash_error): ?>
  <div class="mb-4 px-4 py-3 rounded-xl bg-red-50 border border-red-200 text-red-700 text-sm font-medium">
    ✗ <?= htmlspecialchars($flash_error) ?>
  </div>
<?php endif; ?>

<div class="max-w-3xl mx-auto flex flex-col bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden" style="height: 80vh;">

  <!-- Header -->
  <div class="px-6 py-4 border-b border-slate-200 bg-slate-50 flex items-center justify-between flex-shrink-0">
    <div>
      <h2 class="text-lg font-semibold text-slate-800">Customer: <?= htmlspecialchars($conversation['fb_sender_id']) ?></h2>
      <p class="text-sm text-slate-500 mt-0.5">Via Page: <?= htmlspecialchars($conversation['page_name'] ?? 'Unknown') ?></p>
    </div>
    <a href="/conversations" class="btn-primary text-xs bg-slate-600 hover:bg-slate-700">← Back</a>
  </div>

  <!-- Messages -->
  <div id="chat-messages" class="flex-1 overflow-y-auto p-6 space-y-4 bg-slate-50/50">
    <?php if (empty($messages)): ?>
      <div class="text-center text-slate-500 mt-10">No messages found.</div>
    <?php else: ?>
      <?php foreach ($messages as $msg): ?>
        <?php if ($msg['role'] === 'user'): ?>
          <div class="flex justify-end">
            <div class="max-w-[75%] bg-indigo-600 text-white rounded-2xl rounded-tr-sm px-4 py-3 shadow-md">
              <p class="text-sm whitespace-pre-wrap"><?= htmlspecialchars($msg['content']) ?></p>
              <span class="text-[10px] text-indigo-200 mt-1 block text-right">Customer &bull; <?= date('g:i A', strtotime($msg['created_at'])) ?></span>
            </div>
          </div>
        <?php else: ?>
          <div class="flex justify-start">
            <div class="max-w-[75%] bg-white border border-slate-200 text-slate-800 rounded-2xl rounded-tl-sm px-4 py-3 shadow-sm">
              <p class="text-sm whitespace-pre-wrap"><?= htmlspecialchars($msg['content']) ?></p>
              <span class="text-[10px] text-slate-400 mt-1 block text-left">AI Bot &bull; <?= date('g:i A', strtotime($msg['created_at'])) ?></span>
            </div>
          </div>
        <?php endif; ?>
      <?php endforeach; ?>
    <?php endif; ?>
  </div>

  <!-- Manual Message Send -->
  <div class="border-t border-slate-200 bg-white px-4 py-3 flex-shrink-0">
    <p class="text-[11px] text-slate-400 mb-2 font-medium uppercase tracking-wide">Send as Admin / Bot</p>
    <form method="POST" action="/conversations/<?= $convId ?>/send" class="flex gap-3 items-end">
      <?= \App\Core\CSRF::field() ?>
      <textarea
        name="message"
        rows="2"
        placeholder="Type a message to send directly to this customer..."
        class="form-input text-sm flex-1 resize-none"
        style="border-radius:12px; padding: 10px 14px;"
        onkeydown="if(event.ctrlKey && event.key==='Enter') this.form.submit();"
      ></textarea>
      <button type="submit" class="btn-primary flex-shrink-0" style="height:42px; border-radius:12px; padding: 0 20px;">
        Send&nbsp;↑
      </button>
    </form>
    <p class="text-[10px] text-slate-400 mt-1.5">Ctrl+Enter to send quickly</p>
  </div>

</div>

<script>
  // Auto-scroll to bottom of chat
  const chatContainer = document.getElementById('chat-messages');
  if (chatContainer) chatContainer.scrollTop = chatContainer.scrollHeight;
</script>

<?php require_once __DIR__ . '/../layouts/footer.php'; ?>
