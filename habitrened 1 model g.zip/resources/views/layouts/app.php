<?php
/**
 * Shared layout header for business dashboard
 * Usage: include this at the top of every business view
 * Variables expected: $pageTitle (string)
 */
use App\Core\{Session, CSRF};
use App\Models\SystemSetting;
$settings = (new SystemSetting())->all();
$siteName = $settings['site_name'] ?? 'AI Chatbot SaaS';
$user     = Session::user();
$success  = Session::flash('flash_success');
$error    = Session::flash('flash_error');
$csrf     = CSRF::token();
?>
<!DOCTYPE html>
<html lang="en" class="h-full">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= htmlspecialchars($pageTitle ?? 'Dashboard') ?> — <?= htmlspecialchars($siteName) ?></title>
  <script src="https://cdn.tailwindcss.com"></script>
  <script>tailwind.config = { darkMode: 'class' }</script>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <style>
    body { font-family: 'Inter', sans-serif; }

    /* ── Sidebar base ── */
    #sidebar {
      width: 272px;
      background: #FFFFFF;
      border-right: 1px solid #EAEDF3;
      transition: width 0.25s ease, transform 0.25s ease;
      box-shadow: 2px 0 20px rgba(0,0,0,0.04);
    }
    #sidebar.collapsed { width: 80px; }
    #sidebar.collapsed .nav-label,
    #sidebar.collapsed .sidebar-section-title,
    #sidebar.collapsed .user-name,
    #sidebar.collapsed .user-plan,
    #sidebar.collapsed .site-name,
    #sidebar.collapsed .upgrade-text,
    #sidebar.collapsed .logout-label { display: none; }
    #sidebar.collapsed .sidebar-link { justify-content: center; padding: 12px; border-radius: 14px; }
    #sidebar.collapsed .logo-area { justify-content: center; padding: 20px 0; }
    #sidebar.collapsed .nav-badge { display: none; }
    #sidebar.collapsed .user-card { justify-content: center; padding: 12px; }
    #sidebar.collapsed .upgrade-btn { justify-content: center; padding: 10px; }
    #sidebar.collapsed .logout-btn { justify-content: center; padding: 10px; }
    #sidebar.collapsed .collapse-btn { justify-content: center; }

    /* Tooltip on collapsed */
    #sidebar.collapsed .sidebar-link { position: relative; }
    #sidebar.collapsed .sidebar-link:hover::after {
      content: attr(data-label);
      position: absolute;
      left: calc(100% + 14px);
      top: 50%;
      transform: translateY(-50%);
      background: #1E1B4B;
      color: white;
      font-size: 12px;
      font-weight: 500;
      padding: 6px 12px;
      border-radius: 8px;
      white-space: nowrap;
      z-index: 999;
      pointer-events: none;
      box-shadow: 0 4px 12px rgba(0,0,0,0.12);
    }
    #sidebar.collapsed .sidebar-link:hover::before {
      content: '';
      position: absolute;
      left: calc(100% + 6px);
      top: 50%;
      transform: translateY(-50%);
      border: 6px solid transparent;
      border-right-color: #1E1B4B;
      z-index: 999;
    }

    /* ── Nav link ── */
    .sidebar-link {
      display: flex;
      align-items: center;
      gap: 12px;
      padding: 11px 14px;
      border-radius: 12px;
      color: #64748B;
      font-size: 14px;
      font-weight: 500;
      text-decoration: none;
      transition: all 0.2s ease;
      white-space: nowrap;
      overflow: hidden;
    }
    .sidebar-link:hover {
      background: #F5F3FF;
      color: #6C4DFF;
    }
    .sidebar-link:hover svg { color: #6C4DFF; }
    .sidebar-link.active {
      background: linear-gradient(135deg, #6C4DFF 0%, #7C6FFF 100%);
      color: #FFFFFF;
      font-weight: 600;
      box-shadow: 0 4px 16px rgba(108,77,255,0.28);
    }
    .sidebar-link.active svg { color: #FFFFFF; }
    .sidebar-link svg { flex-shrink: 0; width: 20px; height: 20px; transition: color 0.2s; }

    /* ── Badge ── */
    .nav-badge {
      margin-left: auto;
      background: #EDE9FE;
      color: #6C4DFF;
      font-size: 11px;
      font-weight: 700;
      padding: 2px 8px;
      border-radius: 20px;
      min-width: 22px;
      text-align: center;
    }
    .sidebar-link.active .nav-badge { background: rgba(255,255,255,0.25); color: #fff; }

    /* ── Section title ── */
    .sidebar-section-title {
      font-size: 10.5px;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.08em;
      color: #B0B7C3;
      padding: 0 14px;
      margin-bottom: 6px;
      margin-top: 6px;
    }

    /* ── User card ── */
    .user-avatar {
      width: 40px; height: 40px;
      border-radius: 12px;
      background: linear-gradient(135deg, #6C4DFF 0%, #4F8CFF 100%);
      color: white;
      font-size: 13px;
      font-weight: 700;
      display: flex; align-items: center; justify-content: center;
      flex-shrink: 0;
      box-shadow: 0 3px 10px rgba(108,77,255,0.28);
    }

    /* ── Upgrade button ── */
    .upgrade-btn {
      display: flex;
      align-items: center;
      gap: 10px;
      padding: 12px 14px;
      border-radius: 14px;
      background: #FFF9EC;
      border: 1px solid #FFE9A0;
      color: #92600A;
      font-size: 13px;
      font-weight: 600;
      text-decoration: none;
      transition: all 0.2s ease;
    }
    .upgrade-btn:hover { background: #FFF3CC; border-color: #FFD84D; box-shadow: 0 4px 12px rgba(255,196,0,0.15); }
    .upgrade-btn .upgrade-icon { color: #F59E0B; flex-shrink: 0; }

    /* ── Logout button ── */
    .logout-btn {
      display: flex;
      align-items: center;
      gap: 10px;
      padding: 12px 14px;
      border-radius: 14px;
      background: #FFF5F5;
      border: 1px solid #FECACA;
      color: #DC2626;
      font-size: 13px;
      font-weight: 600;
      text-decoration: none;
      transition: all 0.2s ease;
    }
    .logout-btn:hover { background: #FEE2E2; box-shadow: 0 4px 12px rgba(220,38,38,0.12); }

    /* ── Collapse toggle button ── */
    .collapse-btn {
      display: flex; align-items: center; justify-content: flex-end;
      padding: 0 16px;
      height: 40px;
      cursor: pointer;
      color: #94A3B8;
      transition: color 0.2s;
    }
    .collapse-btn:hover { color: #6C4DFF; }
    .collapse-btn svg { transition: transform 0.25s ease; }
    #sidebar.collapsed .collapse-btn { justify-content: center; }
    #sidebar.collapsed .collapse-btn svg { transform: rotate(180deg); }

    /* ── Main content area ── */
    .stat-card { @apply bg-white rounded-2xl p-6 shadow-[0_2px_12px_rgba(0,0,0,0.03)] border border-[#E2E8F0] hover:shadow-[0_8px_24px_rgba(0,0,0,0.06)] transition-all duration-300; }
    .btn-primary { background: linear-gradient(135deg, #6C4DFF 0%, #4F8CFF 100%); @apply inline-flex items-center gap-2 text-white font-medium px-5 py-2.5 rounded-[12px] shadow-[0_4px_12px_rgba(108,77,255,0.25)] hover:shadow-[0_6px_16px_rgba(108,77,255,0.35)] transition-all text-sm; }
    .btn-danger  { @apply inline-flex items-center gap-2 bg-red-500 hover:bg-red-600 shadow-[0_4px_12px_rgba(239,68,68,0.25)] text-white font-medium px-5 py-2.5 rounded-[12px] transition-all text-sm; }
    .form-input  { @apply w-full border border-[#E2E8F0] rounded-[12px] px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#6C4DFF]/50 focus:border-[#6C4DFF] transition-all shadow-sm; }

    /* Mobile overlay */
    #sidebar-overlay { display: none; }
    @media (max-width: 767px) {
      #sidebar { position: fixed; inset-y: 0; left: 0; z-index: 40; transform: translateX(-100%); width: 272px !important; }
      #sidebar.mobile-open { transform: translateX(0); }
      #sidebar-overlay.active { display: block; }
    }
  </style>
  <script>
    // Desktop collapse toggle
    function toggleCollapse() {
      document.getElementById('sidebar').classList.toggle('collapsed');
      try { localStorage.setItem('sb_collapsed', document.getElementById('sidebar').classList.contains('collapsed') ? '1' : '0'); } catch(e){}
    }
    // Mobile open/close
    function toggleSidebar() {
      document.getElementById('sidebar').classList.toggle('mobile-open');
      document.getElementById('sidebar-overlay').classList.toggle('active');
    }
    // Restore collapse state on desktop
    document.addEventListener('DOMContentLoaded', function() {
      try {
        if (window.innerWidth >= 768 && localStorage.getItem('sb_collapsed') === '1') {
          document.getElementById('sidebar').classList.add('collapsed');
        }
      } catch(e){}
    });
  </script>
</head>
<body class="bg-[#F5F6FA] h-full" style="font-family:'Inter',sans-serif;">
<div class="flex h-screen overflow-hidden">

  <!-- Mobile overlay -->
  <div id="sidebar-overlay" onclick="toggleSidebar()" class="fixed inset-0 bg-slate-900/40 z-30 transition-opacity backdrop-blur-sm"></div>

  <!-- ═══════════ SIDEBAR ═══════════ -->
  <aside id="sidebar" class="flex flex-col flex-shrink-0 h-full overflow-hidden">

    <!-- Logo row + collapse button -->
    <div class="flex items-center justify-between px-5 pt-5 pb-4 border-b border-[#F0F0F5]">
      <a href="/dashboard" class="logo-area flex items-center gap-3 min-w-0">
        <?php if (!empty($settings['site_logo'])): ?>
          <img src="<?= htmlspecialchars($settings['site_logo']) ?>" class="h-9 w-9 rounded-[10px] shadow-sm flex-shrink-0" alt="Logo">
        <?php else: ?>
          <div class="h-9 w-9 rounded-[10px] flex items-center justify-center flex-shrink-0"
               style="background: linear-gradient(135deg, #6C4DFF 0%, #7C6FFF 100%); box-shadow:0 4px 10px rgba(108,77,255,0.32);">
            <svg class="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"/>
            </svg>
          </div>
        <?php endif; ?>
        <span class="site-name font-bold text-[15px] text-[#0F172A] tracking-tight truncate"><?= htmlspecialchars($siteName) ?></span>
      </a>
      <!-- Desktop collapse arrow -->
      <button onclick="toggleCollapse()" class="collapse-btn hidden md:flex">
        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/>
        </svg>
      </button>
    </div>

    <!-- Nav links -->
    <nav class="flex-1 px-3 py-4 space-y-0.5 overflow-y-auto overflow-x-hidden">
      <p class="sidebar-section-title">Main Menu</p>

      <?php $cur = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH); ?>

      <a href="/dashboard" data-label="Dashboard"
         class="sidebar-link <?= $cur === '/dashboard' ? 'active' : '' ?>">
        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
            d="M4 5a1 1 0 011-1h4a1 1 0 011 1v5a1 1 0 01-1 1H5a1 1 0 01-1-1V5zm10 0a1 1 0 011-1h4a1 1 0 011 1v2a1 1 0 01-1 1h-4a1 1 0 01-1-1V5zM4 15a1 1 0 011-1h4a1 1 0 011 1v4a1 1 0 01-1 1H5a1 1 0 01-1-1v-4zm10-3a1 1 0 011-1h4a1 1 0 011 1v7a1 1 0 01-1 1h-4a1 1 0 01-1-1v-7z"/>
        </svg>
        <span class="nav-label">Dashboard</span>
      </a>

      <a href="/products" data-label="Products"
         class="sidebar-link <?= str_starts_with($cur, '/products') ? 'active' : '' ?>">
        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
            d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10"/>
        </svg>
        <span class="nav-label">Products</span>
      </a>

      <a href="/orders" data-label="Orders"
         class="sidebar-link <?= str_starts_with($cur, '/orders') ? 'active' : '' ?>">
        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
            d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"/>
        </svg>
        <span class="nav-label">Orders</span>
        <span class="nav-badge">3</span>
      </a>

      <a href="/conversations" data-label="Conversations"
         class="sidebar-link <?= str_starts_with($cur, '/conversations') ? 'active' : '' ?>">
        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
            d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z"/>
        </svg>
        <span class="nav-label">Conversations</span>
      </a>

      <a href="/facebook" data-label="Facebook Pages"
         class="sidebar-link <?= str_starts_with($cur, '/facebook') ? 'active' : '' ?>">
        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
            d="M18 2h-3a5 5 0 00-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 011-1h3z"/>
        </svg>
        <span class="nav-label">Facebook Pages</span>
      </a>

      <a href="/subscription" data-label="Subscription"
         class="sidebar-link <?= str_starts_with($cur, '/subscription') ? 'active' : '' ?>">
        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
            d="M9 12l2 2 4-4M7.835 4.697a3.42 3.42 0 001.946-.806 3.42 3.42 0 014.438 0 3.42 3.42 0 001.946.806 3.42 3.42 0 013.138 3.138 3.42 3.42 0 00.806 1.946 3.42 3.42 0 010 4.438 3.42 3.42 0 00-.806 1.946 3.42 3.42 0 01-3.138 3.138 3.42 3.42 0 00-1.946.806 3.42 3.42 0 01-4.438 0 3.42 3.42 0 00-1.946-.806 3.42 3.42 0 01-3.138-3.138 3.42 3.42 0 00-.806-1.946 3.42 3.42 0 010-4.438 3.42 3.42 0 00.806-1.946 3.42 3.42 0 013.138-3.138z"/>
        </svg>
        <span class="nav-label">Subscription</span>
      </a>

      <a href="/reports" data-label="Reports"
         class="sidebar-link <?= str_starts_with($cur, '/reports') ? 'active' : '' ?>">
        <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
            d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"/>
        </svg>
        <span class="nav-label">Reports</span>
      </a>
    </nav>

    <!-- Bottom section: user card + upgrade + logout -->
    <div class="px-3 pb-5 border-t border-[#F0F0F5] pt-3 space-y-2">

      <!-- User card -->
      <div class="user-card flex items-center gap-3 px-2 py-2 rounded-[12px] hover:bg-[#F5F3FF] transition-colors cursor-default overflow-hidden">
        <div class="user-avatar">
          <?= strtoupper(substr($user['name'] ?? 'U', 0, 2)) ?>
        </div>
        <div class="flex-1 min-w-0">
          <p class="user-name font-semibold text-[13px] text-[#0F172A] truncate leading-tight"><?= htmlspecialchars($user['name'] ?? '') ?></p>
          <p class="user-plan text-[11px] text-slate-400 flex items-center gap-1.5 mt-0.5">
            <span class="w-1.5 h-1.5 rounded-full bg-green-400 shadow-[0_0_6px_rgba(74,222,128,0.6)]"></span>
            Free Plan
          </p>
        </div>
        <svg class="upgrade-text w-4 h-4 text-slate-300 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/>
        </svg>
      </div>

      <!-- Upgrade -->
      <a href="/subscription" class="upgrade-btn">
        <svg class="upgrade-icon w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
            d="M5 3v4M3 5h4M6 17v4m-2-2h4m5-16l2.286 6.857L21 12l-5.714 2.143L13 21l-2.286-6.857L5 12l5.714-2.143L13 3z"/>
        </svg>
        <div class="upgrade-text flex flex-col min-w-0">
          <span class="text-[13px] font-semibold text-[#92600A] leading-tight truncate">Upgrade Plan</span>
          <span class="text-[11px] text-[#B8892A] truncate">Unlock more features</span>
        </div>
        <svg class="upgrade-text w-4 h-4 text-[#F59E0B] ml-auto flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/>
        </svg>
      </a>

      <!-- Logout -->
      <a href="/logout" class="logout-btn">
        <svg class="w-5 h-5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
            d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"/>
        </svg>
        <span class="logout-label font-semibold text-[13px]">Logout</span>
      </a>
    </div>
  </aside>
  <!-- ═══════════ END SIDEBAR ═══════════ -->

  <!-- Main Content -->
  <main class="flex-1 overflow-y-auto min-w-0">
    <!-- Top Bar -->
    <header class="bg-white border-b border-slate-100 px-6 py-4 flex items-center justify-between sticky top-0 z-10 shadow-[0_1px_8px_rgba(0,0,0,0.04)]">
      <div class="flex items-center gap-3">
        <button onclick="toggleSidebar()" class="md:hidden text-slate-500 focus:outline-none p-1">
          <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"/>
          </svg>
        </button>
        <h1 class="text-[15px] font-semibold text-slate-800 truncate"><?= htmlspecialchars($pageTitle ?? 'Dashboard') ?></h1>
      </div>
      <div class="flex items-center gap-3">
        <?php if (Session::get('admin_impersonating')): ?>
        <a href="/admin/return-to-admin" class="text-xs bg-orange-100 text-orange-700 px-3 py-1.5 rounded-full font-medium hover:bg-orange-200">
          ← Return to Admin
        </a>
        <?php endif; ?>
        <span class="text-xs text-slate-400 flex items-center gap-1.5">
          <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"/>
          </svg>
          <?= date('D, M j, Y') ?>
        </span>
      </div>
    </header>

    <!-- Flash Messages -->
    <?php if ($success): ?>
    <div class="mx-6 mt-4 bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-xl text-sm flex items-center gap-2">
      <svg class="w-4 h-4 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
        <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/>
      </svg>
      <?= htmlspecialchars($success) ?>
    </div>
    <?php endif; ?>
    <?php if ($error): ?>
    <div class="mx-6 mt-4 bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-xl text-sm flex items-center gap-2">
      <svg class="w-4 h-4 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
        <path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clip-rule="evenodd"/>
      </svg>
      <?= htmlspecialchars($error) ?>
    </div>
    <?php endif; ?>

    <div class="p-6"></div>