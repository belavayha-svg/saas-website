<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Core\{Request, Response, Session, CSRF};
use App\Models\{DeliveryRule, BusinessPaymentMethod};

class DeliveryRuleController
{
    private Response $response;
    private DeliveryRule $model;

    public function __construct()
    {
        $this->response = new Response();
        $this->model    = new DeliveryRule();
    }

    /** GET /delivery-rules — JSON list for modal */
    public function index(Request $request): void
    {
        $userId  = Session::user()['id'];
        $rules   = $this->model->forUser($userId);
        
        $paymentModel = new BusinessPaymentMethod();
        $payments     = $paymentModel->forUser($userId);

        header('Content-Type: application/json');
        echo json_encode(['rules' => $rules, 'payments' => $payments]);
        exit;
    }

    /** POST /business-payments — add new payment method */
    public function storePayment(Request $request): void
    {
        CSRF::verifyOrFail();
        $userId      = Session::user()['id'];
        $methodName  = trim($request->post('method_name', ''));
        $accountNum  = trim($request->post('account_number', ''));

        if (empty($methodName) || empty($accountNum)) {
            http_response_code(422);
            header('Content-Type: application/json');
            echo json_encode(['error' => 'পেমেন্ট মেথড এবং নাম্বার আবশ্যক।']);
            exit;
        }

        $paymentModel = new BusinessPaymentMethod();
        $id = $paymentModel->create([
            'user_id'        => $userId,
            'method_name'    => $methodName,
            'account_number' => $accountNum,
        ]);

        header('Content-Type: application/json');
        echo json_encode(['success' => true, 'id' => $id]);
        exit;
    }

    /** POST /business-payments/:id/delete */
    public function destroyPayment(Request $request): void
    {
        CSRF::verifyOrFail();
        $userId = Session::user()['id'];
        $id     = (int) $request->param('id');
        $paymentModel = new BusinessPaymentMethod();
        $paymentModel->delete($id, $userId);
        header('Content-Type: application/json');
        echo json_encode(['success' => true]);
        exit;
    }

    /** POST /delivery-rules — add new rule */
    public function store(Request $request): void
    {
        CSRF::verifyOrFail();
        $userId   = Session::user()['id'];
        $areaName = trim($request->post('area_name', ''));
        $charge   = (float) $request->post('charge', 0);
        $note     = trim($request->post('note', ''));

        if (empty($areaName)) {
            http_response_code(422);
            header('Content-Type: application/json');
            echo json_encode(['error' => 'এলাকার নাম আবশ্যক।']);
            exit;
        }

        $id = $this->model->create([
            'user_id'   => $userId,
            'area_name' => $areaName,
            'charge'    => $charge,
            'note'      => $note ?: null,
        ]);

        header('Content-Type: application/json');
        echo json_encode(['success' => true, 'id' => $id]);
        exit;
    }

    /** POST /delivery-rules/:id/update */
    public function update(Request $request): void
    {
        CSRF::verifyOrFail();
        $userId   = Session::user()['id'];
        $id       = (int) $request->param('id');
        $areaName = trim($request->post('area_name', ''));
        $charge   = (float) $request->post('charge', 0);
        $note     = trim($request->post('note', ''));

        if (empty($areaName)) {
            http_response_code(422);
            header('Content-Type: application/json');
            echo json_encode(['error' => 'এলাকার নাম আবশ্যক।']);
            exit;
        }

        $this->model->update($id, $userId, [
            'area_name' => $areaName,
            'charge'    => $charge,
            'note'      => $note ?: null,
        ]);

        header('Content-Type: application/json');
        echo json_encode(['success' => true]);
        exit;
    }

    /** POST /delivery-rules/:id/delete */
    public function destroy(Request $request): void
    {
        CSRF::verifyOrFail();
        $userId = Session::user()['id'];
        $id     = (int) $request->param('id');
        $this->model->delete($id, $userId);
        header('Content-Type: application/json');
        echo json_encode(['success' => true]);
        exit;
    }
}
