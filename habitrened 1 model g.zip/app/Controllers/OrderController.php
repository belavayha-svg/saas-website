<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Core\{Request, Response, Session, CSRF};
use App\Models\Order;

class OrderController
{
    private Response $response;
    private Order $model;

    public function __construct()
    {
        $this->response = new Response();
        $this->model    = new Order();
    }

    public function index(Request $request): void
    {
        $userId      = Session::user()['id'];
        $status      = $request->get('status', '');
        $paymentType = $request->get('payment_type', '');
        $page        = max(1, (int) $request->get('page', 1));
        $limit       = 20;

        $orders = $this->model->forUser($userId, $limit, ($page - 1) * $limit, $status, $paymentType);
        $total  = $this->model->count($userId, $status, $paymentType);

        $this->response->view('orders/index', compact('orders', 'total', 'page', 'limit', 'status', 'paymentType'));
    }

    public function show(Request $request): void
    {
        $userId = Session::user()['id'];
        $id     = (int) $request->param('id');
        $order  = $this->model->findById($id, $userId);
        if (!$order) $this->response->abort(404);
        $items  = $this->model->getItems($id);
        $this->response->view('orders/show', compact('order', 'items'));
    }

    public function updateStatus(Request $request): void
    {
        CSRF::verifyOrFail();
        $userId = Session::user()['id'];
        $id     = (int) $request->param('id');
        $status = $request->post('status', '');

        $valid = ['pending', 'confirmed', 'processing', 'delivered', 'cancelled'];
        if (!in_array($status, $valid)) {
            $this->response->withError('Invalid status.', "/orders/{$id}");
        }

        $this->model->updateStatus($id, $userId, $status);
        $this->response->withSuccess('Order status updated.', "/orders/{$id}");
    }

    public function updatePayment(Request $request): void
    {
        CSRF::verifyOrFail();
        $userId = Session::user()['id'];
        $id     = (int) $request->param('id');
        $order  = $this->model->findById($id, $userId);
        if (!$order) $this->response->abort(404);

        $paymentType = $request->post('payment_type', 'pending');
        $validTypes  = ['full', 'partial', 'pending'];
        if (!in_array($paymentType, $validTypes)) {
            $paymentType = 'pending';
        }

        $deliveryCharge  = (float) $request->post('delivery_charge', 0);
        $amountSent      = (float) $request->post('amount_sent', 0);
        // Keep paid_amount in sync with amount_sent
        $paidAmount      = $amountSent > 0 ? $amountSent : (float) $request->post('paid_amount', 0);
        $transactionId   = trim($request->post('transaction_id', ''));
        $customerName    = trim($request->post('customer_name', ''));
        $customerPhone   = trim($request->post('customer_phone', ''));
        $customerAddress = trim($request->post('customer_address', ''));

        $this->model->updatePayment($id, $userId, [
            'payment_type'     => $paymentType,
            'delivery_charge'  => $deliveryCharge,
            'paid_amount'      => $paidAmount,
            'transaction_id'   => $transactionId ?: null,
            'amount_sent'      => $amountSent,
            'customer_name'    => $customerName ?: null,
            'customer_phone'   => $customerPhone ?: null,
            'customer_address' => $customerAddress ?: null,
        ]);

        $this->response->withSuccess('Payment info updated.', "/orders/{$id}");
    }
}
