<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Core\{Request, Response, Session, CSRF};
use App\Models\{Plan, PaymentMethod, PaymentRequest, Subscription};
use App\Services\SubscriptionService;

class SubscriptionController
{
    private Response $response;

    public function __construct()
    {
        $this->response = new Response();
    }

    public function index(Request $request): void
    {
        $userId   = Session::user()['id'];
        $planModel = new Plan();
        $subModel  = new Subscription();
        $plans    = $planModel->all(onlyActive: true);
        $current  = $subModel->getActive($userId);
        $history  = $subModel->history($userId);
        $this->response->view('subscription/index', compact('plans', 'current', 'history'));
    }

    public function checkout(Request $request): void
    {
        $planId  = (int) $request->param('planId');
        $plan    = (new Plan())->findById($planId);
        if (!$plan) $this->response->abort(404, 'Plan not found.');
        $methods = (new PaymentMethod())->all(onlyActive: true);
        $error   = Session::flash('flash_error');
        $this->response->view('subscription/checkout', compact('plan', 'methods', 'error'));
    }

    public function submitPayment(Request $request): void
    {
        CSRF::verifyOrFail();
        $userId = Session::user()['id'];
        $planId = (int) $request->post('plan_id', 0);
        $trxId  = $request->post('trx_id', '');
        $method = $request->post('payment_method', '');
        $amount = (float) $request->post('amount', 0);

        if (!$planId || empty($trxId) || empty($method)) {
            $this->response->withError('All fields are required.', "/subscription/checkout/{$planId}");
        }

        $plan = (new Plan())->findById($planId);
        if (!$plan) $this->response->withError('Invalid plan.', '/subscription');

        (new PaymentRequest())->create([
            'user_id'        => $userId,
            'plan_id'        => $planId,
            'trx_id'         => $trxId,
            'payment_method' => $method,
            'amount'         => $amount ?: $plan['price'],
        ]);

        $this->response->withSuccess('Payment request submitted. Admin will verify shortly.', '/subscription');
    }
}
