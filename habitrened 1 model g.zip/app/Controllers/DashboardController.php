<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Core\{Request, Response, Session};
use App\Models\{Order, Product, Subscription, FacebookPage, AiUsageLog};
use App\Services\{SubscriptionService, AiUsageService};

class DashboardController
{
    private Response $response;

    public function __construct()
    {
        $this->response = new Response();
    }

    public function index(Request $request): void
    {
        $userId      = Session::user()['id'];
        $orderModel  = new Order();
        $productModel = new Product();
        $subService  = new SubscriptionService();
        $fbModel     = new FacebookPage();
        $aiUsage     = new AiUsageService();

        $subscription     = $subService->getActive($userId);
        $totalOrders      = $orderModel->count($userId);
        $pendingOrders    = $orderModel->countByStatus($userId, 'pending');
        $totalProducts    = $productModel->count($userId);
        $connectedPages   = $fbModel->countForUser($userId);
        $aiMessagesUsed   = $aiUsage->totalForUser($userId);
        $revenueMonth     = $orderModel->revenueByPeriod($userId, 'month');
        $revenueWeek      = $orderModel->revenueByPeriod($userId, 'week');
        $revenueDay       = $orderModel->revenueByPeriod($userId, 'day');
        $dailyOrders      = $orderModel->dailyOrders($userId, 30);
        $recentOrders     = $orderModel->forUser($userId, 5);
        $aiDailyStats     = $aiUsage->dailyStats($userId, 30);

        $this->response->view('dashboard/index', compact(
            'subscription', 'totalOrders', 'pendingOrders', 'totalProducts',
            'connectedPages', 'aiMessagesUsed', 'revenueMonth', 'revenueWeek',
            'revenueDay', 'dailyOrders', 'recentOrders', 'aiDailyStats'
        ));
    }
}
