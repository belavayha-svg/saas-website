<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Core\{Request, Response, Session, CSRF};
use App\Models\{FacebookPage, Subscription};
use App\Services\{FacebookService, SubscriptionService};

class FacebookController
{
    private Response $response;
    private FacebookPage $model;
    private FacebookService $fbService;
    private SubscriptionService $subService;

    public function __construct()
    {
        $this->response   = new Response();
        $this->model      = new FacebookPage();
        $this->fbService  = new FacebookService();
        $this->subService = new SubscriptionService();
    }

    public function index(Request $request): void
    {
        $userId = Session::user()['id'];
        $pages  = $this->model->forUser($userId);
        $sub    = $this->subService->getActive($userId);
        $pageLimit   = (int) ($sub['page_limit'] ?? 1);
        $connected   = $this->model->countForUser($userId);
        $fbAppId     = env('FB_APP_ID', '');
        $this->response->view('facebook/index', compact('pages', 'pageLimit', 'connected', 'fbAppId'));
    }

    /**
     * Exchange short-lived user token for page tokens and save selected page
     */
    public function connect(Request $request): void
    {
        CSRF::verifyOrFail();
        $userId      = Session::user()['id'];
        $userToken   = $request->post('user_access_token', '');
        $pageId      = $request->post('page_id', '');

        if (empty($userToken) || empty($pageId)) {
            $this->response->withError('Missing token or page ID.', '/facebook');
        }

        // Check page limit
        $sub = $this->subService->getActive($userId);
        $limit = (int) ($sub['page_limit'] ?? 1);
        if ($limit !== -1 && $this->model->countForUser($userId) >= $limit) {
            $this->response->withError('You have reached your Facebook page limit. Upgrade your plan.', '/facebook');
        }

        // --- NEW CODE: Short-Lived টোকেনকে Long-Lived টোকেনে কনভার্ট করা হচ্ছে ---
        // এতে পেজ টোকেনটি 'Never Expire' বা আজীবনের জন্য ভ্যালিড হয়ে যাবে।
        $longLivedToken = $this->fbService->getLongLivedUserToken($userToken);
        if ($longLivedToken) {
            $userToken = $longLivedToken; // এখন থেকে Long-Lived টোকেন ব্যবহার হবে
        }
        // -------------------------------------------------------------------------

        $pages = $this->fbService->getPageTokens($userToken);
        $found = null;
        foreach ($pages as $p) {
            if ($p['id'] === $pageId) { $found = $p; break; }
        }
        if (!$found) {
            $this->response->withError('Page not found in your Facebook account.', '/facebook');
        }

        // Subscribe our app to the page's webhooks to start receiving messages
        $subscribed = $this->fbService->subscribeAppToPage($found['id'], $found['access_token']);
        
        if (!$subscribed) {
            $this->response->withError('Failed to activate messages for this page. Ensure you have the pages_messaging permission.', '/facebook');
        }

        $this->model->create($userId, $found['id'], $found['name'], $found['access_token']);
        $this->response->withSuccess("Page \"{$found['name']}\" connected successfully and AI is active.", '/facebook');
    }

    public function disconnect(Request $request): void
    {
        CSRF::verifyOrFail();
        $userId = Session::user()['id'];
        $id     = (int) $request->param('id');
        $this->model->disconnect($id, $userId);
        $this->response->withSuccess('Page disconnected.', '/facebook');
    }

    /**
     * API endpoint — returns user's pages from FB for JS token exchange
     */
    public function getPages(Request $request): void
    {
        $userToken = $request->get('token', '');
        if (empty($userToken)) {
            (new Response())->json(['error' => 'Missing token'], 400);
        }
        $pages = $this->fbService->getPageTokens($userToken);
        (new Response())->json(['pages' => $pages]);
    }
}