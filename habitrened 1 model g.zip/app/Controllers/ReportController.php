<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Core\{Request, Response, Session};
use App\Models\{Order};
use App\Services\AiUsageService;

class ReportController
{
    private Response $response;

    public function __construct()
    {
        $this->response = new Response();
    }

    public function index(Request $request): void
    {
        $userId     = Session::user()['id'];
        $orderModel = new Order();
        $aiService  = new AiUsageService();

        $period      = $request->get('period', 'month');
        $revenue     = $orderModel->revenueByPeriod($userId, $period);
        $dailyOrders = $orderModel->dailyOrders($userId, match($period) {
            'day'   => 1,
            'week'  => 7,
            default => 30,
        });
        $aiStats     = $aiService->dailyStats($userId, 30);
        $orderStats  = [
            'total'     => $orderModel->count($userId),
            'pending'   => $orderModel->countByStatus($userId, 'pending'),
            'confirmed' => $orderModel->countByStatus($userId, 'confirmed'),
            'delivered' => $orderModel->countByStatus($userId, 'delivered'),
            'cancelled' => $orderModel->countByStatus($userId, 'cancelled'),
        ];
        $this->response->view('reports/index', compact('revenue', 'dailyOrders', 'aiStats', 'orderStats', 'period'));
    }
}
