<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Core\{Request, Response, Session, CSRF};
use App\Models\Product;

class ProductController
{
    private Response $response;
    private Product $model;

    public function __construct()
    {
        $this->response = new Response();
        $this->model    = new Product();
    }

    public function index(Request $request): void
    {
        $userId   = Session::user()['id'];
        $products = $this->model->forUser($userId);
        $this->response->view('products/index', compact('products'));
    }

    public function create(Request $request): void
    {
        $error = Session::flash('flash_error');
        $this->response->view('products/create', compact('error'));
    }

    public function store(Request $request): void
    {
        CSRF::verifyOrFail();
        $userId = Session::user()['id'];
        $name        = $request->post('name', '');
        $price       = (float) $request->post('price', 0);
        $description = $request->post('description', '');
        $status      = $request->post('status', 'active');

        if (empty($name) || $price < 0) {
            $this->response->withError('Name and valid price are required.', '/products/create');
        }

        $imagesData = [];
        $allowedColumns = ['image', 'image_2'];
        foreach ($allowedColumns as $col) {
            $file = $request->file($col);
            if ($file && $file['error'] === UPLOAD_ERR_OK) {
                $imagesData[$col] = $this->uploadImage($file, $userId);
            }
        }

        $this->model->create(array_merge(compact('userId', 'name', 'description', 'price', 'status'), $imagesData, ['user_id' => $userId]));
        $this->response->withSuccess('Product added successfully.', '/products');
    }

    public function edit(Request $request): void
    {
        $userId  = Session::user()['id'];
        $id      = (int) $request->param('id');
        $product = $this->model->findById($id, $userId);
        if (!$product) $this->response->abort(404, 'Product not found.');
        $error = Session::flash('flash_error');
        $this->response->view('products/edit', compact('product', 'error'));
    }

    public function update(Request $request): void
    {
        CSRF::verifyOrFail();
        $userId  = Session::user()['id'];
        $id      = (int) $request->param('id');
        $product = $this->model->findById($id, $userId);
        if (!$product) $this->response->abort(404);

        $data = [
            'name'        => $request->post('name', ''),
            'description' => $request->post('description', ''),
            'price'       => (float) $request->post('price', 0),
            'status'      => $request->post('status', 'active'),
        ];

        $this->model->update($id, $userId, $data);

        $allowedColumns = ['image', 'image_2'];
        foreach ($allowedColumns as $col) {
            $file = $request->file($col);
            if ($file && $file['error'] === UPLOAD_ERR_OK) {
                $imagePath = $this->uploadImage($file, $userId);
                $this->model->updateImage($id, $imagePath, $col);
            }
        }

        $this->response->withSuccess('Product updated.', '/products');
    }

    public function destroy(Request $request): void
    {
        CSRF::verifyOrFail();
        $userId = Session::user()['id'];
        $id     = (int) $request->param('id');
        $this->model->delete($id, $userId);
        $this->response->withSuccess('Product deleted.', '/products');
    }

    private function uploadImage(array $file, int $userId): string
    {
        $ext     = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        $allowed = ['jpg','jpeg','png','gif','webp'];
        if (!in_array($ext, $allowed)) return '';

        $dir = dirname(__DIR__, 2) . '/storage/uploads/' . $userId;
        if (!is_dir($dir)) mkdir($dir, 0755, true);

        $filename = uniqid('prod_', true) . '.' . $ext;
        move_uploaded_file($file['tmp_name'], $dir . '/' . $filename);
        return '/storage/uploads/' . $userId . '/' . $filename;
    }
}
