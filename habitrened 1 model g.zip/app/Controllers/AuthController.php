<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Core\{Request, Response, Session, CSRF};
use App\Middleware\RateLimitMiddleware;
use App\Models\User;
use App\Models\Subscription;

class AuthController
{
    private Response $response;
    private User $userModel;

    // Remember-me cookie name and lifetime (30 days)
    private const REMEMBER_COOKIE  = 'remember_me';
    private const REMEMBER_DAYS    = 30;

    public function __construct()
    {
        $this->response  = new Response();
        $this->userModel = new User();
    }

    public function showLogin(Request $request): void
    {
        // If already logged in via session → redirect
        if (Session::isLoggedIn()) {
            $this->response->redirect(Session::isSuperAdmin() ? '/admin/dashboard' : '/dashboard');
        }

        // Auto-login via remember_me cookie
        if (!empty($_COOKIE[self::REMEMBER_COOKIE])) {
            $token = $_COOKIE[self::REMEMBER_COOKIE];
            $user  = $this->userModel->findByRememberToken($token);
            if ($user && $user['status'] === 'active') {
                Session::login($user);
                // Refresh the cookie lifetime
                $this->setRememberCookie($token);
                $this->response->redirect($user['role'] === 'super_admin' ? '/admin/dashboard' : '/dashboard');
            } else {
                // Token invalid — clear it
                $this->clearRememberCookie();
            }
        }

        $error   = Session::flash('flash_error');
        $success = Session::flash('flash_success');
        $this->response->view('auth/login', compact('error', 'success'));
    }

    public function login(Request $request): void
    {
        // Rate limit: 10 attempts per min
        (new RateLimitMiddleware(10, 60))->handle($request);
        CSRF::verifyOrFail();

        $email    = strtolower(trim($request->post('email', '')));
        $password = $request->rawPost('password', '');
        $remember = $request->post('remember_me', '') === '1';

        if (empty($email) || empty($password)) {
            $this->response->withError('Email and password are required.', '/login');
        }

        $user = $this->userModel->findByEmail($email);

        if (!$user || !$this->userModel->verifyPassword($password, $user['password'])) {
            $this->response->withError('Invalid credentials.', '/login');
        }

        if ($user['status'] === 'suspended') {
            $this->response->withError('Your account has been suspended. Contact support.', '/login');
        }

        // Start session
        Session::login($user);

        // Set remember-me cookie if requested
        if ($remember) {
            $token = bin2hex(random_bytes(32)); // 64-char secure token
            $this->userModel->setRememberToken((int)$user['id'], $token);
            $this->setRememberCookie($token);
        }

        $intended = Session::flash('intended_url') ?? ($user['role'] === 'super_admin' ? '/admin/dashboard' : '/dashboard');
        $this->response->redirect($intended);
    }

    public function showRegister(Request $request): void
    {
        if (Session::isLoggedIn()) $this->response->redirect('/dashboard');
        $error = Session::flash('flash_error');
        $this->response->view('auth/register', compact('error'));
    }

    public function register(Request $request): void
    {
        (new RateLimitMiddleware(5, 60))->handle($request);
        CSRF::verifyOrFail();

        $name         = $request->post('name', '');
        $businessName = $request->post('business_name', '');
        $email        = strtolower(trim($request->post('email', '')));
        $password     = $request->rawPost('password', '');
        $confirm      = $request->rawPost('password_confirm', '');

        if (empty($name) || empty($email) || empty($password)) {
            $this->response->withError('All fields are required.', '/register');
        }
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $this->response->withError('Invalid email address.', '/register');
        }
        if (strlen($password) < 8) {
            $this->response->withError('Password must be at least 8 characters.', '/register');
        }
        if ($password !== $confirm) {
            $this->response->withError('Passwords do not match.', '/register');
        }
        if ($this->userModel->findByEmail($email)) {
            $this->response->withError('Email already registered.', '/register');
        }

        $userId = $this->userModel->create([
            'name'          => $name,
            'business_name' => $businessName,
            'email'         => $email,
            'password'      => $password,
        ]);

        // Auto-assign free plan (plan id=1)
        $subModel = new Subscription();
        $subModel->create($userId, 1, 30, 100);

        $this->response->withSuccess('Account created! Please login.', '/login');
    }

    public function logout(Request $request): void
    {
        // Clear remember_me token from DB and cookie
        $user = Session::user();
        if ($user) {
            $this->userModel->clearRememberToken((int)$user['id']);
        }
        $this->clearRememberCookie();

        Session::logout();
        $this->response->redirect('/login');
    }

    // ── Private helpers ──────────────────────────────────────────────────────

    private function setRememberCookie(string $token): void
    {
        setcookie(
            self::REMEMBER_COOKIE,
            $token,
            [
                'expires'  => time() + (self::REMEMBER_DAYS * 24 * 3600),
                'path'     => '/',
                'secure'   => isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
                'httponly' => true,
                'samesite' => 'Lax',
            ]
        );
    }

    private function clearRememberCookie(): void
    {
        setcookie(self::REMEMBER_COOKIE, '', [
            'expires'  => time() - 3600,
            'path'     => '/',
            'httponly' => true,
            'samesite' => 'Lax',
        ]);
        unset($_COOKIE[self::REMEMBER_COOKIE]);
    }
}
