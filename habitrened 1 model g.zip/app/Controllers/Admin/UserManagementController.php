<?php

declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Core\{Request, Response, Session, CSRF};
use App\Models\User;

class UserManagementController
{
    private Response $response;
    private User $model;

    public function __construct()
    {
        $this->response = new Response();
        $this->model    = new User();
    }

    public function index(Request $request): void
    {
        $page   = max(1, (int) $request->get('page', 1));
        $limit  = 20;
        $users  = $this->model->all($limit, ($page - 1) * $limit);
        $total  = $this->model->count();
        $error  = Session::flash('flash_error');
        $success = Session::flash('flash_success');
        $this->response->view('admin/users/index', compact('users', 'total', 'page', 'limit', 'error', 'success'));
    }

    public function edit(Request $request): void
    {
        $id   = (int) $request->param('id');
        $user = $this->model->findById($id);
        if (!$user) $this->response->abort(404);
        $error = Session::flash('flash_error');
        $this->response->view('admin/users/edit', compact('user', 'error'));
    }

    public function update(Request $request): void
    {
        CSRF::verifyOrFail();
        $id   = (int) $request->param('id');
        $data = [
            'name'          => $request->post('name', ''),
            'business_name' => $request->post('business_name', ''),
            'email'         => strtolower(trim($request->post('email', ''))),
            'status'        => $request->post('status', 'active'),
        ];
        $password = $request->rawPost('password', '');
        if (!empty($password)) $data['password'] = $password;

        $this->model->update($id, $data);
        $this->response->withSuccess('User updated.', '/admin/users');
    }

    public function suspend(Request $request): void
    {
        CSRF::verifyOrFail();
        $id = (int) $request->param('id');
        $this->model->setStatus($id, 'suspended');
        $this->response->withSuccess('User suspended.', '/admin/users');
    }

    public function activate(Request $request): void
    {
        CSRF::verifyOrFail();
        $id = (int) $request->param('id');
        $this->model->setStatus($id, 'active');
        $this->response->withSuccess('User activated.', '/admin/users');
    }

    public function delete(Request $request): void
    {
        CSRF::verifyOrFail();
        $id = (int) $request->param('id');
        $this->model->delete($id);
        $this->response->withSuccess('User deleted.', '/admin/users');
    }
}
