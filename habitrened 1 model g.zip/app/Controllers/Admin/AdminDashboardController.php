<?php

declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Core\{Request, Response};
use App\Models\{User, Subscription, PaymentRequest, FacebookPage, AiUsageLog};
use App\Services\AiUsageService;

class AdminDashboardController
{
    private Response $response;

    public function __construct()
    {
        $this->response = new Response();
    }

    public function index(Request $request): void
    {
        $userModel    = new User();
        $subModel     = new Subscription();
        $payModel     = new PaymentRequest();
        $fbModel      = new FacebookPage();
        $aiService    = new AiUsageService();

        $totalUsers        = $userModel->count();
        $activeSubs        = $subModel->countActive();
        $expiredSubs       = $subModel->countExpired();
        $totalRevenue      = $payModel->totalRevenue();
        $totalPages        = $fbModel->countTotal();
        $totalAiMessages   = $aiService->totalAll();
        $pendingPayments   = $payModel->countByStatus('pending');
        $recentUsers       = $userModel->all(10, 0);
        $recentPayments    = $payModel->all('pending');

        $this->response->view('admin/dashboard/index', compact(
            'totalUsers', 'activeSubs', 'expiredSubs', 'totalRevenue',
            'totalPages', 'totalAiMessages', 'pendingPayments', 'recentUsers', 'recentPayments'
        ));
    }
}
