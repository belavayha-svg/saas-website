<?php

declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Core\{Request, Response, Session, CSRF};
use App\Models\PaymentRequest;
use App\Services\SubscriptionService;

class PaymentVerificationController
{
    private Response $response;

    public function __construct()
    {
        $this->response = new Response();
    }

    public function index(Request $request): void
    {
        $status   = $request->get('status', '');
        $payments = (new PaymentRequest())->all($status);
        $success  = Session::flash('flash_success');
        $error    = Session::flash('flash_error');
        $this->response->view('admin/payments/index', compact('payments', 'status', 'success', 'error'));
    }

    public function approve(Request $request): void
    {
        CSRF::verifyOrFail();
        $id      = (int) $request->param('id');
        $service = new SubscriptionService();

        if ($service->activate($id)) {
            $this->response->withSuccess('Payment approved and subscription activated.', '/admin/payments');
        } else {
            $this->response->withError('Could not approve. Payment may already be reviewed.', '/admin/payments');
        }
    }

    public function reject(Request $request): void
    {
        CSRF::verifyOrFail();
        $id   = (int) $request->param('id');
        $note = $request->post('note', '');
        (new SubscriptionService())->reject($id, $note);
        $this->response->withSuccess('Payment rejected.', '/admin/payments');
    }
}
