<?php

declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Core\{Request, Response, Session, CSRF};
use App\Models\SystemSetting;

class SystemSettingController
{
    private Response $response;

    public function __construct()
    {
        $this->response = new Response();
    }

    public function index(Request $request): void
    {
        $settings = (new SystemSetting())->all();
        $success  = Session::flash('flash_success');
        $error    = Session::flash('flash_error');
        $this->response->view('admin/settings/index', compact('settings', 'success', 'error'));
    }

    public function update(Request $request): void
    {
        CSRF::verifyOrFail();
        $model  = new SystemSetting();
        $settings = $request->rawPost('settings');
        if (is_array($settings)) {
            foreach ($settings as $key => $val) {
                if (is_string($key) && is_string($val)) {
                    $model->set($key, trim($val));
                }
            }
        }

        // Logo upload
        $file = $request->file('logo');
        if ($file && $file['error'] === UPLOAD_ERR_OK) {
            $ext   = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
            $dir   = dirname(__DIR__, 3) . '/storage/uploads/logos';
            if (!is_dir($dir)) mkdir($dir, 0755, true);
            $fname = 'logo.' . $ext;
            move_uploaded_file($file['tmp_name'], $dir . '/' . $fname);
            $model->set('site_logo', '/storage/uploads/logos/' . $fname);
        }

        $this->response->withSuccess('Settings saved.', '/admin/settings');
    }
}
