<?php

declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Core\{Request, Response, Session, CSRF};
use App\Models\Plan;
use App\Models\PaymentMethod;

class PlanController
{
    private Response $response;

    public function __construct()
    {
        $this->response = new Response();
    }

    /* =========== PLANS =========== */

    public function index(Request $request): void
    {
        $plans   = (new Plan())->all();
        $methods = (new PaymentMethod())->all();
        $error   = Session::flash('flash_error');
        $success = Session::flash('flash_success');
        $this->response->view('admin/plans/index', compact('plans', 'methods', 'error', 'success'));
    }

    public function create(Request $request): void
    {
        $this->response->view('admin/plans/create');
    }

    public function store(Request $request): void
    {
        CSRF::verifyOrFail();
        $model = new Plan();
        $model->create([
            'plan_name'        => $request->post('plan_name'),
            'duration_days'    => (int) $request->post('duration_days', 30),
            'ai_message_limit' => (int) $request->post('ai_message_limit', 100),
            'page_limit'       => (int) $request->post('page_limit', 1),
            'price'            => (float) $request->post('price', 0),
            'status'           => $request->post('status', 'active'),
        ]);
        $this->response->withSuccess('Plan created.', '/admin/plans');
    }

    public function update(Request $request): void
    {
        CSRF::verifyOrFail();
        $id    = (int) $request->param('id');
        $model = new Plan();
        $model->update($id, [
            'plan_name'        => $request->post('plan_name'),
            'duration_days'    => (int) $request->post('duration_days', 30),
            'ai_message_limit' => (int) $request->post('ai_message_limit', 100),
            'page_limit'       => (int) $request->post('page_limit', 1),
            'price'            => (float) $request->post('price', 0),
            'status'           => $request->post('status', 'active'),
        ]);
        $this->response->withSuccess('Plan updated.', '/admin/plans');
    }

    public function delete(Request $request): void
    {
        CSRF::verifyOrFail();
        $id = (int) $request->param('id');
        (new Plan())->delete($id);
        $this->response->withSuccess('Plan deleted.', '/admin/plans');
    }

    /* =========== PAYMENT METHODS =========== */

    public function storeMethod(Request $request): void
    {
        CSRF::verifyOrFail();
        (new PaymentMethod())->create([
            'method_name'    => $request->post('method_name'),
            'account_number' => $request->post('account_number'),
            'account_holder' => $request->post('account_holder'),
            'status'         => 'active',
        ]);
        $this->response->withSuccess('Payment method added.', '/admin/plans');
    }

    public function deleteMethod(Request $request): void
    {
        CSRF::verifyOrFail();
        $id = (int) $request->param('id');
        (new PaymentMethod())->delete($id);
        $this->response->withSuccess('Payment method deleted.', '/admin/plans');
    }
}
