<?php

declare(strict_types=1);

namespace App\Controllers\Admin;

use App\Core\{Request, Response, Session};
use App\Models\{User, Product, Order};

class BusinessController
{
    private Response $response;

    public function __construct()
    {
        $this->response = new Response();
    }

    public function index(Request $request): void
    {
        $users = (new User())->all(100, 0);
        // Filter to business owners only
        $businesses = array_filter($users, fn($u) => $u['role'] === 'business');
        $this->response->view('admin/businesses/index', compact('businesses'));
    }

    public function show(Request $request): void
    {
        $id      = (int) $request->param('id');
        $user    = (new User())->findById($id);
        if (!$user || $user['role'] !== 'business') $this->response->abort(404);
        $products = (new Product())->forUser($id);
        $orders   = (new Order())->forUser($id, 20);
        $this->response->view('admin/businesses/show', compact('user', 'products', 'orders'));
    }

    /**
     * Login As Business — impersonate a user
     */
    public function loginAs(Request $request): void
    {
        $id   = (int) $request->param('id');
        $user = (new User())->findById($id);
        if (!$user || $user['role'] !== 'business') $this->response->abort(403);

        // Store admin ID for return
        Session::set('admin_impersonating', Session::user()['id']);
        Session::login($user);
        $this->response->redirect('/dashboard');
    }

    /**
     * Return to Super Admin from impersonation
     */
    public function returnToAdmin(Request $request): void
    {
        $adminId = Session::get('admin_impersonating');
        if (!$adminId) $this->response->redirect('/admin/dashboard');
        $admin = (new User())->findById((int) $adminId);
        if (!$admin) $this->response->redirect('/login');
        Session::forget('admin_impersonating');
        Session::login($admin);
        $this->response->redirect('/admin/dashboard');
    }
}
