<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Core\{Request, Response, Session, CSRF};
use App\Models\{Conversation, Message, FacebookPage};
use App\Services\FacebookService;

class ConversationController
{
    private Response $response;

    public function __construct()
    {
        $this->response = new Response();
    }

    public function index(Request $request): void
    {
        $userId = Session::user()['id'];
        $model  = new Conversation();
        $conversations = $model->forUser($userId);

        $this->response->view('conversations/index', compact('conversations'));
    }

    public function show(Request $request): void
    {
        $id     = (int)$request->param('id');
        $userId = Session::user()['id'];

        $convModel    = new Conversation();
        $conversation = $convModel->findByIdAndUser($id, $userId);

        if (!$conversation) {
            Session::set('flash_error', 'Conversation not found.');
            $this->response->redirect('/conversations');
            return;
        }

        $msgModel = new Message();
        $messages = $msgModel->getByConversation($id);

        $this->response->view('conversations/show', compact('conversation', 'messages'));
    }

    /**
     * Admin manually sends a message to the customer via Facebook Messenger.
     */
    public function sendManual(Request $request): void
    {
        CSRF::verifyOrFail();

        $id      = (int)$request->param('id');
        $userId  = Session::user()['id'];
        $text    = trim($request->rawPost('message', ''));

        if ($text === '') {
            Session::set('flash_error', 'Message cannot be empty.');
            $this->response->redirect('/conversations/' . $id);
            return;
        }

        // Ownership check
        $convModel    = new Conversation();
        $conversation = $convModel->findByIdAndUser($id, $userId);

        if (!$conversation) {
            Session::set('flash_error', 'Conversation not found.');
            $this->response->redirect('/conversations');
            return;
        }

        // Fetch the page token for this conversation's page
        $pageModel = new FacebookPage();
        $page      = $pageModel->findByPageId($conversation['page_id']);

        if (!$page || empty($page['page_token'])) {
            Session::set('flash_error', 'Facebook page token not found. Please reconnect the page.');
            $this->response->redirect('/conversations/' . $id);
            return;
        }

        // Send via Messenger API
        $fb      = new FacebookService();
        $success = $fb->sendMessage($conversation['fb_sender_id'], $text, $page['page_token']);

        // Save to DB regardless (so the admin can see their own message)
        $msgModel = new Message();
        $msgModel->add($id, 'model', $text);

        if ($success) {
            Session::set('flash_success', 'Message sent successfully.');
        } else {
            Session::set('flash_error', 'Message saved but Facebook delivery may have failed. Check the page token.');
        }

        $this->response->redirect('/conversations/' . $id);
    }
}

