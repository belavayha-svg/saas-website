<?php

declare(strict_types=1);

namespace App\Controllers;

use App\Core\{Request, Response};
use App\Models\{FacebookPage, Conversation, Message, Product, Subscription, DeliveryRule, BusinessPaymentMethod};
use App\Services\{GeminiAiService, FacebookService, SubscriptionService, AiUsageService};

/**
 * WebhookController — Handles Facebook Messenger Webhooks
 */
class WebhookController
{
    public function handle(Request $request): void
    {
        $fbService = new FacebookService();

        // 1. Handle GET – webhook verification challenge
        if ($request->method() === 'GET') {
            $challenge = $fbService->verifyWebhook($_GET);
            if ($challenge !== false) {
                http_response_code(200);
                echo $challenge;
            } else {
                http_response_code(403);
                echo 'Verification failed';
            }
            exit;
        }

        // 2. Handle POST – incoming messages
        $raw     = file_get_contents('php://input');
        $payload = json_decode($raw, true);

        if (empty($payload) || ($payload['object'] ?? '') !== 'page') {
            http_response_code(200);
            exit;
        }

        $messages = $fbService->parseIncomingMessages($payload);

        foreach ($messages as $msg) {
            $this->processMessage($msg['sender_id'], $msg['page_id'], $msg['text'], $msg['images'], $fbService);
        }

        http_response_code(200);
        echo 'EVENT_RECEIVED';
        exit;
    }

    private function processMessage(string $senderId, string $pageId, string $text, array $images, FacebookService $fbService): void
    {
        error_log("[Webhook] Incoming message from {$senderId} on page {$pageId}: {$text}");

        // Find which business owns this page
        $pageModel = new FacebookPage();
        $page      = $pageModel->findByPageId($pageId);
        if (!$page) {
            error_log("[Webhook] Warning: No registered page found for Page ID {$pageId}");
            return;
        }

        $userId    = $page['user_id'];
        $pageToken = $page['page_token'];
        error_log("[Webhook] Matched page to user_id={$userId}");

        // Check subscription + message credits
        $subService = new SubscriptionService();
        $activeSub  = $subService->getActive($userId);
        if ($activeSub !== false && !$subService->hasActiveSubscription($userId)) {
            error_log("[Webhook] User {$userId} subscription depleted/expired.");
            $fbService->sendMessage($senderId, "আপনার AI মেসেজ লিমিট শেষ হয়েছে। Please upgrade your subscription.", $pageToken);
            return;
        }

        // Get / create conversation
        $convModel = new Conversation();
        $conv      = $convModel->findOrCreate($userId, $senderId, $pageId);
        error_log("[Webhook] Conversation ID: {$conv['id']}");

        // Get message history in chronological order (oldest first)
        $msgModel = new Message();
        $history  = $msgModel->recent($conv['id'], 8);
        $history  = array_reverse($history);

        // Get business products for system prompt
        $productModel = new Product();
        $products     = $productModel->forUser($userId, activeOnly: true);

        // Get business info for system prompt
        $userModel = new \App\Models\User();
        $userInfo  = $userModel->findById($userId);
        $business  = [
            'business_name' => $userInfo['business_name'] ?? $userInfo['name'] ?? 'Our Store'
        ];

        // Get delivery rules and payment methods for system prompt
        $deliveryRuleModel = new DeliveryRule();
        $deliveryRules     = $deliveryRuleModel->forUser($userId);

        $paymentModel      = new BusinessPaymentMethod();
        $paymentMethods    = $paymentModel->forUser($userId);

        // Build system prompt
        $aiService    = new GeminiAiService();
        $systemPrompt = $aiService->buildSystemPrompt($business, $products, $deliveryRules, $paymentMethods);

        error_log("[Webhook] Calling Gemini AI for user_id={$userId}, history_count=" . count($history));

        // Format user input for AI (including images if any)
        $userInput = $text;
        if (!empty($images)) {
            $imageContext = [];
            foreach ($images as $img) {
                $imageContext[] = "[IMAGE_ATTACHED: {$img}]";
            }
            $userInput = trim($text . "\n" . implode("\n", $imageContext));
        }

        // Generate AI response
        $aiReply = $aiService->chat($history, $userInput, $systemPrompt, $images);

        error_log("[Webhook] Gemini replied: " . mb_substr($aiReply, 0, 300));

        // Parse [IMG] tags
        if (preg_match_all('/\[IMG\](.*?)\[\/IMG\]/is', $aiReply, $matches)) {
            foreach ($matches[1] as $imageUrl) {
                $imageUrl = trim($imageUrl);
                if (!empty($imageUrl)) {
                    $fbService->sendImage($senderId, $imageUrl, $pageToken);
                }
            }
            // Remove [IMG] tags from text
            $aiReply = preg_replace('/\[IMG\].*?\[\/IMG\]/is', '', $aiReply);
            $aiReply = trim($aiReply);
        }

        // ──────────────────────────────────────────────────────────────────────
        // Parse [ORDER] tags
        // FIX #1: Strip markdown code fences BEFORE JSON decoding.
        // AI may wrap JSON in ```json ... ``` which breaks json_decode().
        // ──────────────────────────────────────────────────────────────────────
        if (preg_match('/\[ORDER\](.*?)\[\/ORDER\]/is', $aiReply, $matches)) {

            // Strip any markdown code fences (```json, ```, etc.)
            $orderJson = trim($matches[1]);
            $orderJson = preg_replace('/^```(?:json)?\s*/i', '', $orderJson);
            $orderJson = preg_replace('/\s*```\s*$/i',       '', $orderJson);
            $orderJson = trim($orderJson);

            error_log("[Webhook] ORDER JSON (cleaned): " . $orderJson);

            $orderData = json_decode($orderJson, true);

            if (is_array($orderData) && !empty($orderData['products'])) {
                $totalAmount = 0;
                $orderItems  = [];
                $prodModel   = new \App\Models\Product();

                foreach ($orderData['products'] as $p) {
                    $prodId = (int)($p['id'] ?? 0);
                    $qty    = max(1, (int)($p['qty'] ?? 1));
                    $price  = (float)($p['price'] ?? 0);
                    $name   = 'Product';

                    // FIX #3: Always look up the real product from DB to get correct price & name
                    if ($prodId > 0) {
                        $product = $prodModel->findById($prodId, $userId);
                        if ($product) {
                            $name  = $product['name'];
                            $price = (float)$product['price'];
                        } else {
                            // Product ID didn't match — log it for debugging
                            error_log("[Webhook] WARNING: Product ID {$prodId} not found for user {$userId}.");
                        }
                    }

                    $totalAmount += $price * $qty;
                    $orderItems[] = [
                        'product_id'   => $prodId > 0 ? $prodId : null,
                        'product_name' => $name,
                        'quantity'     => $qty,
                        'price'        => $price,
                    ];
                }

                // Detect payment_type: "full" or "partial"
                $deliveryCharge = (float)($orderData['delivery_charge'] ?? 0);
                $paymentType    = $orderData['payment_type'] ?? 'pending';
                if (!in_array($paymentType, ['full', 'partial', 'pending'])) {
                    $paymentType = 'pending';
                }

                // Amount sent: AI calculates, we trust the value
                $paidAmount  = (float)($orderData['paid_amount'] ?? 0);
                $amountSent  = $paidAmount; // same value, stored separately for clarity

                $transactionId = !empty($orderData['transaction_id']) ? trim($orderData['transaction_id']) : null;

                $orderModel = new \App\Models\Order();
                $orderId = $orderModel->create([
                    'user_id'          => $userId,
                    'fb_sender_id'     => $senderId,
                    'page_id'          => $pageId,
                    'total_amount'     => $totalAmount,
                    'delivery_charge'  => $deliveryCharge,
                    'payment_type'     => $paymentType,
                    'paid_amount'      => $paidAmount,
                    'transaction_id'   => $transactionId,
                    'amount_sent'      => $amountSent,
                    'customer_name'    => $orderData['customer_name'] ?? null,
                    'customer_phone'   => $orderData['customer_phone'] ?? null,
                    'customer_address' => $orderData['note'] ?? null,
                    'note'             => $orderData['note'] ?? '',
                ]);

                foreach ($orderItems as $item) {
                    $orderModel->addItem($orderId, $item);
                }
                error_log("[Webhook] ✅ Created Order #{$orderId} | Type: {$paymentType} | Sent: {$amountSent} | TrxID: {$transactionId}");

            } else {
                error_log("[Webhook] ⚠️ ORDER tag found but JSON invalid or missing products. Raw: " . $orderJson);
            }

            // Remove [ORDER] tag from visible reply
            $aiReply = preg_replace('/\[ORDER\].*?\[\/ORDER\]/is', '', $aiReply);
            $aiReply = trim($aiReply);
        }

        if (empty($aiReply)) {
            $aiReply = "অর্ডার সফলভাবে নেওয়া হয়েছে! আমরা শীঘ্রই প্রক্রিয়া করব।";
        }

        // Deduct credit
        $subService->deductCredit($userId);

        // Log AI usage
        (new AiUsageService())->log($userId, $pageId, 1);

        // Save messages to DB
        $msgModel->add($conv['id'], 'user',  $userInput);
        $msgModel->add($conv['id'], 'model', $aiReply);

        // Send reply via Messenger
        $success = $fbService->sendMessage($senderId, $aiReply, $pageToken);
        if (!$success) {
            error_log("[Webhook] Error: Failed to send message to Facebook for sender {$senderId}");
        } else {
            error_log("[Webhook] Success: Replied to {$senderId}");
        }
    }
}
