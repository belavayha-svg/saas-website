<?php

declare(strict_types=1);

namespace App\Services;

/**
 * GeminiAiService — Gemini API integration (Google AI Studio)
 */
class GeminiAiService
{
    private string $apiKey;
    private string $model;
    private string $apiBase = 'https://generativelanguage.googleapis.com/v1beta/models/';

    public function __construct()
    {
        $this->apiKey = env('GEMINI_API_KEY', '');
        $this->model  = env('GEMINI_MODEL', 'gemini-2.0-flash');
    }

    /**
     * Generate a response given conversation history and business context.
     *
     * @param array  $history  [['role'=>'user'|'model','content'=>'...'], ...]
     * @param string $userText The current user message
     * @param string $systemPrompt Business-specific instructions
     * @param array  $images   Array of image URLs
     * @return string AI response text
     */
    public function chat(array $history, string $userText, string $systemPrompt = '', array $images = []): string
    {
        if (empty($this->apiKey)) {
            return 'Gemini API key not configured.';
        }

        $contents = [];

        foreach ($history as $msg) {
            $role       = $msg['role'] === 'model' ? 'model' : 'user';
            $contents[] = [
                'role'  => $role,
                'parts' => [
                    ['text' => $msg['content']]
                ]
            ];
        }

        // Current user message
        $currentUserParts   = [];
        $currentUserParts[] = ['text' => $userText];

        foreach ($images as $imgUrl) {
            $imageData = @file_get_contents($imgUrl);
            if ($imageData !== false) {
                $base64            = base64_encode($imageData);
                $mimeType          = $this->getMimeType($imgUrl, $imageData);
                $currentUserParts[] = [
                    'inlineData' => [
                        'mimeType' => $mimeType,
                        'data'     => $base64,
                    ]
                ];
            }
        }

        $contents[] = [
            'role'  => 'user',
            'parts' => $currentUserParts,
        ];

        $payload = [
            'contents'         => $contents,
            'generationConfig' => [
                'temperature'     => 0.7,
                'maxOutputTokens' => 600,
            ],
        ];

        if (!empty($systemPrompt)) {
            $payload['systemInstruction'] = [
                'parts' => [
                    ['text' => $systemPrompt]
                ]
            ];
        }

        $url      = $this->apiBase . $this->model . ':generateContent?key=' . $this->apiKey;
        $response = $this->httpPost($url, $payload);

        return $response['candidates'][0]['content']['parts'][0]['text']
            ?? 'দুঃখিত, এই মুহূর্তে উত্তর দেওয়া সম্ভব হচ্ছে না।';
    }

    private function getMimeType(string $url, string $data): string
    {
        $finfo = new \finfo(FILEINFO_MIME_TYPE);
        $mime  = $finfo->buffer($data);
        if ($mime && $mime !== 'application/x-empty') {
            return $mime;
        }
        $ext = strtolower(pathinfo(parse_url($url, PHP_URL_PATH) ?? '', PATHINFO_EXTENSION));
        return match ($ext) {
            'png'  => 'image/png',
            'gif'  => 'image/gif',
            'webp' => 'image/webp',
            default => 'image/jpeg',
        };
    }

    /**
     * Build a business-specific system prompt.
     *
     * @param array $business      Business info
     * @param array $products      Array of products
     * @param array $deliveryRules Delivery rules from DB
     * @param array $paymentMethods Payment methods from DB
     */
    public function buildSystemPrompt(array $business, array $products, array $deliveryRules = [], array $paymentMethods = []): string
    {
        $appUrl      = env('APP_URL', 'http://localhost');
        $productList = '';
        foreach ($products as $p) {
            $imageUrl     = empty($p['image']) ? 'No image' : $appUrl . $p['image'];
            $desc         = !empty($p['description']) ? mb_substr($p['description'], 0, 100) . '...' : 'No details';
            $productList .= "- {$p['name']}: ৳{$p['price']} (ID: {$p['id']}, Image: {$imageUrl}, Details: {$desc})\n";
        }

        // Delivery rules section
        $deliverySection = '';
        if (!empty($deliveryRules)) {
            $deliverySection = "\nDelivery Areas & Charges:\n";
            foreach ($deliveryRules as $rule) {
                $deliverySection .= "- {$rule['area_name']}: ৳{$rule['charge']} ({$rule['note']})\n";
            }
        }

        // Payment methods section
        $paymentSection = "\nAvailable Payment Methods:\n";
        if (!empty($paymentMethods)) {
            foreach ($paymentMethods as $pm) {
                $paymentSection .= "- {$pm['method_name']}: {$pm['account_number']}\n";
            }
        } else {
            $paymentSection .= "- Cash on Delivery (COD)\n";
        }

        return <<<PROMPT
You are an expert AI Sales Assistant for "{$business['business_name']}". You are confident, professional, warm, and concise — like a top-level sales executive, NOT a generic bot.

━━━━━━━━━━━━━━━━━━━━━━
AVAILABLE PRODUCTS:
{$productList}
{$deliverySection}
{$paymentSection}
━━━━━━━━━━━━━━━━━━━━━━

### CORE RULES (NEVER BREAK THESE):

1. **LANGUAGE**: Always respond in smart, professional Bengali. Use respectful tone (আপনি, স্যার/ম্যাডাম). Only switch to English if the customer writes in English.

2. **BREVITY**: Keep every reply short and punchy. No long paragraphs. Use emoji sparingly for friendliness.

3. **CUSTOMER LOGIN**: Customers are permanently logged in. NEVER ask them to log in again.

4. **PERSISTENT CONVERSATION**: After every order is placed, STAY ACTIVE. If the customer asks about any product again, immediately show the product catalog again and restart the sales flow.

━━━━━━━━━━━━━━━━━━━━━━
### SALES FLOW (Follow This Sequence):

**STEP 1 — Show Product:**
Suggest the product with price and image tag:
[IMG]http://full-image-url.jpg[/IMG]

**STEP 2 — Call to Action:**
Ask: "এই প্রোডাক্টটি কি অর্ডার করবেন?"

**STEP 3 — Collect Info (REQUIRED: Name + Phone + Address):**
Ask for all three in one message. You ONLY need these three to proceed. Do NOT wait for payment confirmation before collecting info.

**STEP 4 — Inform Delivery Charge & Payment:**
Once you have name, phone, address — tell them the delivery charge for their area, and ask:
"কিভাবে পেমেন্ট করতে চান? পুরো টাকা (Full) নাকি শুধু ডেলিভারি চার্জ (Partial)?"

**STEP 5 — Handle Payment:**
- If they choose **Full Payment**: Calculate `paid_amount = product_price × qty + delivery_charge`. Set `payment_type = "full"`.
- If they choose **Partial / Delivery Only**: Set `paid_amount = delivery_charge`. Set `payment_type = "partial"`.
- After they send payment, ask: "আপনার Transaction ID টি দিন।"

**STEP 6 — Generate Order Tag:**
As soon as you have Name + Phone + Address (payment details optional — use defaults if missing):
Output the hidden order tag IMMEDIATELY. Do NOT delay.

━━━━━━━━━━━━━━━━━━━━━━
### ORDER TAG FORMAT — CRITICAL RULES:

⚠️ NEVER wrap the tag in ```json or ``` code blocks. Output RAW inline text only.
⚠️ Output the [ORDER] tag as plain text mixed into your reply.
⚠️ If transaction_id is not yet provided, use "N/A".
⚠️ payment_type must be EXACTLY "full", "partial", or "pending".

CORRECT FORMAT (copy this exactly):
[ORDER]{"products":[{"id":PRODUCT_ID,"qty":1,"price":PRICE}],"payment_type":"full","paid_amount":TOTAL,"delivery_charge":CHARGE,"transaction_id":"TRX123","customer_name":"Name","customer_phone":"01XXXXXXXXX","note":"Full address here"}[/ORDER]

After outputting the tag, confirm to the customer: "✅ আপনার অর্ডার কনফার্ম হয়েছে! আমরা শীঘ্রই যোগাযোগ করব।"

━━━━━━━━━━━━━━━━━━━━━━
### IMAGE RECOGNITION:
If a customer sends an image, analyze it, find the closest matching product from inventory, and show it with price and image tag.

━━━━━━━━━━━━━━━━━━━━━━
### AFTER ORDER — STAY ACTIVE:
After every successful order, do NOT end the conversation. Say something like: "আর কিছু দরকার হলে জানাবেন! 😊" and wait. If they ask about any product, show the catalog again.
PROMPT;
    }

    private function httpPost(string $url, array $data): array
    {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => json_encode($data),
            CURLOPT_HTTPHEADER     => ['Content-Type: application/json'],
            CURLOPT_TIMEOUT        => 30,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => 0,
        ]);
        $body   = curl_exec($ch);
        $errno  = curl_errno($ch);
        $error  = curl_error($ch);
        $status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($errno) {
            error_log("[GeminiAiService] CURL Error ({$errno}): {$error}");
            return [];
        }

        $decoded = json_decode($body, true);

        if (!isset($decoded['candidates'][0]['content']['parts'][0]['text'])) {
            error_log("[GeminiAiService] Unexpected response (HTTP {$status}): " . $body);
        }

        return $decoded ?? [];
    }
}
