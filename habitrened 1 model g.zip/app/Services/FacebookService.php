<?php

declare(strict_types=1);

namespace App\Services;

/**
 * FacebookService — Messenger Send API & Webhook handling
 */
class FacebookService
{
    private string $graphUrl = 'https://graph.facebook.com/v19.0/';

    /**
     * Verify the webhook challenge handshake
     */
    public function verifyWebhook(array $query): bool|string
    {
        $verifyToken = env('FB_WEBHOOK_VERIFY_TOKEN', '');
        $mode        = $query['hub_mode'] ?? '';
        $token       = $query['hub_verify_token'] ?? '';
        $challenge   = $query['hub_challenge'] ?? '';

        if ($mode === 'subscribe' && hash_equals($verifyToken, $token)) {
            return $challenge;
        }
        return false;
    }

    /**
     * Parse incoming webhook payload and extract messages.
     * Skips echo events (bot's own sent messages) to prevent reply loops.
     * Returns array of ['sender_id', 'page_id', 'text']
     */
    public function parseIncomingMessages(array $payload): array
    {
        $messages = [];
        $entries  = $payload['entry'] ?? [];

        foreach ($entries as $entry) {
            $pageId = $entry['id'] ?? '';
            foreach ($entry['messaging'] ?? [] as $event) {
                // ✅ Fix #4: Skip echoed messages sent BY the bot itself
                if (!empty($event['message']['is_echo'])) {
                    continue;
                }

                // Process text and attachments
                if (isset($event['message']['text']) || isset($event['message']['attachments'])) {
                    $text = $event['message']['text'] ?? '';
                    $images = [];
                    
                    if (isset($event['message']['attachments'])) {
                        foreach ($event['message']['attachments'] as $attachment) {
                            if ($attachment['type'] === 'image' && isset($attachment['payload']['url'])) {
                                $images[] = $attachment['payload']['url'];
                            }
                        }
                    }

                    $messages[] = [
                        'sender_id' => $event['sender']['id'] ?? '',
                        'page_id'   => $pageId,
                        'text'      => $text,
                        'images'    => $images,
                    ];
                }
            }
        }

        return $messages;
    }

    /**
     * Send a text reply via Messenger Send API
     */
    public function sendMessage(string $recipientId, string $text, string $pageAccessToken): bool
    {
        $url  = $this->graphUrl . 'me/messages?access_token=' . $pageAccessToken;
        $body = [
            'recipient' => ['id' => $recipientId],
            'message'   => ['text' => $text],
            'messaging_type' => 'RESPONSE',
        ];

        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => json_encode($body),
            CURLOPT_HTTPHEADER     => ['Content-Type: application/json'],
            CURLOPT_TIMEOUT        => 10,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => 0,
        ]);
        $response = curl_exec($ch);
        curl_close($ch);

        $result = json_decode($response, true);
        return isset($result['message_id']);
    }

    public function sendImage(string $recipientId, string $imageUrl, string $pageAccessToken): bool
    {
        $url  = $this->graphUrl . 'me/messages?access_token=' . $pageAccessToken;
        $body = [
            'recipient' => ['id' => $recipientId],
            'message'   => [
                'attachment' => [
                    'type' => 'image',
                    'payload' => [
                        'url' => $imageUrl,
                        'is_reusable' => true
                    ]
                ]
            ],
            'messaging_type' => 'RESPONSE',
        ];

        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => json_encode($body),
            CURLOPT_HTTPHEADER     => ['Content-Type: application/json'],
            CURLOPT_TIMEOUT        => 10,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => 0,
        ]);
        $response = curl_exec($ch);
        curl_close($ch);

        $result = json_decode($response, true);
        return isset($result['message_id']);
    }

    /**
     * Exchange short-lived token for a long-lived user token (valid for 60 days).
     * The subsequent page tokens generated from this will be non-expiring.
     */
    public function getLongLivedUserToken(string $shortLivedToken): string|false
    {
        $appId     = env('FB_APP_ID', '');
        $appSecret = env('FB_APP_SECRET', '');

        if (empty($appId) || empty($appSecret)) {
            return false;
        }

        $url = $this->graphUrl . "oauth/access_token?grant_type=fb_exchange_token&client_id={$appId}&client_secret={$appSecret}&fb_exchange_token={$shortLivedToken}";

        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 15,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => 0,
        ]);
        $response = curl_exec($ch);
        curl_close($ch);

        $data = json_decode($response, true);
        return $data['access_token'] ?? false;
    }

    /**
     * Fetch page tokens using a User Access Token
     */
    public function getPageTokens(string $userAccessToken): array
    {
        $url = $this->graphUrl . 'me/accounts?access_token=' . $userAccessToken;
        $ch  = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 15,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => 0,
        ]);
        $response = curl_exec($ch);
        curl_close($ch);

        $data = json_decode($response, true) ?? [];
        return $data['data'] ?? [];
    }

    /**
     * Subscribe the Facebook App to this Page's webhooks so it receives messages
     */
    public function subscribeAppToPage(string $pageId, string $pageToken): bool
    {
        $url = $this->graphUrl . $pageId . '/subscribed_apps';
        $body = [
            'subscribed_fields' => 'messages,messaging_postbacks',
            'access_token'      => $pageToken
        ];

        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => http_build_query($body),
            CURLOPT_TIMEOUT        => 15,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => 0,
        ]);
        $response = curl_exec($ch);
        curl_close($ch);

        $result = json_decode($response, true);
        return isset($result['success']) && $result['success'] == true;
    }
}