<?php

declare(strict_types=1);

namespace App\Services;

use App\Models\AiUsageLog;

/**
 * AiUsageService — Log AI usage and provide stats
 */
class AiUsageService
{
    private AiUsageLog $model;

    public function __construct()
    {
        $this->model = new AiUsageLog();
    }

    public function log(int $userId, string $pageId, int $tokens = 1): void
    {
        $this->model->log($userId, $pageId, $tokens);
    }

    public function totalForUser(int $userId): int
    {
        return $this->model->totalForUser($userId);
    }

    public function totalAll(): int
    {
        return $this->model->totalAll();
    }

    public function dailyStats(int $userId, int $days = 30): array
    {
        return $this->model->dailyForUser($userId, $days);
    }
}
