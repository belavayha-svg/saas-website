<?php

declare(strict_types=1);

namespace App\Services;

use App\Models\Subscription;
use App\Models\PaymentRequest;

/**
 * SubscriptionService — Business logic for subscriptions
 */
class SubscriptionService
{
    private Subscription $subscriptionModel;
    private PaymentRequest $paymentModel;

    public function __construct()
    {
        $this->subscriptionModel = new Subscription();
        $this->paymentModel      = new PaymentRequest();
    }

    /**
     * Check if a user has an active, non-expired subscription with remaining credits.
     */
    public function hasActiveSubscription(int $userId): bool
    {
        $sub = $this->subscriptionModel->getActive($userId);
        if (!$sub) return false;
        // Free credit check — if remaining == -1 it's unlimited
        return $sub['remaining_messages'] === -1 || $sub['remaining_messages'] > 0;
    }

    /**
     * Get active subscription details.
     */
    public function getActive(int $userId): array|false
    {
        return $this->subscriptionModel->getActive($userId);
    }

    /**
     * Deduct one AI message credit. Returns false if limit reached.
     */
    public function deductCredit(int $userId): bool
    {
        $sub = $this->subscriptionModel->getActive($userId);
        if (!$sub) return false;
        return $this->subscriptionModel->deductMessage($sub['id']);
    }

    /**
     * Activate a subscription when admin approves payment.
     */
    public function activate(int $paymentRequestId): bool
    {
        $req = $this->paymentModel->findById($paymentRequestId);
        if (!$req || $req['payment_status'] !== 'pending') return false;

        // Mark payment as approved
        $this->paymentModel->updateStatus($paymentRequestId, 'approved');

        // Expire any existing active subscription
        $existingSub = $this->subscriptionModel->getActive($req['user_id']);
        if ($existingSub) {
            // Keep existing, just create a new one that starts now
        }

        // Create new subscription
        $this->subscriptionModel->create(
            $req['user_id'],
            $req['plan_id'],
            $req['duration_days'],
            $req['ai_message_limit']
        );

        return true;
    }

    /**
     * Reject a payment request.
     */
    public function reject(int $paymentRequestId, string $note = ''): bool
    {
        $req = $this->paymentModel->findById($paymentRequestId);
        if (!$req) return false;
        $this->paymentModel->updateStatus($paymentRequestId, 'rejected', $note);
        return true;
    }
}
