<?php

declare(strict_types=1);

namespace App\Middleware;

use App\Core\Request;

/**
 * RateLimitMiddleware — IP-based request throttling using flat file counters
 */
class RateLimitMiddleware
{
    private int $maxRequests;
    private int $windowSeconds;

    public function __construct(int $maxRequests = 60, int $windowSeconds = 60)
    {
        $this->maxRequests   = $maxRequests;
        $this->windowSeconds = $windowSeconds;
    }

    public function handle(Request $request): void
    {
        $ip      = preg_replace('/[^0-9a-fA-F.:_]/', '', $request->ip());
        $cacheDir = dirname(__DIR__, 2) . '/storage/rate_limit';

        if (!is_dir($cacheDir)) {
            mkdir($cacheDir, 0755, true);
        }

        $file = $cacheDir . '/' . md5($ip) . '.json';
        $now  = time();
        $data = ['count' => 0, 'reset_at' => $now + $this->windowSeconds];

        if (file_exists($file)) {
            $content = json_decode(file_get_contents($file), true);
            if ($content && $content['reset_at'] > $now) {
                $data = $content;
            }
        }

        $data['count']++;
        file_put_contents($file, json_encode($data), LOCK_EX);

        if ($data['count'] > $this->maxRequests) {
            http_response_code(429);
            header('Content-Type: application/json');
            echo json_encode(['error' => 'Too many requests. Please slow down.']);
            exit;
        }
    }
}
