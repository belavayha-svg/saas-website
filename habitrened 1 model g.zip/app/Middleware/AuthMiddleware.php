<?php

declare(strict_types=1);

namespace App\Middleware;

use App\Core\Request;
use App\Core\Session;
use App\Models\User;

/**
 * AuthMiddleware — Redirect unauthenticated users to /login.
 * Supports persistent auto-login via remember_me cookie.
 */
class AuthMiddleware
{
    private const REMEMBER_COOKIE = 'remember_me';
    private const REMEMBER_DAYS   = 30;

    public function handle(Request $request): void
    {
        // 1. Already logged in via session → pass through
        if (Session::isLoggedIn()) {
            $this->checkSuspended();
            return;
        }

        // 2. Try auto-login via remember_me cookie
        if (!empty($_COOKIE[self::REMEMBER_COOKIE])) {
            $token     = $_COOKIE[self::REMEMBER_COOKIE];
            $userModel = new User();
            $user      = $userModel->findByRememberToken($token);

            if ($user && ($user['status'] ?? '') === 'active') {
                // Valid token → restore session
                Session::login($user);

                // Refresh cookie lifetime
                setcookie(
                    self::REMEMBER_COOKIE,
                    $token,
                    [
                        'expires'  => time() + (self::REMEMBER_DAYS * 24 * 3600),
                        'path'     => '/',
                        'secure'   => isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
                        'httponly' => true,
                        'samesite' => 'Lax',
                    ]
                );

                // Pass through — user is now logged in
                return;
            }

            // Invalid/expired token → clear cookie
            setcookie(self::REMEMBER_COOKIE, '', [
                'expires'  => time() - 3600,
                'path'     => '/',
                'httponly' => true,
                'samesite' => 'Lax',
            ]);
            unset($_COOKIE[self::REMEMBER_COOKIE]);
        }

        // 3. Not authenticated → redirect to login
        Session::set('intended_url', $request->path());
        header('Location: /login');
        exit;
    }

    private function checkSuspended(): void
    {
        $user = Session::user();
        if (($user['status'] ?? '') === 'suspended') {
            Session::logout();
            header('Location: /login?error=suspended');
            exit;
        }
    }
}
