<?php

declare(strict_types=1);

namespace App\Middleware;

use App\Core\Request;
use App\Core\Session;

/**
 * AdminMiddleware — Restrict routes to Super Admins only
 */
class AdminMiddleware
{
    public function handle(Request $request): void
    {
        if (!Session::isLoggedIn()) {
            header('Location: /login');
            exit;
        }
        if (!Session::isSuperAdmin()) {
            http_response_code(403);
            require dirname(__DIR__, 2) . '/resources/views/errors/403.php';
            exit;
        }
    }
}
