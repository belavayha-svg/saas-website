<?php

declare(strict_types=1);

namespace App\Core;

/**
 * Response — HTTP response helpers
 */
class Response
{
    public function redirect(string $url, int $status = 302): void
    {
        http_response_code($status);
        header("Location: $url");
        exit;
    }

    public function json(mixed $data, int $status = 200): void
    {
        http_response_code($status);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        exit;
    }

    public function view(string $template, array $data = []): void
    {
        extract($data, EXTR_SKIP);
        $file = dirname(__DIR__, 2) . '/resources/views/' . $template . '.php';
        if (!file_exists($file)) {
            $this->abort(404, "View not found: $template");
        }
        require $file;
    }

    public function abort(int $code, string $message = ''): never
    {
        http_response_code($code);
        echo $message;
        exit;
    }

    public function back(): void
    {
        $this->redirect($_SERVER['HTTP_REFERER'] ?? '/');
    }

    public function withSuccess(string $message, string $url): void
    {
        Session::set('flash_success', $message);
        $this->redirect($url);
    }

    public function withError(string $message, string $url = ''): void
    {
        Session::set('flash_error', $message);
        $this->redirect($url ?: ($_SERVER['HTTP_REFERER'] ?? '/'));
    }
}
