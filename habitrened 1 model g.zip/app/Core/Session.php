<?php

declare(strict_types=1);

namespace App\Core;

/**
 * Session — Secure session management
 */
class Session
{
    public static function start(): void
    {
        if (session_status() === PHP_SESSION_NONE) {
            session_set_cookie_params([
                'lifetime' => 0,
                'path'     => '/',
                'secure'   => isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
                'httponly' => true,
                'samesite' => 'Lax',
            ]);
            session_name('SAAS_SESSION');
            session_start();
        }
    }

    public static function set(string $key, mixed $value): void
    {
        $_SESSION[$key] = $value;
    }

    public static function get(string $key, mixed $default = null): mixed
    {
        return $_SESSION[$key] ?? $default;
    }

    public static function has(string $key): bool
    {
        return isset($_SESSION[$key]);
    }

    public static function forget(string $key): void
    {
        unset($_SESSION[$key]);
    }

    public static function destroy(): void
    {
        session_unset();
        session_destroy();
    }

    public static function regenerate(): void
    {
        session_regenerate_id(true);
    }

    public static function flash(string $key): mixed
    {
        $value = self::get($key);
        self::forget($key);
        return $value;
    }

    public static function user(): array|null
    {
        return self::get('auth_user');
    }

    public static function login(array $user): void
    {
        self::regenerate();
        self::set('auth_user', $user);
    }

    public static function logout(): void
    {
        self::destroy();
    }

    public static function isLoggedIn(): bool
    {
        return self::has('auth_user');
    }

    public static function isSuperAdmin(): bool
    {
        return (self::user()['role'] ?? '') === 'super_admin';
    }
}
