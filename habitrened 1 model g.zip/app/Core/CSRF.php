<?php

declare(strict_types=1);

namespace App\Core;

/**
 * CSRF — Token generation and validation
 */
class CSRF
{
    private const TOKEN_KEY = 'csrf_token';

    public static function token(): string
    {
        if (!Session::has(self::TOKEN_KEY)) {
            Session::set(self::TOKEN_KEY, bin2hex(random_bytes(32)));
        }
        return Session::get(self::TOKEN_KEY) ?? '';
    }

    public static function field(): string
    {
        $token = self::token();
        return "<input type=\"hidden\" name=\"_csrf\" value=\"{$token}\">";
    }

    public static function validate(): bool
    {
        $token  = Session::get(self::TOKEN_KEY, '');
        $input  = $_POST['_csrf'] ?? $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
        return !empty($token) && hash_equals($token, $input);
    }

    public static function verifyOrFail(): void
    {
        if (!self::validate()) {
            http_response_code(403);
            echo json_encode(['error' => 'CSRF token mismatch.']);
            exit;
        }
    }
}
