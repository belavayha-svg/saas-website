<?php

declare(strict_types=1);

namespace App\Core;

/**
 * Router — Simple RESTful router with middleware support
 */
class Router
{
    private array $routes = [];
    private array $middlewareGroups = [];
    private string $currentGroup = '';
    private array $currentMiddleware = [];

    public function get(string $path, array|callable $handler): void
    {
        $this->addRoute('GET', $path, $handler);
    }

    public function post(string $path, array|callable $handler): void
    {
        $this->addRoute('POST', $path, $handler);
    }

    public function put(string $path, array|callable $handler): void
    {
        $this->addRoute('PUT', $path, $handler);
    }

    public function delete(string $path, array|callable $handler): void
    {
        $this->addRoute('DELETE', $path, $handler);
    }

    public function group(array $options, callable $callback): void
    {
        $prevGroup      = $this->currentGroup;
        $prevMiddleware = $this->currentMiddleware;

        $this->currentGroup     = $prevGroup . ($options['prefix'] ?? '');
        $this->currentMiddleware = array_merge($prevMiddleware, $options['middleware'] ?? []);

        $callback($this);

        $this->currentGroup      = $prevGroup;
        $this->currentMiddleware = $prevMiddleware;
    }

    private function addRoute(string $method, string $path, array|callable $handler): void
    {
        $this->routes[] = [
            'method'     => $method,
            'path'       => $this->currentGroup . $path,
            'handler'    => $handler,
            'middleware' => $this->currentMiddleware,
        ];
    }

    public function dispatch(Request $request): void
    {
        $method = $request->method();
        $uri    = $request->path();

        foreach ($this->routes as $route) {
            $pattern = $this->buildPattern($route['path']);
            if ($route['method'] === $method && preg_match($pattern, $uri, $matches)) {
                // Extract named params
                $params = array_filter($matches, fn($k) => !is_int($k), ARRAY_FILTER_USE_KEY);
                $request->setParams($params);

                // Run middleware
                foreach ($route['middleware'] as $mw) {
                    $middleware = new $mw();
                    $middleware->handle($request);
                }

                // Invoke controller
                $this->invoke($route['handler'], $request);
                return;
            }
        }

        // 404
        http_response_code(404);
        require dirname(__DIR__, 2) . '/resources/views/errors/404.php';
    }

    private function buildPattern(string $path): string
    {
        // Convert :param to named capture groups
        $pattern = preg_replace('/\/:([a-zA-Z_]+)/', '/(?P<$1>[^/]+)', $path);
        return '#^' . $pattern . '/?$#';
    }

    private function invoke(array|callable $handler, Request $request): void
    {
        if (is_callable($handler)) {
            $handler($request);
            return;
        }

        [$class, $method] = $handler;
        $controller = new $class();
        $controller->$method($request);
    }
}
