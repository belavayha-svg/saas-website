<?php

declare(strict_types=1);

namespace App\Core;

/**
 * Request — Wraps HTTP input with XSS sanitization
 */
class Request
{
    private array $params = [];

    public function method(): string
    {
        $method = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');
        // Support _method spoofing for PUT/DELETE
        if ($method === 'POST' && isset($_POST['_method'])) {
            $method = strtoupper($_POST['_method']);
        }
        return $method;
    }

    public function path(): string
    {
        $uri = $_SERVER['REQUEST_URI'] ?? '/';
        $path = parse_url($uri, PHP_URL_PATH);
        return rtrim($path, '/') ?: '/';
    }

    public function get(string $key, mixed $default = null): mixed
    {
        return $this->clean($_GET[$key] ?? $default);
    }

    public function post(string $key, mixed $default = null): mixed
    {
        return $this->clean($_POST[$key] ?? $default);
    }

    public function input(string $key, mixed $default = null): mixed
    {
        return $this->post($key) ?? $this->get($key) ?? $default;
    }

    public function all(): array
    {
        return array_map([$this, 'clean'], array_merge($_GET, $_POST));
    }

    public function file(string $key): array|null
    {
        return $_FILES[$key] ?? null;
    }

    public function isPost(): bool
    {
        return $this->method() === 'POST';
    }

    public function isAjax(): bool
    {
        return ($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '') === 'XMLHttpRequest';
    }

    public function ip(): string
    {
        return $_SERVER['HTTP_X_FORWARDED_FOR']
            ?? $_SERVER['REMOTE_ADDR']
            ?? '0.0.0.0';
    }

    public function setParams(array $params): void
    {
        $this->params = $params;
    }

    public function param(string $key, mixed $default = null): mixed
    {
        return $this->clean($this->params[$key] ?? $default);
    }

    private function clean(mixed $value): mixed
    {
        if (is_array($value)) {
            return array_map([$this, 'clean'], $value);
        }
        if (is_string($value)) {
            return htmlspecialchars(trim($value), ENT_QUOTES, 'UTF-8');
        }
        return $value;
    }

    public function rawPost(string $key, mixed $default = null): mixed
    {
        return $_POST[$key] ?? $default;
    }
}
