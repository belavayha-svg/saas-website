<?php

declare(strict_types=1);

namespace App\Models;

use App\Core\Database;

/**
 * Message — Chat history per conversation
 */
class Message
{
    private Database $db;

    public function __construct()
    {
        $this->db = Database::getInstance();
    }

    public function add(int $conversationId, string $role, string $content): void
    {
        $this->db->execute(
            'INSERT INTO messages (conversation_id, role, content) VALUES (?,?,?)',
            [$conversationId, $role, $content]
        );
    }

    /**
     * Get last N messages for Gemini/AI history.
     * Limit is cast to int so PDO PARAM_INT is used — fixes LIMIT crash.
     */
    public function recent(int $conversationId, int $limit = 10): array
    {
        return $this->db->fetchAll(
            'SELECT role, content FROM messages WHERE conversation_id=? ORDER BY id DESC LIMIT ?',
            [$conversationId, $limit]
        );
    }

    public function getByConversation(int $conversationId): array
    {
        return $this->db->fetchAll(
            'SELECT * FROM messages WHERE conversation_id = ? ORDER BY id ASC',
            [$conversationId]
        );
    }
}
