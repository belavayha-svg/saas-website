<?php

declare(strict_types=1);

namespace App\Models;

use App\Core\Database;

class PaymentMethod
{
    private Database $db;

    public function __construct()
    {
        $this->db = Database::getInstance();
    }

    public function all(bool $onlyActive = false): array
    {
        $sql = 'SELECT * FROM payment_methods';
        if ($onlyActive) $sql .= " WHERE status = 'active'";
        $sql .= ' ORDER BY id ASC';
        return $this->db->fetchAll($sql);
    }

    public function findById(int $id): array|false
    {
        return $this->db->fetchOne('SELECT * FROM payment_methods WHERE id = ?', [$id]);
    }

    public function create(array $data): int
    {
        $this->db->execute(
            'INSERT INTO payment_methods (method_name, account_number, account_holder, status) VALUES (?,?,?,?)',
            [$data['method_name'], $data['account_number'], $data['account_holder'], $data['status'] ?? 'active']
        );
        return (int) $this->db->lastInsertId();
    }

    public function update(int $id, array $data): int
    {
        return $this->db->execute(
            'UPDATE payment_methods SET method_name=?, account_number=?, account_holder=?, status=? WHERE id=?',
            [$data['method_name'], $data['account_number'], $data['account_holder'], $data['status'], $id]
        );
    }

    public function delete(int $id): int
    {
        return $this->db->execute('DELETE FROM payment_methods WHERE id=?', [$id]);
    }
}
