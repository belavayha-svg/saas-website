<?php

declare(strict_types=1);

namespace App\Models;

use App\Core\Database;

class AiUsageLog
{
    private Database $db;

    public function __construct()
    {
        $this->db = Database::getInstance();
    }

    public function log(int $userId, string $pageId, int $tokens = 1): void
    {
        $this->db->execute(
            'INSERT INTO ai_usage_logs (user_id, page_id, tokens_used) VALUES (?,?,?)',
            [$userId, $pageId, $tokens]
        );
    }

    public function totalForUser(int $userId): int
    {
        $row = $this->db->fetchOne('SELECT SUM(tokens_used) as total FROM ai_usage_logs WHERE user_id=?', [$userId]);
        return (int) ($row['total'] ?? 0);
    }

    public function totalAll(): int
    {
        $row = $this->db->fetchOne('SELECT SUM(tokens_used) as total FROM ai_usage_logs');
        return (int) ($row['total'] ?? 0);
    }

    public function dailyForUser(int $userId, int $days = 30): array
    {
        return $this->db->fetchAll(
            "SELECT DATE(created_at) as date, SUM(tokens_used) as total FROM ai_usage_logs WHERE user_id=? AND created_at >= DATE_SUB(NOW(), INTERVAL ? DAY) GROUP BY DATE(created_at) ORDER BY date ASC",
            [$userId, $days]
        );
    }
}
