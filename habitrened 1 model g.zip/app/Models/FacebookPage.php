<?php

declare(strict_types=1);

namespace App\Models;

use App\Core\Database;

class FacebookPage
{
    private Database $db;

    public function __construct()
    {
        $this->db = Database::getInstance();
    }

    public function forUser(int $userId): array
    {
        return $this->db->fetchAll('SELECT * FROM facebook_pages WHERE user_id=? ORDER BY id DESC', [$userId]);
    }

    public function findByPageId(string $pageId): array|false
    {
        return $this->db->fetchOne("SELECT fp.*, u.id as owner_id FROM facebook_pages fp JOIN users u ON u.id=fp.user_id WHERE fp.page_id=? AND fp.status='active' LIMIT 1", [$pageId]);
    }

    public function countForUser(int $userId): int
    {
        $row = $this->db->fetchOne("SELECT COUNT(*) as cnt FROM facebook_pages WHERE user_id=? AND status='active'", [$userId]);
        return (int) ($row['cnt'] ?? 0);
    }

    public function countTotal(): int
    {
        $row = $this->db->fetchOne("SELECT COUNT(*) as cnt FROM facebook_pages WHERE status='active'");
        return (int) ($row['cnt'] ?? 0);
    }

    public function create(int $userId, string $pageId, string $pageName, string $pageToken): int
    {
        // Upsert
        $existing = $this->db->fetchOne('SELECT id FROM facebook_pages WHERE user_id=? AND page_id=?', [$userId, $pageId]);
        if ($existing) {
            $this->db->execute(
                "UPDATE facebook_pages SET page_name=?, page_token=?, status='active' WHERE id=?",
                [$pageName, $pageToken, $existing['id']]
            );
            return $existing['id'];
        }
        $this->db->execute(
            'INSERT INTO facebook_pages (user_id, page_id, page_name, page_token) VALUES (?,?,?,?)',
            [$userId, $pageId, $pageName, $pageToken]
        );
        return (int) $this->db->lastInsertId();
    }

    public function disconnect(int $id, int $userId): int
    {
        return $this->db->execute("UPDATE facebook_pages SET status='inactive' WHERE id=? AND user_id=?", [$id, $userId]);
    }

    public function findById(int $id, int $userId): array|false
    {
        return $this->db->fetchOne('SELECT * FROM facebook_pages WHERE id=? AND user_id=?', [$id, $userId]);
    }
}
