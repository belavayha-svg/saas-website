<?php

declare(strict_types=1);

namespace App\Models;

use App\Core\Database;

class Order
{
    private Database $db;

    public function __construct()
    {
        $this->db = Database::getInstance();
    }

    public function forUser(int $userId, int $limit = 50, int $offset = 0, string $status = '', string $paymentType = ''): array
    {
        $sql    = 'SELECT * FROM orders WHERE user_id=?';
        $params = [$userId];

        if ($status !== '') {
            $sql      .= ' AND status=?';
            $params[]  = $status;
        }
        if ($paymentType !== '') {
            $sql      .= ' AND payment_type=?';
            $params[]  = $paymentType;
        }

        $sql      .= ' ORDER BY id DESC LIMIT ? OFFSET ?';
        $params[]  = $limit;
        $params[]  = $offset;

        return $this->db->fetchAll($sql, $params);
    }

    public function findById(int $id, int $userId): array|false
    {
        return $this->db->fetchOne('SELECT * FROM orders WHERE id=? AND user_id=?', [$id, $userId]);
    }

    public function create(array $data): int
    {
        $this->db->execute(
            'INSERT INTO orders
             (user_id, fb_sender_id, page_id, total_amount, delivery_charge, payment_type,
              paid_amount, transaction_id, amount_sent, customer_name, customer_phone, customer_address, note)
             VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)',
            [
                $data['user_id'],
                $data['fb_sender_id'],
                $data['page_id'],
                $data['total_amount']      ?? 0,
                $data['delivery_charge']   ?? 0,
                $data['payment_type']      ?? 'pending',
                $data['paid_amount']       ?? 0,
                $data['transaction_id']    ?? null,
                $data['amount_sent']       ?? 0,
                $data['customer_name']     ?? null,
                $data['customer_phone']    ?? null,
                $data['customer_address']  ?? null,
                $data['note']              ?? null,
            ]
        );
        return (int) $this->db->lastInsertId();
    }

    public function addItem(int $orderId, array $item): void
    {
        $this->db->execute(
            'INSERT INTO order_items (order_id, product_id, product_name, quantity, price) VALUES (?,?,?,?,?)',
            [$orderId, $item['product_id'] ?? null, $item['product_name'], $item['quantity'], $item['price']]
        );
    }

    public function getItems(int $orderId): array
    {
        return $this->db->fetchAll('SELECT * FROM order_items WHERE order_id=?', [$orderId]);
    }

    public function updateStatus(int $id, int $userId, string $status): int
    {
        return $this->db->execute('UPDATE orders SET status=? WHERE id=? AND user_id=?', [$status, $id, $userId]);
    }

    public function updatePayment(int $id, int $userId, array $data): int
    {
        return $this->db->execute(
            'UPDATE orders
             SET payment_type=?, delivery_charge=?, paid_amount=?, transaction_id=?,
                 amount_sent=?, customer_name=?, customer_phone=?, customer_address=?
             WHERE id=? AND user_id=?',
            [
                $data['payment_type']     ?? 'pending',
                $data['delivery_charge']  ?? 0,
                $data['paid_amount']      ?? 0,
                $data['transaction_id']   ?? null,
                $data['amount_sent']      ?? 0,
                $data['customer_name']    ?? null,
                $data['customer_phone']   ?? null,
                $data['customer_address'] ?? null,
                $id,
                $userId,
            ]
        );
    }

    public function count(int $userId, string $status = '', string $paymentType = ''): int
    {
        $sql    = 'SELECT COUNT(*) as cnt FROM orders WHERE user_id=?';
        $params = [$userId];

        if ($status !== '') {
            $sql      .= ' AND status=?';
            $params[]  = $status;
        }
        if ($paymentType !== '') {
            $sql      .= ' AND payment_type=?';
            $params[]  = $paymentType;
        }

        $row = $this->db->fetchOne($sql, $params);
        return (int) ($row['cnt'] ?? 0);
    }

    public function countByStatus(int $userId, string $status): int
    {
        $row = $this->db->fetchOne('SELECT COUNT(*) as cnt FROM orders WHERE user_id=? AND status=?', [$userId, $status]);
        return (int) ($row['cnt'] ?? 0);
    }

    public function revenueByPeriod(int $userId, string $period = 'month'): float
    {
        $map  = ['day' => 'DATE(created_at)=CURDATE()', 'week' => 'YEARWEEK(created_at)=YEARWEEK(NOW())', 'month' => 'MONTH(created_at)=MONTH(NOW()) AND YEAR(created_at)=YEAR(NOW())'];
        $cond = $map[$period] ?? $map['month'];
        $row  = $this->db->fetchOne("SELECT SUM(total_amount) as total FROM orders WHERE user_id=? AND $cond AND status NOT IN ('cancelled')", [$userId]);
        return (float) ($row['total'] ?? 0);
    }

    public function dailyOrders(int $userId, int $days = 30): array
    {
        return $this->db->fetchAll(
            "SELECT DATE(created_at) as date, COUNT(*) as count, SUM(total_amount) as revenue FROM orders WHERE user_id=? AND created_at >= DATE_SUB(NOW(), INTERVAL ? DAY) GROUP BY DATE(created_at) ORDER BY date ASC",
            [$userId, $days]
        );
    }
}
