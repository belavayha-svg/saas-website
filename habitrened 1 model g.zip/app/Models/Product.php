<?php

declare(strict_types=1);

namespace App\Models;

use App\Core\Database;

class Product
{
    private Database $db;

    public function __construct()
    {
        $this->db = Database::getInstance();
    }

    public function forUser(int $userId, bool $activeOnly = false): array
    {
        $sql = 'SELECT * FROM products WHERE user_id=?';
        if ($activeOnly) $sql .= " AND status='active'";
        $sql .= ' ORDER BY id DESC';
        return $this->db->fetchAll($sql, [$userId]);
    }

    public function findById(int $id, int $userId): array|false
    {
        return $this->db->fetchOne('SELECT * FROM products WHERE id=? AND user_id=?', [$id, $userId]);
    }

    public function create(array $data): int
    {
        $this->db->execute(
            'INSERT INTO products (user_id, name, colors, description, price, image, image_2, image_3, image_4, status) VALUES (?,?,?,?,?,?,?,?,?,?)',
            [
                $data['user_id'], 
                $data['name'], 
                $data['colors'] ?? null, 
                $data['description'] ?? '', 
                $data['price'], 
                $data['image'] ?? null, 
                $data['image_2'] ?? null, 
                $data['image_3'] ?? null, 
                $data['image_4'] ?? null, 
                $data['status'] ?? 'active'
            ]
        );
        return (int) $this->db->lastInsertId();
    }

    public function update(int $id, int $userId, array $data): int
    {
        return $this->db->execute(
            'UPDATE products SET name=?, colors=?, description=?, price=?, status=? WHERE id=? AND user_id=?',
            [$data['name'], $data['colors'] ?? null, $data['description'] ?? '', $data['price'], $data['status'] ?? 'active', $id, $userId]
        );
    }

    public function updateImage(int $id, string $path, string $column = 'image'): void
    {
        $allowedColumns = ['image', 'image_2', 'image_3', 'image_4'];
        if (!in_array($column, $allowedColumns)) {
            $column = 'image';
        }
        $this->db->execute("UPDATE products SET {$column}=? WHERE id=?", [$path, $id]);
    }

    public function delete(int $id, int $userId): int
    {
        return $this->db->execute('DELETE FROM products WHERE id=? AND user_id=?', [$id, $userId]);
    }

    public function count(int $userId): int
    {
        $row = $this->db->fetchOne('SELECT COUNT(*) as cnt FROM products WHERE user_id=?', [$userId]);
        return (int) ($row['cnt'] ?? 0);
    }
}
