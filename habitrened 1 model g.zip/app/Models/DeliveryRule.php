<?php

declare(strict_types=1);

namespace App\Models;

use App\Core\Database;

class DeliveryRule
{
    private Database $db;

    public function __construct()
    {
        $this->db = Database::getInstance();
    }

    public function forUser(int $userId): array
    {
        return $this->db->fetchAll(
            'SELECT * FROM delivery_rules WHERE user_id=? ORDER BY id ASC',
            [$userId]
        );
    }

    public function findById(int $id, int $userId): array|false
    {
        return $this->db->fetchOne(
            'SELECT * FROM delivery_rules WHERE id=? AND user_id=?',
            [$id, $userId]
        );
    }

    public function create(array $data): int
    {
        $this->db->execute(
            'INSERT INTO delivery_rules (user_id, area_name, charge, note) VALUES (?,?,?,?)',
            [$data['user_id'], $data['area_name'], $data['charge'] ?? 0, $data['note'] ?? null]
        );
        return (int) $this->db->lastInsertId();
    }

    public function update(int $id, int $userId, array $data): int
    {
        return $this->db->execute(
            'UPDATE delivery_rules SET area_name=?, charge=?, note=? WHERE id=? AND user_id=?',
            [$data['area_name'], $data['charge'] ?? 0, $data['note'] ?? null, $id, $userId]
        );
    }

    public function delete(int $id, int $userId): int
    {
        return $this->db->execute(
            'DELETE FROM delivery_rules WHERE id=? AND user_id=?',
            [$id, $userId]
        );
    }
}
