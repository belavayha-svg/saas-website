<?php

declare(strict_types=1);

namespace App\Models;

use App\Core\Database;

class BusinessPaymentMethod
{
    private Database $db;

    public function __construct()
    {
        $this->db = Database::getInstance();
    }

    public function forUser(int $userId): array
    {
        return $this->db->fetchAll(
            'SELECT * FROM business_payment_methods WHERE user_id=? ORDER BY id ASC',
            [$userId]
        );
    }

    public function create(array $data): int
    {
        $this->db->execute(
            'INSERT INTO business_payment_methods (user_id, method_name, account_number) VALUES (?,?,?)',
            [$data['user_id'], $data['method_name'], $data['account_number']]
        );
        return (int) $this->db->lastInsertId();
    }

    public function delete(int $id, int $userId): int
    {
        return $this->db->execute(
            'DELETE FROM business_payment_methods WHERE id=? AND user_id=?',
            [$id, $userId]
        );
    }
}
