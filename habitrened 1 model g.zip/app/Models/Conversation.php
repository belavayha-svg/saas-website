<?php

declare(strict_types=1);

namespace App\Models;

use App\Core\Database;

/**
 * Conversation — Messenger thread per business user
 */
class Conversation
{
    private Database $db;

    public function __construct()
    {
        $this->db = Database::getInstance();
    }

    public function findOrCreate(int $userId, string $senderId, string $pageId): array
    {
        $conv = $this->db->fetchOne(
            'SELECT * FROM conversations WHERE user_id=? AND fb_sender_id=? AND page_id=?',
            [$userId, $senderId, $pageId]
        );
        if ($conv) return $conv;

        $this->db->execute(
            'INSERT INTO conversations (user_id, fb_sender_id, page_id) VALUES (?,?,?)',
            [$userId, $senderId, $pageId]
        );
        return $this->db->fetchOne('SELECT * FROM conversations WHERE id=?', [$this->db->lastInsertId()]);
    }

    public function forUser(int $userId): array
    {
        return $this->db->fetchAll(
            'SELECT c.*, p.page_name, 
             (SELECT content FROM messages m WHERE m.conversation_id = c.id ORDER BY created_at DESC LIMIT 1) as last_message,
             (SELECT created_at FROM messages m WHERE m.conversation_id = c.id ORDER BY created_at DESC LIMIT 1) as last_message_time
             FROM conversations c
             LEFT JOIN facebook_pages p ON c.page_id = p.page_id
             WHERE c.user_id = ?
             ORDER BY last_message_time DESC',
            [$userId]
        );
    }
    
    public function findByIdAndUser(int $id, int $userId): ?array
    {
        return $this->db->fetchOne(
            'SELECT c.*, p.page_name 
             FROM conversations c
             LEFT JOIN facebook_pages p ON c.page_id = p.page_id 
             WHERE c.id = ? AND c.user_id = ?',
            [$id, $userId]
        ) ?: null;
    }
}
