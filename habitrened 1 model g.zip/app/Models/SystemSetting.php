<?php

declare(strict_types=1);

namespace App\Models;

use App\Core\Database;

class SystemSetting
{
    private Database $db;
    private array $cache = [];

    public function __construct()
    {
        $this->db = Database::getInstance();
    }

    public function get(string $key, string $default = ''): string
    {
        if (isset($this->cache[$key])) return $this->cache[$key];

        $row = $this->db->fetchOne('SELECT setting_value FROM system_settings WHERE setting_key=?', [$key]);
        $value = $row ? ($row['setting_value'] ?? $default) : $default;
        $this->cache[$key] = $value;
        return $value;
    }

    public function set(string $key, string $value): void
    {
        $this->db->execute(
            'INSERT INTO system_settings (setting_key, setting_value) VALUES (?,?) ON DUPLICATE KEY UPDATE setting_value=?',
            [$key, $value, $value]
        );
        $this->cache[$key] = $value;
    }

    public function all(): array
    {
        $rows   = $this->db->fetchAll('SELECT setting_key, setting_value FROM system_settings');
        $result = [];
        foreach ($rows as $row) {
            $result[$row['setting_key']] = $row['setting_value'];
        }
        return $result;
    }
}
