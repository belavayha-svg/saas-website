<?php

declare(strict_types=1);

namespace App\Models;

use App\Core\Database;

class Subscription
{
    private Database $db;

    public function __construct()
    {
        $this->db = Database::getInstance();
    }

    public function getActive(int $userId): array|false
    {
        return $this->db->fetchOne(
            "SELECT s.*, p.plan_name, p.ai_message_limit, p.page_limit
             FROM subscriptions s
             JOIN plans p ON p.id = s.plan_id
             WHERE s.user_id = ? AND s.status = 'active' AND s.end_date >= CURDATE()
             ORDER BY s.id DESC LIMIT 1",
            [$userId]
        );
    }

    public function create(int $userId, int $planId, int $durationDays, int $messageLimit): int
    {
        $start = date('Y-m-d');
        $end   = date('Y-m-d', strtotime("+{$durationDays} days"));
        $this->db->execute(
            'INSERT INTO subscriptions (user_id, plan_id, start_date, end_date, remaining_messages, status) VALUES (?,?,?,?,?,?)',
            [$userId, $planId, $start, $end, $messageLimit, 'active']
        );
        return (int) $this->db->lastInsertId();
    }

    public function deductMessage(int $subscriptionId): bool
    {
        $sub = $this->db->fetchOne('SELECT * FROM subscriptions WHERE id = ?', [$subscriptionId]);
        if (!$sub) return false;

        $remaining = (int) $sub['remaining_messages'];

        if ($remaining === -1) return true; // unlimited plan
        if ($remaining <= 0)  return false; // depleted

        $this->db->execute(
            'UPDATE subscriptions SET remaining_messages = remaining_messages - 1 WHERE id = ?',
            [$subscriptionId]
        );
        return true;
    }

    public function expireOld(int $userId): void
    {
        $this->db->execute(
            "UPDATE subscriptions SET status='expired' WHERE user_id=? AND (end_date < CURDATE() OR status='active') AND id != (SELECT id FROM (SELECT id FROM subscriptions WHERE user_id=? AND status='active' ORDER BY id DESC LIMIT 1) t)",
            [$userId, $userId]
        );
    }

    public function history(int $userId): array
    {
        return $this->db->fetchAll(
            'SELECT s.*, p.plan_name FROM subscriptions s JOIN plans p ON p.id=s.plan_id WHERE s.user_id=? ORDER BY s.id DESC',
            [$userId]
        );
    }

    public function countActive(): int
    {
        $row = $this->db->fetchOne("SELECT COUNT(*) as cnt FROM subscriptions WHERE status='active' AND end_date >= CURDATE()");
        return (int) ($row['cnt'] ?? 0);
    }

    public function countExpired(): int
    {
        $row = $this->db->fetchOne("SELECT COUNT(*) as cnt FROM subscriptions WHERE status='expired' OR end_date < CURDATE()");
        return (int) ($row['cnt'] ?? 0);
    }
}
