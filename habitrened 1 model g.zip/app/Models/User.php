<?php

declare(strict_types=1);

namespace App\Models;

use App\Core\Database;

class User
{
    private Database $db;

    public function __construct()
    {
        $this->db = Database::getInstance();
    }

    public function findById(int $id): array|false
    {
        return $this->db->fetchOne('SELECT * FROM users WHERE id = ?', [$id]);
    }

    public function findByEmail(string $email): array|false
    {
        return $this->db->fetchOne('SELECT * FROM users WHERE email = ?', [$email]);
    }

    /** Find user by remember_me token (for auto-login) */
    public function findByRememberToken(string $token): array|false
    {
        return $this->db->fetchOne(
            'SELECT * FROM users WHERE remember_token = ? AND status = "active" LIMIT 1',
            [$token]
        );
    }

    /** Save a remember_me token for the user */
    public function setRememberToken(int $id, string $token): void
    {
        $this->db->execute('UPDATE users SET remember_token = ? WHERE id = ?', [$token, $id]);
    }

    /** Clear the remember_me token on logout */
    public function clearRememberToken(int $id): void
    {
        $this->db->execute('UPDATE users SET remember_token = NULL WHERE id = ?', [$id]);
    }

    public function create(array $data): int|false
    {
        $this->db->execute(
            'INSERT INTO users (name, email, password, role, status, business_name) VALUES (?,?,?,?,?,?)',
            [
                $data['name'],
                $data['email'],
                password_hash($data['password'], PASSWORD_BCRYPT, ['cost' => 12]),
                $data['role'] ?? 'business',
                'active',
                $data['business_name'] ?? null,
            ]
        );
        return (int) $this->db->lastInsertId();
    }

    public function update(int $id, array $data): int
    {
        $fields = [];
        $values = [];
        foreach ($data as $col => $val) {
            if ($col === 'password') {
                $val = password_hash($val, PASSWORD_BCRYPT, ['cost' => 12]);
            }
            $fields[] = "`$col` = ?";
            $values[] = $val;
        }
        $values[] = $id;
        return $this->db->execute(
            'UPDATE users SET ' . implode(', ', $fields) . ' WHERE id = ?',
            $values
        );
    }

    public function delete(int $id): int
    {
        return $this->db->execute('DELETE FROM users WHERE id = ?', [$id]);
    }

    public function setStatus(int $id, string $status): int
    {
        return $this->db->execute('UPDATE users SET status = ? WHERE id = ?', [$status, $id]);
    }

    public function all(int $limit = 100, int $offset = 0): array
    {
        return $this->db->fetchAll(
            'SELECT id, name, email, role, status, business_name, created_at FROM users ORDER BY id DESC LIMIT ? OFFSET ?',
            [$limit, $offset]
        );
    }

    public function count(): int
    {
        $row = $this->db->fetchOne('SELECT COUNT(*) as cnt FROM users WHERE role = "business"');
        return (int) ($row['cnt'] ?? 0);
    }

    public function verifyPassword(string $plain, string $hash): bool
    {
        return password_verify($plain, $hash);
    }
}
