<?php

declare(strict_types=1);

namespace App\Models;

use App\Core\Database;

class PaymentRequest
{
    private Database $db;

    public function __construct()
    {
        $this->db = Database::getInstance();
    }

    public function create(array $data): int
    {
        $this->db->execute(
            'INSERT INTO payment_requests (user_id, plan_id, trx_id, payment_method, amount) VALUES (?,?,?,?,?)',
            [$data['user_id'], $data['plan_id'], $data['trx_id'], $data['payment_method'], $data['amount']]
        );
        return (int) $this->db->lastInsertId();
    }

    public function forUser(int $userId): array
    {
        return $this->db->fetchAll(
            'SELECT pr.*, p.plan_name FROM payment_requests pr JOIN plans p ON p.id=pr.plan_id WHERE pr.user_id=? ORDER BY pr.id DESC',
            [$userId]
        );
    }

    public function all(string $status = ''): array
    {
        if ($status) {
            return $this->db->fetchAll(
                'SELECT pr.*, u.name as user_name, u.email, p.plan_name FROM payment_requests pr JOIN users u ON u.id=pr.user_id JOIN plans p ON p.id=pr.plan_id WHERE pr.payment_status=? ORDER BY pr.id DESC',
                [$status]
            );
        }
        return $this->db->fetchAll(
            'SELECT pr.*, u.name as user_name, u.email, p.plan_name FROM payment_requests pr JOIN users u ON u.id=pr.user_id JOIN plans p ON p.id=pr.plan_id ORDER BY pr.id DESC'
        );
    }

    public function findById(int $id): array|false
    {
        return $this->db->fetchOne(
            'SELECT pr.*, u.name as user_name, p.plan_name, p.duration_days, p.ai_message_limit FROM payment_requests pr JOIN users u ON u.id=pr.user_id JOIN plans p ON p.id=pr.plan_id WHERE pr.id=?',
            [$id]
        );
    }

    public function updateStatus(int $id, string $status, string $note = ''): int
    {
        return $this->db->execute(
            'UPDATE payment_requests SET payment_status=?, note=?, reviewed_at=NOW() WHERE id=?',
            [$status, $note, $id]
        );
    }

    public function countByStatus(string $status): int
    {
        $row = $this->db->fetchOne('SELECT COUNT(*) as cnt FROM payment_requests WHERE payment_status=?', [$status]);
        return (int) ($row['cnt'] ?? 0);
    }

    public function totalRevenue(): float
    {
        $row = $this->db->fetchOne("SELECT SUM(amount) as total FROM payment_requests WHERE payment_status='approved'");
        return (float) ($row['total'] ?? 0);
    }
}
