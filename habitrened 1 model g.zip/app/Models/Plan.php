<?php

declare(strict_types=1);

namespace App\Models;

use App\Core\Database;

class Plan
{
    private Database $db;

    public function __construct()
    {
        $this->db = Database::getInstance();
    }

    public function all(bool $onlyActive = false): array
    {
        $sql = 'SELECT * FROM plans';
        if ($onlyActive) $sql .= " WHERE status = 'active'";
        $sql .= ' ORDER BY price ASC';
        return $this->db->fetchAll($sql);
    }

    public function findById(int $id): array|false
    {
        return $this->db->fetchOne('SELECT * FROM plans WHERE id = ?', [$id]);
    }

    public function create(array $data): int
    {
        $this->db->execute(
            'INSERT INTO plans (plan_name, duration_days, ai_message_limit, page_limit, price, status) VALUES (?,?,?,?,?,?)',
            [$data['plan_name'], $data['duration_days'], $data['ai_message_limit'], $data['page_limit'], $data['price'], $data['status'] ?? 'active']
        );
        return (int) $this->db->lastInsertId();
    }

    public function update(int $id, array $data): int
    {
        return $this->db->execute(
            'UPDATE plans SET plan_name=?, duration_days=?, ai_message_limit=?, page_limit=?, price=?, status=? WHERE id=?',
            [$data['plan_name'], $data['duration_days'], $data['ai_message_limit'], $data['page_limit'], $data['price'], $data['status'], $id]
        );
    }

    public function delete(int $id): int
    {
        return $this->db->execute('DELETE FROM plans WHERE id = ?', [$id]);
    }
}
