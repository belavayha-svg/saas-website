<?php

/**
 * Application Configuration
 * Loads environment variables from .env and defines app constants.
 */

// Load .env file
$envFile = dirname(__DIR__) . '/.env';
if (file_exists($envFile)) {
    $lines = file($envFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        if (str_starts_with(trim($line), '#')) continue;
        if (!str_contains($line, '=')) continue;
        [$key, $value] = explode('=', $line, 2);
        $key   = trim($key);
        $value = trim($value, " \t\n\r\0\x0B\"'");
        if (!array_key_exists($key, $_ENV)) {
            putenv("$key=$value");
            $_ENV[$key] = $value;
            $_SERVER[$key] = $value;
        }
    }
}

function env(string $key, mixed $default = null): mixed
{
    return $_ENV[$key] ?? getenv($key) ?: $default;
}

return [
    'name'    => env('APP_NAME', 'AI Chatbot SaaS'),
    'env'     => env('APP_ENV', 'production'),
    'debug'   => env('APP_DEBUG', false) === 'true',
    'url'     => env('APP_URL', 'http://localhost'),
    'secret'  => env('APP_SECRET', 'change_me'),
    'version' => '1.0.0',
];
