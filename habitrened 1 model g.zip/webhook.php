<?php

/**
 * webhook.php — Dedicated Facebook Webhook Endpoint
 * Can be placed at /webhook on its own or handled via index.php.
 * This standalone file ensures META can reach the webhook even
 * if the HTTP server doesn't fully support URL rewriting.
 */

define('BASE_PATH', __DIR__);

spl_autoload_register(function (string $class): void {
    $prefix = 'App\\';
    if (!str_starts_with($class, $prefix)) return;
    $relative = str_replace('\\', '/', substr($class, strlen($prefix)));
    $file     = BASE_PATH . '/app/' . $relative . '.php';
    if (file_exists($file)) require $file;
});

$appConfig = require BASE_PATH . '/config/app.php';

ini_set('display_errors', '0');
error_reporting(0);
ini_set('log_errors', '1');
ini_set('error_log', BASE_PATH . '/storage/logs/webhook.log');

use App\Core\{Request, Session};
use App\Controllers\WebhookController;

Session::start();

$request    = new Request();
$controller = new WebhookController();
$controller->handle($request);
